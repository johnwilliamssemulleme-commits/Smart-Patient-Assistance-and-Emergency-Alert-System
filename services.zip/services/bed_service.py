# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# BED SERVICE
# ============================================================
#
# Responsibility:
#
#     Desktop UI
#          ↓
#     bed_service.py
#          ↓
#     models.py
#          ↓
#     SQLite database
#
# This service manages:
#
#     • Wards
#     • Beds
#     • Bed availability
#     • Bed status
#     • Bed information
#
# This service DOES NOT manage:
#
#     • Patient authentication
#     • Administrator authentication
#     • Patient assignments
#     • ESP32 device assignments
#     • Alerts
#     • Serial communication
#     • Hall Receiver
#
# Those responsibilities belong to other backend services.
# ============================================================


import sqlite3

from models import get_connection


# ============================================================
# WARD MANAGEMENT
# ============================================================

def create_ward(ward_id, ward_type):
    """
    Create a new ward.

    Parameters:
        ward_id:
            Unique ward identifier.

        ward_type:
            Type/name of the ward.

    Returns:
        (True, message) on success
        (False, message) on failure
    """

    ward_id = str(ward_id).strip()
    ward_type = str(ward_type).strip()

    if not ward_id:
        return False, "Ward ID is required."

    if not ward_type:
        return False, "Ward type is required."

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute("""
            SELECT ward_id
            FROM wards
            WHERE ward_id = ?
        """, (ward_id,))

        if cursor.fetchone() is not None:

            connection.close()

            return False, (
                "Ward ID already exists."
            )

        cursor.execute("""
            INSERT INTO wards (
                ward_id,
                ward_type
            )
            VALUES (?, ?)
        """, (
            ward_id,
            ward_type
        ))

        connection.commit()

    except sqlite3.IntegrityError as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to create ward: {error}"
        )

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Database error while creating ward: {error}"
        )

    connection.close()

    return True, "Ward created successfully."


# ============================================================
# GET ALL WARDS
# ============================================================

def get_all_wards():
    """
    Return all registered wards.

    Returns:
        List of sqlite3.Row objects.
    """

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            ward_id,
            ward_type
        FROM wards
        ORDER BY ward_id
    """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# GET WARD
# ============================================================

def get_ward(ward_id):
    """
    Return one ward by ID.

    Returns:
        sqlite3.Row or None
    """

    ward_id = str(ward_id).strip()

    if not ward_id:
        return None

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            ward_id,
            ward_type
        FROM wards
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    ward = cursor.fetchone()

    connection.close()

    return ward


# ============================================================
# UPDATE WARD
# ============================================================

def update_ward(ward_id, ward_type):
    """
    Update the type/name of an existing ward.

    The ward ID itself is not changed.

    Returns:
        (True, message) on success
        (False, message) on failure
    """

    ward_id = str(ward_id).strip()
    ward_type = str(ward_type).strip()

    if not ward_id:
        return False, "Ward ID is required."

    if not ward_type:
        return False, "Ward type is required."

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT ward_id
        FROM wards
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    if cursor.fetchone() is None:

        connection.close()

        return False, "Ward ID does not exist."

    try:

        cursor.execute("""
            UPDATE wards
            SET ward_type = ?
            WHERE ward_id = ?
        """, (
            ward_type,
            ward_id
        ))

        connection.commit()

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to update ward: {error}"
        )

    connection.close()

    return True, "Ward updated successfully."


# ============================================================
# DELETE WARD
# ============================================================

def delete_ward(ward_id):
    """
    Delete a ward.

    A ward can only be deleted when it is not referenced by
    beds or device assignments.

    SQLite foreign-key protection is enabled in models.py.

    Returns:
        (True, message) on success
        (False, message) on failure
    """

    ward_id = str(ward_id).strip()

    if not ward_id:
        return False, "Ward ID is required."

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT ward_id
        FROM wards
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    if cursor.fetchone() is None:

        connection.close()

        return False, "Ward ID does not exist."

    cursor.execute("""
        SELECT bed_id
        FROM beds
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    if cursor.fetchone() is not None:

        connection.close()

        return False, (
            "Ward cannot be deleted because it contains beds."
        )

    cursor.execute("""
        SELECT id
        FROM device_assignments
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    if cursor.fetchone() is not None:

        connection.close()

        return False, (
            "Ward cannot be deleted because it has "
            "device assignments."
        )

    try:

        cursor.execute("""
            DELETE FROM wards
            WHERE ward_id = ?
        """, (ward_id,))

        connection.commit()

    except sqlite3.IntegrityError:

        connection.rollback()
        connection.close()

        return False, (
            "Ward cannot be deleted because it is "
            "still referenced by the system."
        )

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to delete ward: {error}"
        )

    connection.close()

    return True, "Ward deleted successfully."


# ============================================================
# BED MANAGEMENT
# ============================================================

def create_bed(
    bed_id,
    ward_id,
    status="Available"
):
    """
    Create a new bed.

    Parameters:
        bed_id:
            Unique bed identifier.

        ward_id:
            Ward to which the bed belongs.

        status:
            Initial bed status.
            Default is 'Available'.

    Returns:
        (True, message) on success
        (False, message) on failure
    """

    bed_id = str(bed_id).strip()
    ward_id = str(ward_id).strip()
    status = str(status).strip()

    if not bed_id:
        return False, "Bed ID is required."

    if not ward_id:
        return False, "Ward ID is required."

    if not status:
        return False, "Bed status is required."

    allowed_statuses = {
        "Available",
        "Occupied"
    }

    if status not in allowed_statuses:

        return False, (
            "Invalid bed status. "
            "Use Available or Occupied."
        )

    connection = get_connection()
    cursor = connection.cursor()

    # --------------------------------------------------------
    # Check ward
    # --------------------------------------------------------

    cursor.execute("""
        SELECT ward_id
        FROM wards
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    if cursor.fetchone() is None:

        connection.close()

        return False, "Ward ID does not exist."

    # --------------------------------------------------------
    # Check duplicate bed
    # --------------------------------------------------------

    cursor.execute("""
        SELECT bed_id
        FROM beds
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    if cursor.fetchone() is not None:

        connection.close()

        return False, "Bed ID already exists."

    # --------------------------------------------------------
    # Prevent creating an Occupied bed without a patient
    # assignment.
    # --------------------------------------------------------

    if status == "Occupied":

        connection.close()

        return False, (
            "A new bed must initially be Available."
        )

    try:

        cursor.execute("""
            INSERT INTO beds (
                bed_id,
                ward_id,
                status
            )
            VALUES (?, ?, ?)
        """, (
            bed_id,
            ward_id,
            status
        ))

        connection.commit()

    except sqlite3.IntegrityError as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to create bed: {error}"
        )

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Database error while creating bed: {error}"
        )

    connection.close()

    return True, "Bed created successfully."


# ============================================================
# GET ALL BEDS
# ============================================================

def get_all_beds():
    """
    Return all beds.

    Includes the ward type for convenient use by the UI.

    Returns:
        List of sqlite3.Row objects.
    """

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            b.bed_id,
            b.ward_id,
            w.ward_type,
            b.status
        FROM beds b

        LEFT JOIN wards w
            ON b.ward_id = w.ward_id

        ORDER BY
            b.ward_id,
            b.bed_id
    """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# GET BED
# ============================================================

def get_bed(bed_id):
    """
    Return one bed by ID.

    Includes ward information.

    Returns:
        sqlite3.Row or None
    """

    bed_id = str(bed_id).strip()

    if not bed_id:
        return None

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            b.bed_id,
            b.ward_id,
            w.ward_type,
            b.status
        FROM beds b

        LEFT JOIN wards w
            ON b.ward_id = w.ward_id

        WHERE b.bed_id = ?

        LIMIT 1
    """, (bed_id,))

    bed = cursor.fetchone()

    connection.close()

    return bed


# ============================================================
# GET BEDS BY WARD
# ============================================================

def get_beds_by_ward(ward_id):
    """
    Return all beds belonging to a specific ward.
    """

    ward_id = str(ward_id).strip()

    if not ward_id:
        return []

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            bed_id,
            ward_id,
            status
        FROM beds
        WHERE ward_id = ?
        ORDER BY bed_id
    """, (ward_id,))

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# GET AVAILABLE BEDS
# ============================================================

def get_available_beds(ward_id=None):
    """
    Return all available beds.

    If ward_id is supplied, only beds from that ward are
    returned.
    """

    if ward_id is not None:

        ward_id = str(ward_id).strip()

    connection = get_connection()
    cursor = connection.cursor()

    if ward_id:

        cursor.execute("""
            SELECT
                b.bed_id,
                b.ward_id,
                w.ward_type,
                b.status
            FROM beds b

            LEFT JOIN wards w
                ON b.ward_id = w.ward_id

            WHERE b.ward_id = ?
              AND b.status = 'Available'

            ORDER BY b.bed_id
        """, (ward_id,))

    else:

        cursor.execute("""
            SELECT
                b.bed_id,
                b.ward_id,
                w.ward_type,
                b.status
            FROM beds b

            LEFT JOIN wards w
                ON b.ward_id = w.ward_id

            WHERE b.status = 'Available'

            ORDER BY
                b.ward_id,
                b.bed_id
        """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# GET OCCUPIED BEDS
# ============================================================

def get_occupied_beds(ward_id=None):
    """
    Return all occupied beds.

    If ward_id is supplied, only beds from that ward are
    returned.
    """

    if ward_id is not None:

        ward_id = str(ward_id).strip()

    connection = get_connection()
    cursor = connection.cursor()

    if ward_id:

        cursor.execute("""
            SELECT
                b.bed_id,
                b.ward_id,
                w.ward_type,
                b.status
            FROM beds b

            LEFT JOIN wards w
                ON b.ward_id = w.ward_id

            WHERE b.ward_id = ?
              AND b.status = 'Occupied'

            ORDER BY b.bed_id
        """, (ward_id,))

    else:

        cursor.execute("""
            SELECT
                b.bed_id,
                b.ward_id,
                w.ward_type,
                b.status
            FROM beds b

            LEFT JOIN wards w
                ON b.ward_id = w.ward_id

            WHERE b.status = 'Occupied'

            ORDER BY
                b.ward_id,
                b.bed_id
        """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# UPDATE BED
# ============================================================

def update_bed(
    bed_id,
    ward_id=None,
    status=None
):
    """
    Update an existing bed.

    Parameters:

        bed_id:
            Existing bed ID.

        ward_id:
            Optional new ward.

        status:
            Optional new status.

    Important:
        Bed status must remain consistent with the
        patient_assignments table.

    A bed with a patient assignment cannot be changed to
    Available directly.

    Returns:
        (True, message) on success
        (False, message) on failure
    """

    bed_id = str(bed_id).strip()

    if not bed_id:
        return False, "Bed ID is required."

    if ward_id is not None:
        ward_id = str(ward_id).strip()

        if not ward_id:
            return False, "Ward ID cannot be empty."

    if status is not None:
        status = str(status).strip()

        if status not in {
            "Available",
            "Occupied"
        }:
            return False, (
                "Invalid bed status. "
                "Use Available or Occupied."
            )

    connection = get_connection()
    cursor = connection.cursor()

    # --------------------------------------------------------
    # Get existing bed
    # --------------------------------------------------------

    cursor.execute("""
        SELECT
            bed_id,
            ward_id,
            status
        FROM beds
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    bed = cursor.fetchone()

    if bed is None:

        connection.close()

        return False, "Bed ID does not exist."

    current_ward_id = bed["ward_id"]
    current_status = bed["status"]

    new_ward_id = (
        ward_id
        if ward_id is not None
        else current_ward_id
    )

    new_status = (
        status
        if status is not None
        else current_status
    )

    # --------------------------------------------------------
    # Check new ward
    # --------------------------------------------------------

    if new_ward_id != current_ward_id:

        cursor.execute("""
            SELECT ward_id
            FROM wards
            WHERE ward_id = ?
            LIMIT 1
        """, (new_ward_id,))

        if cursor.fetchone() is None:

            connection.close()

            return False, (
                "New ward ID does not exist."
            )

    # --------------------------------------------------------
    # Check patient assignment
    # --------------------------------------------------------

    cursor.execute("""
        SELECT
            id,
            patient_id,
            staff_id
        FROM patient_assignments
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    assignment = cursor.fetchone()

    # --------------------------------------------------------
    # A bed containing a patient must remain Occupied.
    # --------------------------------------------------------

    if assignment is not None and new_status != "Occupied":

        connection.close()

        return False, (
            "This bed has a patient assigned to it. "
            "Discharge or move the patient before making "
            "the bed Available."
        )

    # --------------------------------------------------------
    # A bed being changed to Occupied must have a patient.
    # --------------------------------------------------------

    if (
        new_status == "Occupied"
        and assignment is None
    ):

        connection.close()

        return False, (
            "A bed cannot be marked Occupied without "
            "a patient assignment."
        )

    # --------------------------------------------------------
    # Check device assignment when changing ward.
    #
    # Device assignments contain both ward_id and bed_id.
    # Changing a bed's ward while a device is assigned would
    # create inconsistent Device → Ward → Bed information.
    # --------------------------------------------------------

    if new_ward_id != current_ward_id:

        cursor.execute("""
            SELECT
                id,
                device_id
            FROM device_assignments
            WHERE bed_id = ?
            LIMIT 1
        """, (bed_id,))

        device_assignment = cursor.fetchone()

        if device_assignment is not None:

            connection.close()

            return False, (
                "This bed has an ESP32 device assigned. "
                "Update the device-bed assignment before "
                "moving the bed to another ward."
            )

    # --------------------------------------------------------
    # Nothing to update
    # --------------------------------------------------------

    if (
        new_ward_id == current_ward_id
        and new_status == current_status
    ):

        connection.close()

        return True, "No bed changes were required."

    try:

        cursor.execute("""
            UPDATE beds
            SET
                ward_id = ?,
                status = ?
            WHERE bed_id = ?
        """, (
            new_ward_id,
            new_status,
            bed_id
        ))

        connection.commit()

    except sqlite3.IntegrityError as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to update bed: {error}"
        )

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Database error while updating bed: {error}"
        )

    connection.close()

    return True, "Bed updated successfully."


# ============================================================
# UPDATE BED STATUS
# ============================================================

def update_bed_status(
    bed_id,
    status
):
    """
    Update only the status of a bed.

    This function enforces consistency with patient
    assignments.

    Valid statuses:
        Available
        Occupied
    """

    bed_id = str(bed_id).strip()
    status = str(status).strip()

    if not bed_id:
        return False, "Bed ID is required."

    if status not in {
        "Available",
        "Occupied"
    }:
        return False, (
            "Invalid bed status. "
            "Use Available or Occupied."
        )

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            bed_id,
            status
        FROM beds
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    bed = cursor.fetchone()

    if bed is None:

        connection.close()

        return False, "Bed ID does not exist."

    # --------------------------------------------------------
    # Check patient assignment
    # --------------------------------------------------------

    cursor.execute("""
        SELECT id
        FROM patient_assignments
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    assignment_exists = (
        cursor.fetchone() is not None
    )

    if status == "Available" and assignment_exists:

        connection.close()

        return False, (
            "Bed cannot be made Available while "
            "a patient is assigned to it."
        )

    if status == "Occupied" and not assignment_exists:

        connection.close()

        return False, (
            "Bed cannot be marked Occupied without "
            "a patient assignment."
        )

    try:

        cursor.execute("""
            UPDATE beds
            SET status = ?
            WHERE bed_id = ?
        """, (
            status,
            bed_id
        ))

        connection.commit()

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to update bed status: {error}"
        )

    connection.close()

    return True, "Bed status updated successfully."


# ============================================================
# DELETE BED
# ============================================================

def delete_bed(bed_id):
    """
    Delete a bed.

    A bed cannot be deleted when it has:
        • A patient assignment
        • An ESP32 device assignment
        • Alert references that prevent deletion

    The database foreign keys provide the final protection.
    """

    bed_id = str(bed_id).strip()

    if not bed_id:
        return False, "Bed ID is required."

    connection = get_connection()
    cursor = connection.cursor()

    # --------------------------------------------------------
    # Check bed exists
    # --------------------------------------------------------

    cursor.execute("""
        SELECT
            bed_id,
            status
        FROM beds
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    bed = cursor.fetchone()

    if bed is None:

        connection.close()

        return False, "Bed ID does not exist."

    # --------------------------------------------------------
    # Patient assignment
    # --------------------------------------------------------

    cursor.execute("""
        SELECT id
        FROM patient_assignments
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    if cursor.fetchone() is not None:

        connection.close()

        return False, (
            "Bed cannot be deleted because a patient "
            "is assigned to it."
        )

    # --------------------------------------------------------
    # Device assignment
    # --------------------------------------------------------

    cursor.execute("""
        SELECT id
        FROM device_assignments
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    if cursor.fetchone() is not None:

        connection.close()

        return False, (
            "Bed cannot be deleted because an ESP32 "
            "device is assigned to it."
        )

    # --------------------------------------------------------
    # Alerts
    #
    # alerts.bed_id uses ON DELETE SET NULL, so alerts do
    # not prevent deletion.
    # --------------------------------------------------------

    try:

        cursor.execute("""
            DELETE FROM beds
            WHERE bed_id = ?
        """, (bed_id,))

        connection.commit()

    except sqlite3.IntegrityError:

        connection.rollback()
        connection.close()

        return False, (
            "Bed cannot be deleted because it is "
            "still referenced by the system."
        )

    except sqlite3.Error as error:

        connection.rollback()
        connection.close()

        return False, (
            f"Unable to delete bed: {error}"
        )

    connection.close()

    return True, "Bed deleted successfully."


# ============================================================
# BED COUNT
# ============================================================

def get_bed_count(ward_id=None):
    """
    Return the total number of beds.

    If ward_id is supplied, count only beds in that ward.
    """

    if ward_id is not None:

        ward_id = str(ward_id).strip()

    connection = get_connection()
    cursor = connection.cursor()

    if ward_id:

        cursor.execute("""
            SELECT COUNT(*) AS total
            FROM beds
            WHERE ward_id = ?
        """, (ward_id,))

    else:

        cursor.execute("""
            SELECT COUNT(*) AS total
            FROM beds
        """)

    result = cursor.fetchone()

    connection.close()

    return result["total"] if result else 0


# ============================================================
# AVAILABLE BED COUNT
# ============================================================

def get_available_bed_count(ward_id=None):
    """
    Return the number of available beds.
    """

    if ward_id is not None:

        ward_id = str(ward_id).strip()

    connection = get_connection()
    cursor = connection.cursor()

    if ward_id:

        cursor.execute("""
            SELECT COUNT(*) AS total
            FROM beds
            WHERE ward_id = ?
              AND status = 'Available'
        """, (ward_id,))

    else:

        cursor.execute("""
            SELECT COUNT(*) AS total
            FROM beds
            WHERE status = 'Available'
        """)

    result = cursor.fetchone()

    connection.close()

    return result["total"] if result else 0


# ============================================================
# OCCUPIED BED COUNT
# ============================================================

def get_occupied_bed_count(ward_id=None):
    """
    Return the number of occupied beds.
    """

    if ward_id is not None:

        ward_id = str(ward_id).strip()

    connection = get_connection()
    cursor = connection.cursor()

    if ward_id:

        cursor.execute("""
            SELECT COUNT(*) AS total
            FROM beds
            WHERE ward_id = ?
              AND status = 'Occupied'
        """, (ward_id,))

    else:

        cursor.execute("""
            SELECT COUNT(*) AS total
            FROM beds
            WHERE status = 'Occupied'
        """)

    result = cursor.fetchone()

    connection.close()

    return result["total"] if result else 0


# ============================================================
# BED SUMMARY
# ============================================================

def get_bed_summary(ward_id=None):
    """
    Return a summary of bed availability.

    Returns:

        {
            "total": ...,
            "available": ...,
            "occupied": ...
        }
    """

    total = get_bed_count(ward_id)
    available = get_available_bed_count(ward_id)
    occupied = get_occupied_bed_count(ward_id)

    return {
        "total": total,
        "available": available,
        "occupied": occupied
    }


# ============================================================
# GET WARD BED SUMMARY
# ============================================================

def get_ward_bed_summary():
    """
    Return bed statistics for every ward.

    Returns rows containing:

        ward_id
        ward_type
        total_beds
        available_beds
        occupied_beds
    """

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            w.ward_id,
            w.ward_type,

            COUNT(b.bed_id) AS total_beds,

            SUM(
                CASE
                    WHEN b.status = 'Available'
                    THEN 1
                    ELSE 0
                END
            ) AS available_beds,

            SUM(
                CASE
                    WHEN b.status = 'Occupied'
                    THEN 1
                    ELSE 0
                END
            ) AS occupied_beds

        FROM wards w

        LEFT JOIN beds b
            ON w.ward_id = b.ward_id

        GROUP BY
            w.ward_id,
            w.ward_type

        ORDER BY w.ward_id
    """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# FIND BED
# ============================================================

def find_bed(bed_id):
    """
    Alias for get_bed().

    Provided for convenient use by UI/service code.
    """

    return get_bed(bed_id)


# ============================================================
# CHECK BED EXISTS
# ============================================================

def bed_exists(bed_id):
    """
    Check whether a bed exists.
    """

    bed_id = str(bed_id).strip()

    if not bed_id:
        return False

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT bed_id
        FROM beds
        WHERE bed_id = ?
        LIMIT 1
    """, (bed_id,))

    result = cursor.fetchone()

    connection.close()

    return result is not None


# ============================================================
# CHECK WARD EXISTS
# ============================================================

def ward_exists(ward_id):
    """
    Check whether a ward exists.
    """

    ward_id = str(ward_id).strip()

    if not ward_id:
        return False

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT ward_id
        FROM wards
        WHERE ward_id = ?
        LIMIT 1
    """, (ward_id,))

    result = cursor.fetchone()

    connection.close()

    return result is not None


# ============================================================
# GET BED WITH PATIENT INFORMATION
# ============================================================

def get_bed_with_patient(bed_id):
    """
    Return a bed together with its current patient and staff
    assignment, if one exists.

    This does not modify any database information.
    """

    bed_id = str(bed_id).strip()

    if not bed_id:
        return None

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            b.bed_id,
            b.ward_id,
            w.ward_type,
            b.status,

            pa.patient_id,
            pa.staff_id,

            pa.created_at AS assignment_created_at,
            pa.updated_at AS assignment_updated_at

        FROM beds b

        LEFT JOIN wards w
            ON b.ward_id = w.ward_id

        LEFT JOIN patient_assignments pa
            ON b.bed_id = pa.bed_id

        WHERE b.bed_id = ?

        LIMIT 1
    """, (bed_id,))

    row = cursor.fetchone()

    connection.close()

    return row


# ============================================================
# GET ALL BEDS WITH PATIENT INFORMATION
# ============================================================

def get_all_beds_with_patients():
    """
    Return all beds together with current patient/staff
    assignment information.

    This is useful for a Bed Management table in the desktop UI.
    """

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            b.bed_id,
            b.ward_id,
            w.ward_type,
            b.status,

            pa.patient_id,
            pa.staff_id,

            pa.created_at AS assignment_created_at,
            pa.updated_at AS assignment_updated_at

        FROM beds b

        LEFT JOIN wards w
            ON b.ward_id = w.ward_id

        LEFT JOIN patient_assignments pa
            ON b.bed_id = pa.bed_id

        ORDER BY
            b.ward_id,
            b.bed_id
    """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# GET EMPTY BEDS
# ============================================================

def get_empty_beds(ward_id=None):
    """
    Return beds that currently have no patient assignment.

    This is based on patient_assignments rather than only
    relying on the bed status field.
    """

    if ward_id is not None:

        ward_id = str(ward_id).strip()

    connection = get_connection()
    cursor = connection.cursor()

    if ward_id:

        cursor.execute("""
            SELECT
                b.bed_id,
                b.ward_id,
                w.ward_type,
                b.status

            FROM beds b

            LEFT JOIN wards w
                ON b.ward_id = w.ward_id

            LEFT JOIN patient_assignments pa
                ON b.bed_id = pa.bed_id

            WHERE b.ward_id = ?
              AND pa.id IS NULL

            ORDER BY b.bed_id
        """, (ward_id,))

    else:

        cursor.execute("""
            SELECT
                b.bed_id,
                b.ward_id,
                w.ward_type,
                b.status

            FROM beds b

            LEFT JOIN wards w
                ON b.ward_id = w.ward_id

            LEFT JOIN patient_assignments pa
                ON b.bed_id = pa.bed_id

            WHERE pa.id IS NULL

            ORDER BY
                b.ward_id,
                b.bed_id
        """)

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# RECONCILE BED STATUS
# ============================================================

def reconcile_bed_status(bed_id=None):
    """
    Synchronize bed.status with patient_assignments.

    Rules:

        Patient assignment exists
            → Occupied

        No patient assignment
            → Available

    If bed_id is supplied, only that bed is reconciled.

    Returns:
        Number of beds updated.
    """

    connection = get_connection()
    cursor = connection.cursor()

    if bed_id is not None:

        bed_id = str(bed_id).strip()

        if not bed_id:

            connection.close()

            return 0

        cursor.execute("""
            SELECT
                b.bed_id,

                CASE
                    WHEN pa.id IS NOT NULL
                    THEN 'Occupied'
                    ELSE 'Available'
                END AS correct_status

            FROM beds b

            LEFT JOIN patient_assignments pa
                ON b.bed_id = pa.bed_id

            WHERE b.bed_id = ?
        """, (bed_id,))

    else:

        cursor.execute("""
            SELECT
                b.bed_id,

                CASE
                    WHEN pa.id IS NOT NULL
                    THEN 'Occupied'
                    ELSE 'Available'
                END AS correct_status

            FROM beds b

            LEFT JOIN patient_assignments pa
                ON b.bed_id = pa.bed_id
        """)

    rows = cursor.fetchall()

    updated = 0

    try:

        for row in rows:

            cursor.execute("""
                UPDATE beds
                SET status = ?
                WHERE bed_id = ?
                  AND status != ?
            """, (
                row["correct_status"],
                row["bed_id"],
                row["correct_status"]
            ))

            updated += cursor.rowcount

        connection.commit()

    except sqlite3.Error:

        connection.rollback()
        connection.close()

        raise

    connection.close()

    return updated


# ============================================================
# BED SERVICE SELF TEST
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        "SMART PATIENT ASSISTANCE AND "
        "EMERGENCY ALERT SYSTEM"
    )

    print(
        "BED SERVICE TEST"
    )

    print(
        "=============================================="
    )

    # --------------------------------------------------------
    # Ward count
    # --------------------------------------------------------

    wards = get_all_wards()

    print(
        f"Wards registered: {len(wards)}"
    )

    # --------------------------------------------------------
    # Bed count
    # --------------------------------------------------------

    beds = get_all_beds()

    print(
        f"Beds registered: {len(beds)}"
    )

    # --------------------------------------------------------
    # Summary
    # --------------------------------------------------------

    summary = get_bed_summary()

    print(
        f"Total beds: {summary['total']}"
    )

    print(
        f"Available beds: {summary['available']}"
    )

    print(
        f"Occupied beds: {summary['occupied']}"
    )

    print(
        "=============================================="
    )