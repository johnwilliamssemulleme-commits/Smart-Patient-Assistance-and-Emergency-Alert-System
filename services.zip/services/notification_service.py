# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# NOTIFICATION SERVICE
# ============================================================
#
# Responsibility:
#
#     Patient ESP32
#          ↓
#     USB Serial
#          ↓
#     serial_service.py
#          ↓
#     notification_service.py
#          ↓
#     SQLite Database
#          ↓
#     Desktop UI
#
# IMPORTANT:
#
# This service does NOT own serial-port communication.
#
# serial_service.py will be responsible for:
#
#     - Detecting the ESP32 serial port
#     - Opening the serial connection
#     - Reading serial data
#     - Reconnecting when disconnected
#     - Parsing the physical serial stream
#
# notification_service.py is responsible for:
#
#     - Receiving parsed messages from serial_service.py
#     - Validating patient alert messages
#     - Resolving Device → Ward → Bed → Patient → Staff
#     - Creating database alerts
#     - Updating device communication status
#     - Creating system logs
#     - Notifying the desktop UI
#     - Playing alert sounds
#     - Text-to-speech notifications
#     - Repeating active alert notifications
#     - Managing alert acknowledgement/attendance
#     - Managing alert cancellation
#
# This design prevents duplicate alert insertion.
#
# ============================================================


import json
import threading
import time

from pathlib import Path
from datetime import datetime

from models import (
    create_database,
    get_connection
)


# ============================================================
# PROJECT DIRECTORIES
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"


# ============================================================
# APPLICATION INFORMATION
# ============================================================

APP_NAME = (
    "Smart Patient Assistance and Emergency Alert System"
)

SERVICE_NAME = "Notification Service"

SERVICE_VERSION = "1.0.0"


# ============================================================
# SETTINGS FILE
# ============================================================

SETTINGS_FILE = DATA_DIR / "system_settings.json"


# ============================================================
# DEFAULT NOTIFICATION SETTINGS
# ============================================================

DEFAULT_NOTIFICATION_SETTINGS = {

    "notification_sound": {

        "sound_enabled": True,

        "volume": 100,

        "repeat_sound": True,

        "repeat_interval": 5

    },

    "response_timing": {

        "response_timeout": 60,

        "alert_repeat_interval": 5

    },

    "alert": {

        "assistance_alert_enabled": True,

        "emergency_alert_enabled": True,

        "critical_alert_enabled": True

    }

}


# ============================================================
# INTERNAL STATE
# ============================================================

_notification_lock = threading.RLock()

_callback_lock = threading.Lock()

_alert_callback = None

_notification_running = False

_notification_thread = None

_stop_event = threading.Event()


# ============================================================
# ACTIVE ALERT TRACKING
# ============================================================
#
# Structure:
#
# {
#     alert_id: {
#         "alert_id": 10,
#         "device_id": "PATIENT-001",
#         "ward_id": "WARD-A",
#         "bed_id": "BED-01",
#         "patient_id": "P001",
#         "staff_id": "S001",
#         "alert_type": "EMERGENCY",
#         "created_at": "...",
#         "last_notification": timestamp
#     }
# }
#
# The database remains authoritative.
#
# This dictionary is only used to control repeated
# notifications during the current application session.
# ============================================================

_active_alerts = {}


# ============================================================
# OPTIONAL TEXT-TO-SPEECH ENGINE
# ============================================================

_tts_engine = None

_tts_lock = threading.Lock()


# ============================================================
# INITIALIZE SERVICE
# ============================================================

def initialize_notification_service():
    """
    Initialize the notification service.

    This ensures the database and data directory exist.
    """

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    create_database()

    load_settings()

    print(
        "Notification service initialized."
    )


# ============================================================
# DEFAULT SETTINGS COPY
# ============================================================

def get_default_notification_settings():
    """
    Return a fresh copy of notification settings.
    """

    return json.loads(
        json.dumps(
            DEFAULT_NOTIFICATION_SETTINGS
        )
    )


# ============================================================
# LOAD SETTINGS
# ============================================================

def load_settings():
    """
    Load notification settings.

    Existing settings are preserved.

    Missing notification sections are automatically added.
    """

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    if not SETTINGS_FILE.exists():

        settings = get_default_notification_settings()

        save_settings(settings)

        return settings

    try:

        with open(
            SETTINGS_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            settings = json.load(file)

        if not isinstance(
            settings,
            dict
        ):

            raise ValueError(
                "Settings file must contain an object."
            )

    except (
        json.JSONDecodeError,
        OSError,
        ValueError
    ):

        settings = {}

    changed = False

    for section, values in (
        DEFAULT_NOTIFICATION_SETTINGS.items()
    ):

        if section not in settings:

            settings[section] = json.loads(
                json.dumps(values)
            )

            changed = True

            continue

        if not isinstance(
            settings[section],
            dict
        ):

            settings[section] = json.loads(
                json.dumps(values)
            )

            changed = True

            continue

        for key, default_value in values.items():

            if key not in settings[section]:

                settings[section][key] = default_value

                changed = True

    if changed:

        save_settings(settings)

    return settings


# ============================================================
# SAVE SETTINGS
# ============================================================

def save_settings(settings):
    """
    Save system settings safely.
    """

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    temporary_file = SETTINGS_FILE.with_suffix(
        ".tmp"
    )

    with open(
        temporary_file,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            settings,
            file,
            indent=4
        )

    temporary_file.replace(
        SETTINGS_FILE
    )


# ============================================================
# GET ALERT SETTINGS
# ============================================================

def get_alert_settings():
    """
    Return alert enable/disable settings.
    """

    settings = load_settings()

    return settings["alert"]


# ============================================================
# GET SOUND SETTINGS
# ============================================================

def get_notification_sound_settings():
    """
    Return notification sound settings.
    """

    settings = load_settings()

    return settings[
        "notification_sound"
    ]


# ============================================================
# GET RESPONSE TIMING SETTINGS
# ============================================================

def get_response_timing_settings():
    """
    Return response timing settings.
    """

    settings = load_settings()

    return settings[
        "response_timing"
    ]


# ============================================================
# UPDATE ALERT SETTINGS
# ============================================================

def update_alert_settings(
    assistance_alert_enabled=None,
    emergency_alert_enabled=None,
    critical_alert_enabled=None
):
    """
    Update alert enable/disable settings.
    """

    settings = load_settings()

    alert = settings["alert"]

    if assistance_alert_enabled is not None:

        alert[
            "assistance_alert_enabled"
        ] = bool(
            assistance_alert_enabled
        )

    if emergency_alert_enabled is not None:

        alert[
            "emergency_alert_enabled"
        ] = bool(
            emergency_alert_enabled
        )

    if critical_alert_enabled is not None:

        alert[
            "critical_alert_enabled"
        ] = bool(
            critical_alert_enabled
        )

    save_settings(settings)

    return alert


# ============================================================
# UPDATE SOUND SETTINGS
# ============================================================

def update_notification_sound_settings(
    sound_enabled=None,
    volume=None,
    repeat_sound=None,
    repeat_interval=None
):
    """
    Update notification sound settings.
    """

    settings = load_settings()

    sound = settings[
        "notification_sound"
    ]

    if sound_enabled is not None:

        sound[
            "sound_enabled"
        ] = bool(
            sound_enabled
        )

    if volume is not None:

        volume = int(volume)

        if volume < 0 or volume > 100:

            raise ValueError(
                "Volume must be between 0 and 100."
            )

        sound["volume"] = volume

    if repeat_sound is not None:

        sound[
            "repeat_sound"
        ] = bool(
            repeat_sound
        )

    if repeat_interval is not None:

        repeat_interval = int(
            repeat_interval
        )

        if repeat_interval <= 0:

            raise ValueError(
                "Repeat interval must be greater than zero."
            )

        sound[
            "repeat_interval"
        ] = repeat_interval

    save_settings(settings)

    return sound


# ============================================================
# UPDATE RESPONSE TIMING
# ============================================================

def update_response_timing_settings(
    response_timeout=None,
    alert_repeat_interval=None
):
    """
    Update response and notification timing.
    """

    settings = load_settings()

    timing = settings[
        "response_timing"
    ]

    if response_timeout is not None:

        response_timeout = int(
            response_timeout
        )

        if response_timeout <= 0:

            raise ValueError(
                "Response timeout must be greater than zero."
            )

        timing[
            "response_timeout"
        ] = response_timeout

    if alert_repeat_interval is not None:

        alert_repeat_interval = int(
            alert_repeat_interval
        )

        if alert_repeat_interval <= 0:

            raise ValueError(
                "Alert repeat interval must be greater than zero."
            )

        timing[
            "alert_repeat_interval"
        ] = alert_repeat_interval

    save_settings(settings)

    return timing


# ============================================================
# ALERT TYPE NORMALIZATION
# ============================================================

def normalize_alert_type(alert_type):
    """
    Normalize alert type received from the ESP32.

    Supported logical alert types:

        ASSISTANCE
        EMERGENCY
        CRITICAL

    Several common firmware names are accepted.
    """

    if alert_type is None:

        return None

    value = str(
        alert_type
    ).strip().upper()

    aliases = {

        "CALL": "ASSISTANCE",

        "PATIENT_CALL": "ASSISTANCE",

        "PATIENT_ALERT": "ASSISTANCE",

        "ASSISTANCE": "ASSISTANCE",

        "HELP": "ASSISTANCE",

        "HELP_REQUEST": "ASSISTANCE",

        "EMERGENCY": "EMERGENCY",

        "EMERGENCY_ALERT": "EMERGENCY",

        "SOS": "EMERGENCY",

        "CRITICAL": "CRITICAL",

        "CRITICAL_ALERT": "CRITICAL",

        "CODE_BLUE": "CRITICAL"

    }

    return aliases.get(
        value,
        value
    )


# ============================================================
# CHECK WHETHER ALERT TYPE IS ENABLED
# ============================================================

def is_alert_type_enabled(alert_type):
    """
    Check whether a particular alert type is enabled.
    """

    alert_type = normalize_alert_type(
        alert_type
    )

    settings = get_alert_settings()

    if alert_type == "ASSISTANCE":

        return settings[
            "assistance_alert_enabled"
        ]

    if alert_type == "EMERGENCY":

        return settings[
            "emergency_alert_enabled"
        ]

    if alert_type == "CRITICAL":

        return settings[
            "critical_alert_enabled"
        ]

    # Unknown alert types are allowed so that future
    # firmware versions do not silently disappear.

    return True


# ============================================================
# REGISTER UI CALLBACK
# ============================================================

def set_notification_callback(callback):
    """
    Register a desktop UI callback.

    Example:

        set_notification_callback(
            main_window.handle_new_alert
        )

    The callback receives a dictionary.
    """

    global _alert_callback

    with _callback_lock:

        _alert_callback = callback


# ============================================================
# SEND ALERT TO UI
# ============================================================

def _notify_ui(alert):
    """
    Notify the registered desktop UI callback.
    """

    with _callback_lock:

        callback = _alert_callback

    if callback is None:

        return

    try:

        callback(alert)

    except Exception as error:

        print(
            "Notification UI callback error:",
            error
        )


# ============================================================
# INITIALIZE TEXT-TO-SPEECH
# ============================================================

def _get_tts_engine():
    """
    Lazily initialize the pyttsx3 engine.

    pyttsx3 is optional. If it cannot initialize,
    the notification service continues operating normally.
    """

    global _tts_engine

    with _tts_lock:

        if _tts_engine is not None:

            return _tts_engine

        try:

            import pyttsx3

            _tts_engine = pyttsx3.init()

            return _tts_engine

        except Exception as error:

            print(
                "Text-to-speech initialization failed:",
                error
            )

            _tts_engine = None

            return None


# ============================================================
# TEXT-TO-SPEECH ALERT
# ============================================================

def format_alert_notification(alert):
    """Build display and voice text from alert data, not hard-coded events."""
    alert = dict(alert or {})
    patient = alert.get("patient_number") or alert.get("patient_id") or "unknown patient"
    ward_type = alert.get("ward") or alert.get("ward_type") or "unknown ward type"
    ward_id = alert.get("ward_id") or "unknown ward"
    alert_type = normalize_alert_type(alert.get("alert_type") or alert.get("type"))
    condition = str(alert.get("condition") or "").replace("_", " ").strip()
    required_action = str(alert.get("required_action") or alert.get("requirement") or "").replace("_", " ").strip()

    location = f"Patient {patient} in {ward_type}, ward ID {ward_id}"
    if alert_type == "CRITICAL" or condition == "critical condition":
        message = f"{location} is in critical condition"
        if required_action:
            message += f" and requires {required_action}"
    elif alert_type == "EMERGENCY":
        message = f"{location} has an emergency need"
        if required_action:
            message += f": {required_action}"
    elif condition == "fall detected":
        message = f"{location} has experienced a fall and requires assistance"
    elif condition == "bed exit":
        message = f"{location} has left the bed"
    else:
        message = f"{location} requires {required_action or condition or 'assistance'}"

    return {
        "display": message + ".",
        "voice": "Attention. " + message + ".",
    }

def speak_alert(alert):
    """
    Speak a patient alert.

    This function is intentionally independent of the
    serial service.
    """

    if not alert:

        return False

    settings = get_notification_sound_settings()

    if not settings.get(
        "sound_enabled",
        True
    ):

        return False

    engine = _get_tts_engine()

    if engine is None:

        return False

    text = format_alert_notification(alert)["voice"]

    def speak():

        try:

            with _tts_lock:

                engine.say(text)

                engine.runAndWait()

        except Exception as error:

            print(
                "Text-to-speech error:",
                error
            )

    thread = threading.Thread(
        target=speak,
        daemon=True
    )

    thread.start()

    return True


# ============================================================
# SYSTEM BEEP
# ============================================================

def play_notification_sound():
    """
    Play a simple system notification sound.

    Windows uses winsound when available.

    On systems where winsound is unavailable,
    the function simply returns False.
    """

    settings = get_notification_sound_settings()

    if not settings.get(
        "sound_enabled",
        True
    ):

        return False

    try:

        import winsound

        volume = settings.get(
            "volume",
            100
        )

        # winsound does not provide a direct percentage
        # volume API, so the volume value is currently
        # retained as a system setting for UI consistency.

        del volume

        winsound.MessageBeep(
            winsound.MB_ICONEXCLAMATION
        )

        return True

    except Exception as error:

        print(
            "Notification sound error:",
            error
        )

        return False


# ============================================================
# NOTIFY ABOUT ALERT
# ============================================================

def notify_alert(alert):
    """
    Perform all notification actions for an alert.
    """

    if not alert:

        return

    play_notification_sound()

    speak_alert(
        alert
    )

    _notify_ui(
        alert
    )


# ============================================================
# NORMALIZE SERIAL MESSAGE
# ============================================================

def normalize_serial_message(message):
    """
    Convert a message received from serial_service.py
    into a standard dictionary.

    Accepted inputs:

        dict
        JSON string
        bytes containing JSON

    Example JSON:

        {
            "message_type": "PATIENT_ALERT",
            "device_id": "PATIENT-001",
            "alert_type": "EMERGENCY"
        }
    """

    if message is None:

        return None

    # --------------------------------------------------------
    # Dictionary
    # --------------------------------------------------------

    if isinstance(
        message,
        dict
    ):

        return dict(message)

    # --------------------------------------------------------
    # Bytes
    # --------------------------------------------------------

    if isinstance(
        message,
        bytes
    ):

        try:

            message = message.decode(
                "utf-8",
                errors="replace"
            )

        except Exception:

            return None

    # --------------------------------------------------------
    # String
    # --------------------------------------------------------

    if isinstance(
        message,
        str
    ):

        message = message.strip()

        if not message:

            return None

        try:

            parsed = json.loads(
                message
            )

            if isinstance(
                parsed,
                dict
            ):

                return parsed

        except json.JSONDecodeError:

            pass

        # ----------------------------------------------------
        # Support simple key=value serial messages.
        #
        # Example:
        #
        # TYPE=EMERGENCY,DEVICE=PATIENT-001
        # ----------------------------------------------------

        parsed = {}

        for part in message.split(","):

            if "=" not in part:

                continue

            key, value = part.split(
                "=",
                1
            )

            key = key.strip()

            value = value.strip()

            if key:

                parsed[key] = value

        if parsed:

            return parsed

        # ----------------------------------------------------
        # Support simple message names.
        # ----------------------------------------------------

        upper_message = message.upper()

        if upper_message in (
            "ASSISTANCE",
            "EMERGENCY",
            "CRITICAL",
            "PATIENT_ALERT",
            "PATIENT_CALL",
            "CALL"
        ):

            return {
                "message_type": upper_message,
                "alert_type": upper_message
            }

        return None

    return None


# ============================================================
# EXTRACT MESSAGE TYPE
# ============================================================

def get_message_type(message):
    """
    Extract and normalize the serial message type.
    """

    if not isinstance(
        message,
        dict
    ):

        return ""

    value = (
        message.get("message_type")
        or message.get("message")
        or message.get("type")
        or ""
    )

    return str(
        value
    ).strip().upper()


# ============================================================
# EXTRACT DEVICE ID
# ============================================================

def get_device_id(message):
    """
    Extract device ID from a serial message.

    Several names are supported so future firmware changes
    do not require rewriting the notification service.
    """

    if not isinstance(
        message,
        dict
    ):

        return None

    device_id = (
        message.get("device_id")
        or message.get("sender_device_id")
        or message.get("sender_id")
        or message.get("device")
        or message.get("deviceId")
    )

    if device_id is None:

        return None

    device_id = str(
        device_id
    ).strip()

    return device_id or None


# ============================================================
# EXTRACT ALERT TYPE
# ============================================================

def get_alert_type(message):
    """
    Extract alert type from serial message.
    """

    if not isinstance(
        message,
        dict
    ):

        return None

    alert_type = (
        message.get("alert_type")
        or message.get("call_type")
        or message.get("alert")
        or message.get("priority")
    )

    if alert_type is None:

        message_type = get_message_type(
            message
        )

        if message_type in (
            "ASSISTANCE",
            "EMERGENCY",
            "CRITICAL",
            "CALL",
            "PATIENT_ALERT",
            "PATIENT_CALL"
        ):

            alert_type = message_type

    return normalize_alert_type(
        alert_type
    )


# ============================================================
# RESOLVE DEVICE ASSIGNMENT
# ============================================================

def resolve_device_assignment(
    device_id
):
    """
    Resolve:

        Device
          ↓
        Ward
          ↓
        Bed
          ↓
        Patient
          ↓
        Staff

    The database assignment is authoritative.

    Returns a dictionary or None.
    """

    if not device_id:

        return None

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                d.device_id,

                da.ward_id,

                da.bed_id,

                pa.patient_id,

                pa.staff_id

            FROM devices d

            LEFT JOIN device_assignments da
                ON d.device_id = da.device_id

            LEFT JOIN patient_assignments pa
                ON da.bed_id = pa.bed_id

            WHERE d.device_id = ?

            LIMIT 1
            """,
            (
                device_id,
            )
        )

        row = cursor.fetchone()

        if row is None:

            return None

        return {
            "device_id": row["device_id"],
            "ward_id": row["ward_id"],
            "bed_id": row["bed_id"],
            "patient_id": row["patient_id"],
            "staff_id": row["staff_id"]
        }

    finally:

        connection.close()


# ============================================================
# UPDATE DEVICE ONLINE STATUS
# ============================================================

def mark_device_online(
    device_id
):
    """
    Mark an ESP32 device as online and update last_seen.
    """

    if not device_id:

        return False

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            UPDATE devices

            SET
                status = 'Online',
                last_seen = CURRENT_TIMESTAMP

            WHERE device_id = ?
            """,
            (
                device_id,
            )
        )

        connection.commit()

        return cursor.rowcount > 0

    except Exception as error:

        connection.rollback()

        print(
            "Unable to update device online status:",
            error
        )

        return False

    finally:

        connection.close()


# ============================================================
# MARK DEVICE OFFLINE
# ============================================================

def mark_device_offline(
    device_id
):
    """
    Mark a registered ESP32 device as offline.
    """

    if not device_id:

        return False

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            UPDATE devices

            SET
                status = 'Offline'

            WHERE device_id = ?
            """,
            (
                device_id,
            )
        )

        connection.commit()

        return cursor.rowcount > 0

    except Exception as error:

        connection.rollback()

        print(
            "Unable to update device offline status:",
            error
        )

        return False

    finally:

        connection.close()


# ============================================================
# ADD SYSTEM LOG
# ============================================================

def add_system_log(
    event_type,
    description,
    device_id=None,
    ward_id=None,
    bed_id=None,
    patient_id=None
):
    """
    Add an event to system_logs.
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            INSERT INTO system_logs (
                event_type,
                description,
                device_id,
                ward_id,
                bed_id,
                patient_id
            )

            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                event_type,
                description,
                device_id,
                ward_id,
                bed_id,
                patient_id
            )
        )

        connection.commit()

        return cursor.lastrowid

    except Exception as error:

        connection.rollback()

        print(
            "Unable to create system log:",
            error
        )

        return None

    finally:

        connection.close()


# ============================================================
# FIND DUPLICATE ACTIVE ALERT
# ============================================================

def find_existing_active_alert(
    device_id,
    alert_type
):
    """
    Find an existing ACTIVE alert for the same device
    and alert type.

    This protects the database from duplicate alerts when
    the same serial message is retransmitted.
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at

            FROM alerts

            WHERE device_id = ?

              AND alert_type = ?

              AND alert_status = 'ACTIVE'

            ORDER BY id DESC

            LIMIT 1
            """,
            (
                device_id,
                alert_type
            )
        )

        return cursor.fetchone()

    finally:

        connection.close()


# ============================================================
# BUILD ALERT DICTIONARY
# ============================================================

def build_alert_dictionary(
    row
):
    """
    Convert SQLite alert row into a normal dictionary.
    """

    if row is None:

        return None

    return {
        "id": row["id"],
        "device_id": row["device_id"],
        "ward_id": row["ward_id"],
        "bed_id": row["bed_id"],
        "patient_id": row["patient_id"],
        "staff_id": row["staff_id"],
        "alert_type": row["alert_type"],
        "alert_status": row["alert_status"],
        "created_at": row["created_at"],
        "attended_at": row["attended_at"]
    }


# ============================================================
# INSERT ALERT
# ============================================================

def insert_alert(
    device_id,
    ward_id,
    bed_id,
    patient_id,
    staff_id,
    alert_type
):
    """
    Insert a new ACTIVE alert into the database.

    Returns:

        alert dictionary

    or:

        None
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            INSERT INTO alerts (
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status
            )

            VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE')
            """,
            (
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type
            )
        )

        alert_id = cursor.lastrowid

        cursor.execute(
            """
            SELECT
                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at

            FROM alerts

            WHERE id = ?

            LIMIT 1
            """,
            (
                alert_id,
            )
        )

        row = cursor.fetchone()

        connection.commit()

        return build_alert_dictionary(
            row
        )

    except Exception as error:

        connection.rollback()

        print(
            "Unable to insert patient alert:",
            error
        )

        return None

    finally:

        connection.close()


# ============================================================
# PROCESS PATIENT ALERT
# ============================================================

def process_patient_alert(
    message
):
    """
    Process a patient alert received from serial_service.py.

    This is the main entry point for patient alerts.

    Example:

        notification_service.process_patient_alert(
            {
                "message_type": "PATIENT_ALERT",
                "device_id": "PATIENT-001",
                "alert_type": "EMERGENCY"
            }
        )
    """

    # --------------------------------------------------------
    # Normalize
    # --------------------------------------------------------

    message = normalize_serial_message(
        message
    )

    if message is None:

        print(
            "Ignoring invalid serial message."
        )

        return None

    # --------------------------------------------------------
    # Device
    # --------------------------------------------------------

    device_id = get_device_id(
        message
    )

    if not device_id:

        print(
            "Ignoring patient alert without device ID."
        )

        return None

    # --------------------------------------------------------
    # Alert type
    # --------------------------------------------------------

    alert_type = get_alert_type(
        message
    )

    if not alert_type:

        print(
            "Ignoring patient alert without alert type."
        )

        return None

    # --------------------------------------------------------
    # Check alert configuration
    # --------------------------------------------------------

    if not is_alert_type_enabled(
        alert_type
    ):

        add_system_log(
            event_type="ALERT_DISABLED",
            description=(
                f"{alert_type} alert received from "
                f"device {device_id}, but this alert type "
                f"is disabled."
            ),
            device_id=device_id
        )

        return None

    # --------------------------------------------------------
    # Device must exist
    # --------------------------------------------------------

    assignment = resolve_device_assignment(
        device_id
    )

    if assignment is None:

        print(
            f"Unknown patient device: {device_id}"
        )

        add_system_log(
            event_type="UNKNOWN_DEVICE_ALERT",
            description=(
                f"Alert received from unregistered "
                f"device {device_id}."
            ),
            device_id=device_id
        )

        return None

    # --------------------------------------------------------
    # Mark device online
    # --------------------------------------------------------

    mark_device_online(
        device_id
    )

    # --------------------------------------------------------
    # Duplicate protection
    # --------------------------------------------------------
    #
    # If the same ESP32 retransmits the same alert while
    # the original alert is still ACTIVE, do not create
    # another database record.
    # --------------------------------------------------------

    existing = find_existing_active_alert(
        device_id,
        alert_type
    )

    if existing is not None:

        existing_alert = build_alert_dictionary(
            existing
        )

        print(
            "Duplicate active patient alert ignored:",
            existing_alert
        )

        # Still notify UI so that the UI can refresh its
        # current active-alert state if necessary.

        _notify_ui(
            existing_alert
        )

        return existing_alert

    # --------------------------------------------------------
    # Insert new alert
    # --------------------------------------------------------

    alert = insert_alert(

        device_id=device_id,

        ward_id=assignment["ward_id"],

        bed_id=assignment["bed_id"],

        patient_id=assignment["patient_id"],

        staff_id=assignment["staff_id"],

        alert_type=alert_type
    )

    if alert is None:

        return None

    # --------------------------------------------------------
    # Track active alert
    # --------------------------------------------------------

    with _notification_lock:

        _active_alerts[
            alert["id"]
        ] = {
            **alert,
            "last_notification": time.time()
        }

    # --------------------------------------------------------
    # System log
    # --------------------------------------------------------

    add_system_log(

        event_type="PATIENT_ALERT_RECEIVED",

        description=(
            f"{alert_type} alert received from "
            f"device {device_id}."
        ),

        device_id=device_id,

        ward_id=assignment["ward_id"],

        bed_id=assignment["bed_id"],

        patient_id=assignment["patient_id"]
    )

    # --------------------------------------------------------
    # Notify desktop UI and sound/TTS
    # --------------------------------------------------------

    notify_alert(
        alert
    )

    print(
        "Patient alert processed successfully:",
        alert
    )

    return alert


# ============================================================
# PROCESS GENERAL SERIAL MESSAGE
# ============================================================

def process_serial_message(
    message
):
    """
    General entry point for serial_service.py.

    serial_service.py should call this function for every
    parsed message that it receives from the Hall Receiver.

    This function determines whether the message is:

        - patient alert
        - heartbeat
        - device status
        - acknowledgement
        - other communication

    Patient alerts are passed to process_patient_alert().
    """

    message = normalize_serial_message(
        message
    )

    if message is None:

        return None

    message_type = get_message_type(
        message
    )

    # --------------------------------------------------------
    # Patient alert
    # --------------------------------------------------------

    if message_type in (
        "PATIENT_ALERT",
        "PATIENT_CALL",
        "ASSISTANCE",
        "EMERGENCY",
        "CRITICAL",
        "CALL"
    ):

        return process_patient_alert(
            message
        )

    # --------------------------------------------------------
    # Some firmware sends alert_type without message_type.
    # --------------------------------------------------------

    if get_alert_type(message):

        return process_patient_alert(
            message
        )

    # --------------------------------------------------------
    # Device communication
    # --------------------------------------------------------

    device_id = get_device_id(
        message
    )

    if device_id:

        mark_device_online(
            device_id
        )

    # --------------------------------------------------------
    # Heartbeat
    # --------------------------------------------------------

    if message_type in (
        "HEARTBEAT",
        "PING",
        "STATUS",
        "DEVICE_STATUS"
    ):

        if device_id:

            add_system_log(

                event_type="DEVICE_HEARTBEAT",

                description=(
                    f"Heartbeat received from "
                    f"device {device_id}."
                ),

                device_id=device_id
            )

        return {
            "message_type": message_type,
            "device_id": device_id
        }

    # --------------------------------------------------------
    # Unknown/general message
    # --------------------------------------------------------

    if device_id:

        add_system_log(

            event_type="SERIAL_MESSAGE_RECEIVED",

            description=(
                f"Serial message received from "
                f"device {device_id}: "
                f"{message_type or 'UNKNOWN'}"
            ),

            device_id=device_id
        )

    else:

        add_system_log(

            event_type="SERIAL_MESSAGE_RECEIVED",

            description=(
                f"Serial message received: "
                f"{message_type or 'UNKNOWN'}"
            )
        )

    print(
        "General serial message:",
        message
    )

    return message


# ============================================================
# GET ACTIVE ALERTS
# ============================================================

def get_active_alerts():
    """
    Return all currently ACTIVE alerts.

    The database is the authoritative source.
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at

            FROM alerts

            WHERE alert_status = 'ACTIVE'

            ORDER BY datetime(created_at) ASC
            """
        )

        rows = cursor.fetchall()

        return [
            build_alert_dictionary(row)
            for row in rows
        ]

    finally:

        connection.close()


# ============================================================
# GET ALERT BY ID
# ============================================================

def get_alert(
    alert_id
):
    """
    Retrieve one alert by ID.
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at

            FROM alerts

            WHERE id = ?

            LIMIT 1
            """,
            (
                alert_id,
            )
        )

        row = cursor.fetchone()

        return build_alert_dictionary(
            row
        )

    finally:

        connection.close()


# ============================================================
# ATTEND ALERT
# ============================================================

def attend_alert(
    alert_id
):
    """
    Mark an ACTIVE alert as ATTENDED.

    attended_at is recorded automatically by the database
    service using the current application timestamp.
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at

            FROM alerts

            WHERE id = ?

            LIMIT 1
            """,
            (
                alert_id,
            )
        )

        row = cursor.fetchone()

        if row is None:

            return False, "Alert not found."

        if row["alert_status"] != "ACTIVE":

            return False, (
                f"Alert is already "
                f"{row['alert_status']}."
            )

        cursor.execute(
            """
            UPDATE alerts

            SET
                alert_status = 'ATTENDED',
                attended_at = CURRENT_TIMESTAMP

            WHERE id = ?
            """,
            (
                alert_id,
            )
        )

        connection.commit()

        alert = get_alert(
            alert_id
        )

    except Exception as error:

        connection.rollback()

        print(
            "Unable to attend alert:",
            error
        )

        return False, (
            f"Unable to attend alert: {error}"
        )

    finally:

        connection.close()

    # --------------------------------------------------------
    # Remove from active notification tracking
    # --------------------------------------------------------

    with _notification_lock:

        _active_alerts.pop(
            alert_id,
            None
        )

    # --------------------------------------------------------
    # Log
    # --------------------------------------------------------

    if alert:

        add_system_log(

            event_type="ALERT_ATTENDED",

            description=(
                f"Alert {alert_id} attended."
            ),

            device_id=alert["device_id"],

            ward_id=alert["ward_id"],

            bed_id=alert["bed_id"],

            patient_id=alert["patient_id"]
        )

        _notify_ui(
            alert
        )

    return True, (
        "Alert attended successfully."
    )


# ============================================================
# CANCEL ALERT
# ============================================================

def cancel_alert(
    alert_id
):
    """
    Mark an ACTIVE alert as CANCELLED.
    """

    connection = get_connection()

    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at

            FROM alerts

            WHERE id = ?

            LIMIT 1
            """,
            (
                alert_id,
            )
        )

        row = cursor.fetchone()

        if row is None:

            return False, "Alert not found."

        if row["alert_status"] != "ACTIVE":

            return False, (
                f"Alert is already "
                f"{row['alert_status']}."
            )

        cursor.execute(
            """
            UPDATE alerts

            SET
                alert_status = 'CANCELLED'

            WHERE id = ?
            """,
            (
                alert_id,
            )
        )

        connection.commit()

        alert = get_alert(
            alert_id
        )

    except Exception as error:

        connection.rollback()

        print(
            "Unable to cancel alert:",
            error
        )

        return False, (
            f"Unable to cancel alert: {error}"
        )

    finally:

        connection.close()

    # --------------------------------------------------------
    # Remove from repeat-notification list
    # --------------------------------------------------------

    with _notification_lock:

        _active_alerts.pop(
            alert_id,
            None
        )

    # --------------------------------------------------------
    # Log
    # --------------------------------------------------------

    if alert:

        add_system_log(

            event_type="ALERT_CANCELLED",

            description=(
                f"Alert {alert_id} cancelled."
            ),

            device_id=alert["device_id"],

            ward_id=alert["ward_id"],

            bed_id=alert["bed_id"],

            patient_id=alert["patient_id"]
        )

        _notify_ui(
            alert
        )

    return True, (
        "Alert cancelled successfully."
    )


# ============================================================
# REFRESH ACTIVE ALERT CACHE
# ============================================================

def refresh_active_alerts():
    """
    Synchronize the in-memory active-alert list with SQLite.
    """

    alerts = get_active_alerts()

    with _notification_lock:

        current_ids = set(
            _active_alerts.keys()
        )

        database_ids = {
            alert["id"]
            for alert in alerts
        }

        # ----------------------------------------------------
        # Add database alerts that are not in memory
        # ----------------------------------------------------

        for alert in alerts:

            if alert["id"] not in _active_alerts:

                _active_alerts[
                    alert["id"]
                ] = {
                    **alert,
                    "last_notification": 0
                }

        # ----------------------------------------------------
        # Remove alerts no longer active
        # ----------------------------------------------------

        for alert_id in (
            current_ids - database_ids
        ):

            _active_alerts.pop(
                alert_id,
                None
            )

    return alerts


# ============================================================
# REPEAT ACTIVE ALERT NOTIFICATIONS
# ============================================================

def _notification_loop():
    """
    Background notification loop.

    Repeats notifications for active alerts according to
    configured timing.
    """

    while not _stop_event.is_set():

        try:

            settings = (
                get_notification_sound_settings()
            )

            repeat_enabled = settings.get(
                "repeat_sound",
                True
            )

            repeat_interval = int(
                settings.get(
                    "repeat_interval",
                    5
                )
            )

            if repeat_interval <= 0:

                repeat_interval = 5

            # ------------------------------------------------
            # Keep cache synchronized
            # ------------------------------------------------

            refresh_active_alerts()

            if repeat_enabled:

                now = time.time()

                alerts_to_notify = []

                with _notification_lock:

                    for alert_id, alert in (
                        _active_alerts.items()
                    ):

                        last_notification = (
                            alert.get(
                                "last_notification",
                                0
                            )
                        )

                        if (
                            now
                            - last_notification
                            >= repeat_interval
                        ):

                            alert[
                                "last_notification"
                            ] = now

                            alerts_to_notify.append(
                                dict(alert)
                            )

                # --------------------------------------------
                # Notify outside lock
                # --------------------------------------------

                for alert in alerts_to_notify:

                    notify_alert(
                        alert
                    )

        except Exception as error:

            print(
                "Notification background loop error:",
                error
            )

        _stop_event.wait(
            1
        )


# ============================================================
# START NOTIFICATION SERVICE
# ============================================================

def start_notification_service():
    """
    Start background notification processing.

    This does NOT start serial communication.

    serial_service.py remains responsible for serial ports.
    """

    global _notification_running
    global _notification_thread

    with _notification_lock:

        if _notification_running:

            print(
                "Notification service is already running."
            )

            return _notification_thread

        initialize_notification_service()

        _stop_event.clear()

        _notification_running = True

        _notification_thread = threading.Thread(
            target=_notification_loop,
            name="NotificationService",
            daemon=True
        )

        _notification_thread.start()

    print(
        "Notification service started."
    )

    return _notification_thread


# ============================================================
# STOP NOTIFICATION SERVICE
# ============================================================

def stop_notification_service():
    """
    Stop background notification processing.

    This does NOT stop serial communication because serial
    communication belongs to serial_service.py.
    """

    global _notification_running
    global _notification_thread

    with _notification_lock:

        if not _notification_running:

            return

        _stop_event.set()

        thread = _notification_thread

        _notification_running = False

        _notification_thread = None

    if thread is not None:

        thread.join(
            timeout=3
        )

    print(
        "Notification service stopped."
    )


# ============================================================
# SERVICE STATUS
# ============================================================

def get_notification_service_status():
    """
    Return notification service status.
    """

    with _notification_lock:

        return {

            "service": SERVICE_NAME,

            "version": SERVICE_VERSION,

            "running": _notification_running,

            "active_alerts": len(
                _active_alerts
            ),

            "timestamp": (
                datetime.now().isoformat()
            )
        }


# ============================================================
# SERIAL SERVICE INTEGRATION
# ============================================================
#
# The future serial_service.py can use these functions:
#
#     notification_service.process_serial_message(message)
#
# or directly:
#
#     notification_service.process_patient_alert(message)
#
#
# Example:
#
#     from services.notification_service import (
#         process_serial_message
#     )
#
#     process_serial_message(
#         {
#             "message_type": "PATIENT_ALERT",
#             "device_id": "PATIENT-001",
#             "alert_type": "EMERGENCY"
#         }
#     )
#
# serial_service.py should NOT:
#
#     INSERT INTO alerts
#
#     UPDATE alerts
#
#     create patient assignments
#
#     create duplicate notifications
#
# Those responsibilities belong here.
# ============================================================


# ============================================================
# CONNECTION EVENTS FROM SERIAL SERVICE
# ============================================================

def handle_device_connected(
    device_id
):
    """
    Called by serial_service.py when a registered ESP32
    connection becomes available.
    """

    device_id = str(
        device_id
    ).strip()

    if not device_id:

        return False

    updated = mark_device_online(
        device_id
    )

    add_system_log(

        event_type="DEVICE_CONNECTED",

        description=(
            f"Patient device {device_id} connected."
        ),

        device_id=device_id
    )

    return updated


# ============================================================
# DEVICE DISCONNECTED
# ============================================================

def handle_device_disconnected(
    device_id
):
    """
    Called by serial_service.py when a patient device
    connection is lost.
    """

    device_id = str(
        device_id
    ).strip()

    if not device_id:

        return False

    updated = mark_device_offline(
        device_id
    )

    add_system_log(

        event_type="DEVICE_DISCONNECTED",

        description=(
            f"Patient device {device_id} disconnected."
        ),

        device_id=device_id
    )

    return updated


# ============================================================
# HALL RECEIVER CONNECTED
# ============================================================

def handle_hall_receiver_connected():
    """
    Called by serial_service.py when the Hall Receiver
    ESP32 connects through USB.
    """

    add_system_log(

        event_type="HALL_RECEIVER_CONNECTED",

        description=(
            "Hall Receiver ESP32 connected through USB."
        )
    )

    return True


# ============================================================
# HALL RECEIVER DISCONNECTED
# ============================================================

def handle_hall_receiver_disconnected():
    """
    Called by serial_service.py when the Hall Receiver
    ESP32 disconnects from USB.
    """

    add_system_log(

        event_type="HALL_RECEIVER_DISCONNECTED",

        description=(
            "Hall Receiver ESP32 disconnected from USB."
        )
    )

    return True


# ============================================================
# CLEAR ALL ACTIVE ALERTS
# ============================================================

def clear_active_alert_cache():
    """
    Clear only the in-memory notification cache.

    This does NOT change the database.

    Database alerts must be attended or cancelled using:

        attend_alert()
        cancel_alert()
    """

    with _notification_lock:

        _active_alerts.clear()


# ============================================================
# SERVICE SHUTDOWN
# ============================================================

def shutdown_notification_service():
    """
    Cleanly stop the notification service.
    """

    stop_notification_service()

    clear_active_alert_cache()

    print(
        "Notification service shutdown complete."
    )


# ============================================================
# TEST MESSAGE
# ============================================================

def test_notification(
    device_id="TEST-DEVICE",
    alert_type="ASSISTANCE"
):
    """
    Test notification processing.

    IMPORTANT:
    The supplied device must already exist in the database
    and have a valid device assignment if this function is
    expected to create a real alert.
    """

    message = {

        "message_type": "PATIENT_ALERT",

        "device_id": device_id,

        "alert_type": alert_type

    }

    return process_patient_alert(
        message
    )


# ============================================================
# DIRECT TEST
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        APP_NAME
    )

    print(
        "NOTIFICATION SERVICE"
    )

    print(
        "=============================================="
    )

    initialize_notification_service()

    print(
        "Notification service initialized."
    )

    print(
        "Service status:"
    )

    print(
        get_notification_service_status()
    )

    print(
        "Active alerts:"
    )

    print(
        get_active_alerts()
    )

    print(
        "=============================================="
    )
