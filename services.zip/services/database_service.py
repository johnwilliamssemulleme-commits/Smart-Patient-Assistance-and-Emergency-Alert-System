# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# DATABASE SERVICE
# ============================================================
#
# Responsibility:
#
#     Other backend services
#             ↓
#     database_service.py
#             ↓
#     models.py
#             ↓
#     SQLite database
#
# This service is responsible ONLY for database operations.
#
# It does NOT:
#     - communicate with ESP32
#     - communicate through serial
#     - parse LoRa packets
#     - read COM ports
#     - process raw sensor data
#     - implement alert detection logic
#     - implement authentication logic
#
# serial_service.py will provide already interpreted data to
# the appropriate service/database operation.
#
# ============================================================


from datetime import datetime

from models import (
    get_connection,
    create_database,
    get_database_path,
)


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

def initialize_database():
    """
    Create the database and all required tables.

    Safe to call multiple times because the database model uses
    CREATE TABLE IF NOT EXISTS.
    """

    create_database()


# ============================================================
# INTERNAL HELPERS
# ============================================================

def _now():
    """
    Return the current local date/time as a string.

    This is used when an operation needs to explicitly update
    updated_at or attended_at.
    """

    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


def _execute(
    query,
    parameters=(),
    fetchone=False,
    fetchall=False,
    commit=False,
):
    """
    Internal database execution helper.

    This keeps connection handling in one place.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            query,
            parameters
        )

        if commit:
            connection.commit()

        if fetchone:
            return cursor.fetchone()

        if fetchall:
            return cursor.fetchall()

        return cursor

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


# ============================================================
# ADMIN
# ============================================================

def create_admin(
    username,
    password_hash,
    recovery_key_hash,
):
    """
    Create an administrator account.

    Returns:
        admin_id
    """

    query = """
        INSERT INTO admin (
            username,
            password_hash,
            recovery_key_hash
        )
        VALUES (?, ?, ?)
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            query,
            (
                username,
                password_hash,
                recovery_key_hash,
            )
        )

        connection.commit()

        return cursor.lastrowid

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def get_admin_by_username(username):
    """
    Retrieve an administrator using username.

    Returns:
        sqlite3.Row or None
    """

    return _execute(
        """
        SELECT *
        FROM admin
        WHERE username = ?
        LIMIT 1
        """,
        (username,),
        fetchone=True,
    )


def get_admin_by_id(admin_id):
    """
    Retrieve an administrator by ID.
    """

    return _execute(
        """
        SELECT *
        FROM admin
        WHERE admin_id = ?
        LIMIT 1
        """,
        (admin_id,),
        fetchone=True,
    )


def update_admin_password(
    admin_id,
    password_hash,
):
    """
    Update an administrator password hash.
    """

    _execute(
        """
        UPDATE admin
        SET
            password_hash = ?,
            updated_at = ?
        WHERE admin_id = ?
        """,
        (
            password_hash,
            _now(),
            admin_id,
        ),
        commit=True,
    )


def update_admin_recovery_key(
    admin_id,
    recovery_key_hash,
):
    """
    Update an administrator recovery-key hash.
    """

    _execute(
        """
        UPDATE admin
        SET
            recovery_key_hash = ?,
            updated_at = ?
        WHERE admin_id = ?
        """,
        (
            recovery_key_hash,
            _now(),
            admin_id,
        ),
        commit=True,
    )


def get_admin_count():
    """
    Return the number of administrators.
    """

    row = _execute(
        """
        SELECT COUNT(*) AS count
        FROM admin
        """,
        fetchone=True,
    )

    return row["count"]


# ============================================================
# WARDS
# ============================================================

def create_ward(
    ward_id,
    ward_type,
):
    """
    Create a ward.
    """

    _execute(
        """
        INSERT INTO wards (
            ward_id,
            ward_type
        )
        VALUES (?, ?)
        """,
        (
            ward_id,
            ward_type,
        ),
        commit=True,
    )


def get_ward(ward_id):
    """
    Retrieve one ward.
    """

    return _execute(
        """
        SELECT *
        FROM wards
        WHERE ward_id = ?
        LIMIT 1
        """,
        (ward_id,),
        fetchone=True,
    )


def get_all_wards():
    """
    Retrieve all wards.
    """

    return _execute(
        """
        SELECT *
        FROM wards
        ORDER BY ward_id
        """,
        fetchall=True,
    )


def update_ward(
    ward_id,
    ward_type,
):
    """
    Update ward type.
    """

    _execute(
        """
        UPDATE wards
        SET ward_type = ?
        WHERE ward_id = ?
        """,
        (
            ward_type,
            ward_id,
        ),
        commit=True,
    )


def delete_ward(ward_id):
    """
    Delete a ward.

    Foreign-key restrictions will prevent deletion when
    dependent records still exist.
    """

    _execute(
        """
        DELETE FROM wards
        WHERE ward_id = ?
        """,
        (ward_id,),
        commit=True,
    )


# ============================================================
# BEDS
# ============================================================

def create_bed(
    bed_id,
    ward_id,
    status="Available",
):
    """
    Create a bed.
    """

    _execute(
        """
        INSERT INTO beds (
            bed_id,
            ward_id,
            status
        )
        VALUES (?, ?, ?)
        """,
        (
            bed_id,
            ward_id,
            status,
        ),
        commit=True,
    )


def get_bed(bed_id):
    """
    Retrieve one bed.
    """

    return _execute(
        """
        SELECT *
        FROM beds
        WHERE bed_id = ?
        LIMIT 1
        """,
        (bed_id,),
        fetchone=True,
    )


def get_all_beds():
    """
    Retrieve all beds.
    """

    return _execute(
        """
        SELECT *
        FROM beds
        ORDER BY bed_id
        """,
        fetchall=True,
    )


def get_beds_by_ward(ward_id):
    """
    Retrieve all beds belonging to a ward.
    """

    return _execute(
        """
        SELECT *
        FROM beds
        WHERE ward_id = ?
        ORDER BY bed_id
        """,
        (ward_id,),
        fetchall=True,
    )


def get_beds_by_status(status):
    """
    Retrieve beds by status.
    """

    return _execute(
        """
        SELECT *
        FROM beds
        WHERE status = ?
        ORDER BY bed_id
        """,
        (status,),
        fetchall=True,
    )


def update_bed_status(
    bed_id,
    status,
):
    """
    Update the status of a bed.
    """

    _execute(
        """
        UPDATE beds
        SET status = ?
        WHERE bed_id = ?
        """,
        (
            status,
            bed_id,
        ),
        commit=True,
    )


def update_bed_ward(
    bed_id,
    ward_id,
):
    """
    Move a bed to another ward.
    """

    _execute(
        """
        UPDATE beds
        SET ward_id = ?
        WHERE bed_id = ?
        """,
        (
            ward_id,
            bed_id,
        ),
        commit=True,
    )


def delete_bed(bed_id):
    """
    Delete a bed.

    Foreign-key restrictions will prevent deletion when
    dependent records still exist.
    """

    _execute(
        """
        DELETE FROM beds
        WHERE bed_id = ?
        """,
        (bed_id,),
        commit=True,
    )


# ============================================================
# PATIENTS
# ============================================================

def create_patient(patient_id):
    """
    Create a patient record.
    """

    _execute(
        """
        INSERT INTO patients (
            patient_id
        )
        VALUES (?)
        """,
        (patient_id,),
        commit=True,
    )


def get_patient(patient_id):
    """
    Retrieve one patient.
    """

    return _execute(
        """
        SELECT *
        FROM patients
        WHERE patient_id = ?
        LIMIT 1
        """,
        (patient_id,),
        fetchone=True,
    )


def get_all_patients():
    """
    Retrieve all patients.
    """

    return _execute(
        """
        SELECT *
        FROM patients
        ORDER BY patient_id
        """,
        fetchall=True,
    )


def delete_patient(patient_id):
    """
    Delete a patient.

    Existing assignments/alerts may prevent deletion or cause
    referenced values to become NULL according to the schema.
    """

    _execute(
        """
        DELETE FROM patients
        WHERE patient_id = ?
        """,
        (patient_id,),
        commit=True,
    )


# ============================================================
# STAFF
# ============================================================

def create_staff(staff_id):
    """
    Create a staff record.
    """

    _execute(
        """
        INSERT INTO staff (
            staff_id
        )
        VALUES (?)
        """,
        (staff_id,),
        commit=True,
    )


def get_staff(staff_id):
    """
    Retrieve one staff member.
    """

    return _execute(
        """
        SELECT *
        FROM staff
        WHERE staff_id = ?
        LIMIT 1
        """,
        (staff_id,),
        fetchone=True,
    )


def get_all_staff():
    """
    Retrieve all staff.
    """

    return _execute(
        """
        SELECT *
        FROM staff
        ORDER BY staff_id
        """,
        fetchall=True,
    )


def delete_staff(staff_id):
    """
    Delete a staff record.
    """

    _execute(
        """
        DELETE FROM staff
        WHERE staff_id = ?
        """,
        (staff_id,),
        commit=True,
    )


# ============================================================
# PATIENT ASSIGNMENTS
# ============================================================

def assign_patient(
    bed_id,
    patient_id,
    staff_id,
):
    """
    Assign a patient and responsible staff member to a bed.

    The database schema already guarantees:
        - one patient per bed
        - one bed per patient
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            INSERT INTO patient_assignments (
                bed_id,
                patient_id,
                staff_id
            )
            VALUES (?, ?, ?)
            """,
            (
                bed_id,
                patient_id,
                staff_id,
            )
        )

        cursor.execute(
            """
            UPDATE beds
            SET status = 'Occupied'
            WHERE bed_id = ?
            """,
            (bed_id,)
        )

        connection.commit()

        return cursor.lastrowid

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def get_patient_assignment_by_bed(bed_id):
    """
    Retrieve the active patient assignment for a bed.
    """

    return _execute(
        """
        SELECT
            pa.id,
            pa.bed_id,
            pa.patient_id,
            pa.staff_id,
            pa.created_at,
            pa.updated_at,
            b.ward_id,
            b.status AS bed_status
        FROM patient_assignments pa
        JOIN beds b
            ON b.bed_id = pa.bed_id
        WHERE pa.bed_id = ?
        LIMIT 1
        """,
        (bed_id,),
        fetchone=True,
    )


def get_patient_assignment_by_patient(patient_id):
    """
    Retrieve the assignment for a patient.
    """

    return _execute(
        """
        SELECT
            pa.id,
            pa.bed_id,
            pa.patient_id,
            pa.staff_id,
            pa.created_at,
            pa.updated_at,
            b.ward_id,
            b.status AS bed_status
        FROM patient_assignments pa
        JOIN beds b
            ON b.bed_id = pa.bed_id
        WHERE pa.patient_id = ?
        LIMIT 1
        """,
        (patient_id,),
        fetchone=True,
    )


def get_all_patient_assignments():
    """
    Retrieve all patient assignments.
    """

    return _execute(
        """
        SELECT
            pa.id,
            pa.bed_id,
            pa.patient_id,
            pa.staff_id,
            pa.created_at,
            pa.updated_at,
            b.ward_id,
            b.status AS bed_status
        FROM patient_assignments pa
        JOIN beds b
            ON b.bed_id = pa.bed_id
        ORDER BY pa.created_at DESC
        """,
        fetchall=True,
    )


def update_patient_assignment(
    bed_id,
    patient_id,
    staff_id,
):
    """
    Update the patient/staff assignment for a bed.
    """

    _execute(
        """
        UPDATE patient_assignments
        SET
            patient_id = ?,
            staff_id = ?,
            updated_at = ?
        WHERE bed_id = ?
        """,
        (
            patient_id,
            staff_id,
            _now(),
            bed_id,
        ),
        commit=True,
    )


def remove_patient_assignment(bed_id):
    """
    Remove the patient assignment from a bed.

    The bed is returned to Available status.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            DELETE FROM patient_assignments
            WHERE bed_id = ?
            """,
            (bed_id,)
        )

        cursor.execute(
            """
            UPDATE beds
            SET status = 'Available'
            WHERE bed_id = ?
            """,
            (bed_id,)
        )

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


# ============================================================
# DEVICES
# ============================================================

def create_device(
    device_id,
    status="Offline",
):
    """
    Register a device.
    """

    _execute(
        """
        INSERT INTO devices (
            device_id,
            status
        )
        VALUES (?, ?)
        """,
        (
            device_id,
            status,
        ),
        commit=True,
    )


def get_device(device_id):
    """
    Retrieve one device.
    """

    return _execute(
        """
        SELECT *
        FROM devices
        WHERE device_id = ?
        LIMIT 1
        """,
        (device_id,),
        fetchone=True,
    )


def get_all_devices():
    """
    Retrieve all devices.
    """

    return _execute(
        """
        SELECT *
        FROM devices
        ORDER BY device_id
        """,
        fetchall=True,
    )


def update_device_status(
    device_id,
    status,
):
    """
    Update a device's status.
    """

    _execute(
        """
        UPDATE devices
        SET
            status = ?
        WHERE device_id = ?
        """,
        (
            status,
            device_id,
        ),
        commit=True,
    )


def update_device_last_seen(
    device_id,
    last_seen=None,
):
    """
    Update the last_seen value for a device.

    If last_seen is omitted, the current application time is
    used.

    This function does not communicate with the device.
    """

    if last_seen is None:
        last_seen = _now()

    _execute(
        """
        UPDATE devices
        SET
            last_seen = ?
        WHERE device_id = ?
        """,
        (
            last_seen,
            device_id,
        ),
        commit=True,
    )


def set_device_online(
    device_id,
    last_seen=None,
):
    """
    Mark a device as Online and update last_seen.
    """

    if last_seen is None:
        last_seen = _now()

    _execute(
        """
        UPDATE devices
        SET
            status = 'Online',
            last_seen = ?
        WHERE device_id = ?
        """,
        (
            last_seen,
            device_id,
        ),
        commit=True,
    )


def set_device_offline(device_id):
    """
    Mark a device as Offline.
    """

    update_device_status(
        device_id,
        "Offline",
    )


def delete_device(device_id):
    """
    Delete a device.
    """

    _execute(
        """
        DELETE FROM devices
        WHERE device_id = ?
        """,
        (device_id,),
        commit=True,
    )


# ============================================================
# DEVICE ASSIGNMENTS
# ============================================================

def assign_device(
    device_id,
    ward_id,
    bed_id,
):
    """
    Assign a device to a ward and bed.

    The database schema guarantees:
        - one device cannot have multiple assignments
        - one bed cannot have multiple devices
    """

    _execute(
        """
        INSERT INTO device_assignments (
            device_id,
            ward_id,
            bed_id
        )
        VALUES (?, ?, ?)
        """,
        (
            device_id,
            ward_id,
            bed_id,
        ),
        commit=True,
    )


def get_device_assignment(device_id):
    """
    Retrieve assignment information for a device.
    """

    return _execute(
        """
        SELECT
            da.id,
            da.device_id,
            da.ward_id,
            da.bed_id,
            da.created_at,
            da.updated_at
        FROM device_assignments da
        WHERE da.device_id = ?
        LIMIT 1
        """,
        (device_id,),
        fetchone=True,
    )


def get_device_assignment_by_bed(bed_id):
    """
    Retrieve the device assigned to a bed.
    """

    return _execute(
        """
        SELECT
            da.id,
            da.device_id,
            da.ward_id,
            da.bed_id,
            da.created_at,
            da.updated_at
        FROM device_assignments da
        WHERE da.bed_id = ?
        LIMIT 1
        """,
        (bed_id,),
        fetchone=True,
    )


def get_all_device_assignments():
    """
    Retrieve all device assignments.
    """

    return _execute(
        """
        SELECT
            da.id,
            da.device_id,
            da.ward_id,
            da.bed_id,
            da.created_at,
            da.updated_at
        FROM device_assignments da
        ORDER BY da.created_at DESC
        """,
        fetchall=True,
    )


def update_device_assignment(
    device_id,
    ward_id,
    bed_id,
):
    """
    Update the ward and bed assigned to a device.
    """

    _execute(
        """
        UPDATE device_assignments
        SET
            ward_id = ?,
            bed_id = ?,
            updated_at = ?
        WHERE device_id = ?
        """,
        (
            ward_id,
            bed_id,
            _now(),
            device_id,
        ),
        commit=True,
    )


def remove_device_assignment(device_id):
    """
    Remove a device assignment.
    """

    _execute(
        """
        DELETE FROM device_assignments
        WHERE device_id = ?
        """,
        (device_id,),
        commit=True,
    )


# ============================================================
# ALERTS
# ============================================================

def create_alert(
    alert_type,
    device_id=None,
    ward_id=None,
    bed_id=None,
    patient_id=None,
    staff_id=None,
    alert_status="ACTIVE",
):
    """
    Store an alert.

    IMPORTANT:
        This function does not determine whether something is
        an alert.

        Alert detection/business logic belongs elsewhere.

        The caller supplies the already determined alert_type
        and associated IDs.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            INSERT INTO alerts (
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
            )
        )

        connection.commit()

        return cursor.lastrowid

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def get_alert(alert_id):
    """
    Retrieve one alert.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE id = ?
        LIMIT 1
        """,
        (alert_id,),
        fetchone=True,
    )


def get_all_alerts():
    """
    Retrieve all alerts.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        ORDER BY created_at DESC
        """,
        fetchall=True,
    )


def get_active_alerts():
    """
    Retrieve all active alerts.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE alert_status = 'ACTIVE'
        ORDER BY created_at DESC
        """,
        fetchall=True,
    )


def get_alerts_by_status(alert_status):
    """
    Retrieve alerts by status.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE alert_status = ?
        ORDER BY created_at DESC
        """,
        (
            alert_status,
        ),
        fetchall=True,
    )


def get_alerts_by_type(alert_type):
    """
    Retrieve alerts by type.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE alert_type = ?
        ORDER BY created_at DESC
        """,
        (
            alert_type,
        ),
        fetchall=True,
    )


def get_alerts_by_ward(ward_id):
    """
    Retrieve alerts for a ward.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE ward_id = ?
        ORDER BY created_at DESC
        """,
        (
            ward_id,
        ),
        fetchall=True,
    )


def get_alerts_by_bed(bed_id):
    """
    Retrieve alerts for a bed.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE bed_id = ?
        ORDER BY created_at DESC
        """,
        (
            bed_id,
        ),
        fetchall=True,
    )


def get_alerts_by_device(device_id):
    """
    Retrieve alerts generated by a device.
    """

    return _execute(
        """
        SELECT *
        FROM alerts
        WHERE device_id = ?
        ORDER BY created_at DESC
        """,
        (
            device_id,
        ),
        fetchall=True,
    )


def attend_alert(alert_id):
    """
    Mark an alert as attended.

    The alert remains in the database for history.
    """

    _execute(
        """
        UPDATE alerts
        SET
            alert_status = 'ATTENDED',
            attended_at = ?
        WHERE id = ?
        """,
        (
            _now(),
            alert_id,
        ),
        commit=True,
    )


def resolve_alert(alert_id):
    """
    Mark an alert as resolved.

    This keeps the alert record for historical reporting.
    """

    _execute(
        """
        UPDATE alerts
        SET
            alert_status = 'RESOLVED',
            attended_at = COALESCE(attended_at, ?)
        WHERE id = ?
        """,
        (
            _now(),
            alert_id,
        ),
        commit=True,
    )


def update_alert_status(
    alert_id,
    alert_status,
):
    """
    Update alert status without implementing any alert logic.
    """

    _execute(
        """
        UPDATE alerts
        SET
            alert_status = ?
        WHERE id = ?
        """,
        (
            alert_status,
            alert_id,
        ),
        commit=True,
    )


def delete_alert(alert_id):
    """
    Delete an alert.
    """

    _execute(
        """
        DELETE FROM alerts
        WHERE id = ?
        """,
        (alert_id,),
        commit=True,
    )


# ============================================================
# SYSTEM LOGS
# ============================================================

def create_system_log(
    event_type,
    description,
    device_id=None,
    ward_id=None,
    bed_id=None,
    patient_id=None,
):
    """
    Create a system log entry.

    This function only stores the event supplied by the caller.
    It does not determine what the event means.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            INSERT INTO system_logs (
                event_type,
                description,
                device_id,
                ward_id,
                bed_id,
                patient_id
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                event_type,
                description,
                device_id,
                ward_id,
                bed_id,
                patient_id,
            )
        )

        connection.commit()

        return cursor.lastrowid

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def get_system_log(log_id):
    """
    Retrieve one system log.
    """

    return _execute(
        """
        SELECT *
        FROM system_logs
        WHERE id = ?
        LIMIT 1
        """,
        (log_id,),
        fetchone=True,
    )


def get_all_system_logs():
    """
    Retrieve all system logs.
    """

    return _execute(
        """
        SELECT *
        FROM system_logs
        ORDER BY created_at DESC
        """,
        fetchall=True,
    )


def get_system_logs_by_event_type(event_type):
    """
    Retrieve system logs by event type.
    """

    return _execute(
        """
        SELECT *
        FROM system_logs
        WHERE event_type = ?
        ORDER BY created_at DESC
        """,
        (
            event_type,
        ),
        fetchall=True,
    )


def get_system_logs_by_device(device_id):
    """
    Retrieve logs associated with a device.
    """

    return _execute(
        """
        SELECT *
        FROM system_logs
        WHERE device_id = ?
        ORDER BY created_at DESC
        """,
        (
            device_id,
        ),
        fetchall=True,
    )


def get_system_logs_by_bed(bed_id):
    """
    Retrieve logs associated with a bed.
    """

    return _execute(
        """
        SELECT *
        FROM system_logs
        WHERE bed_id = ?
        ORDER BY created_at DESC
        """,
        (
            bed_id,
        ),
        fetchall=True,
    )


# ============================================================
# DASHBOARD / SUMMARY QUERIES
# ============================================================

def get_bed_summary():
    """
    Return basic bed statistics.
    """

    return _execute(
        """
        SELECT
            COUNT(*) AS total_beds,
            SUM(
                CASE
                    WHEN status = 'Available'
                    THEN 1
                    ELSE 0
                END
            ) AS available_beds,
            SUM(
                CASE
                    WHEN status = 'Occupied'
                    THEN 1
                    ELSE 0
                END
            ) AS occupied_beds
        FROM beds
        """,
        fetchone=True,
    )


def get_device_summary():
    """
    Return basic device statistics.
    """

    return _execute(
        """
        SELECT
            COUNT(*) AS total_devices,
            SUM(
                CASE
                    WHEN status = 'Online'
                    THEN 1
                    ELSE 0
                END
            ) AS online_devices,
            SUM(
                CASE
                    WHEN status = 'Offline'
                    THEN 1
                    ELSE 0
                END
            ) AS offline_devices
        FROM devices
        """,
        fetchone=True,
    )


def get_alert_summary():
    """
    Return basic alert statistics.
    """

    return _execute(
        """
        SELECT
            COUNT(*) AS total_alerts,
            SUM(
                CASE
                    WHEN alert_status = 'ACTIVE'
                    THEN 1
                    ELSE 0
                END
            ) AS active_alerts,
            SUM(
                CASE
                    WHEN alert_status = 'ATTENDED'
                    THEN 1
                    ELSE 0
                END
            ) AS attended_alerts,
            SUM(
                CASE
                    WHEN alert_status = 'RESOLVED'
                    THEN 1
                    ELSE 0
                END
            ) AS resolved_alerts
        FROM alerts
        """,
        fetchone=True,
    )


def get_dashboard_summary():
    """
    Return the main database statistics required by a
    dashboard.

    No sensor processing is performed here.
    """

    bed_summary = get_bed_summary()
    device_summary = get_device_summary()
    alert_summary = get_alert_summary()

    return {
        "beds": dict(bed_summary),
        "devices": dict(device_summary),
        "alerts": dict(alert_summary),
    }


# ============================================================
# PATIENT / BED / DEVICE INFORMATION
# ============================================================

def get_bed_patient_information(bed_id):
    """
    Retrieve combined information about:

        bed
        ward
        patient
        assigned staff
        assigned device
    """

    return _execute(
        """
        SELECT
            b.bed_id,
            b.status AS bed_status,
            b.ward_id,
            w.ward_type,

            pa.patient_id,
            pa.staff_id,

            da.device_id,

            d.status AS device_status,
            d.last_seen

        FROM beds b

        LEFT JOIN wards w
            ON w.ward_id = b.ward_id

        LEFT JOIN patient_assignments pa
            ON pa.bed_id = b.bed_id

        LEFT JOIN device_assignments da
            ON da.bed_id = b.bed_id

        LEFT JOIN devices d
            ON d.device_id = da.device_id

        WHERE b.bed_id = ?

        LIMIT 1
        """,
        (
            bed_id,
        ),
        fetchone=True,
    )


def get_device_patient_information(device_id):
    """
    Retrieve combined information about a device and the
    patient/bed to which it is assigned.
    """

    return _execute(
        """
        SELECT
            d.device_id,
            d.status AS device_status,
            d.last_seen,

            da.ward_id,
            da.bed_id,

            pa.patient_id,
            pa.staff_id

        FROM devices d

        LEFT JOIN device_assignments da
            ON da.device_id = d.device_id

        LEFT JOIN patient_assignments pa
            ON pa.bed_id = da.bed_id

        WHERE d.device_id = ?

        LIMIT 1
        """,
        (
            device_id,
        ),
        fetchone=True,
    )


# ============================================================
# DATABASE MAINTENANCE
# ============================================================

def database_exists():
    """
    Return True if the SQLite database file exists.
    """

    return get_database_path().exists()


def get_table_names():
    """
    Return all database table names.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
            ORDER BY name
            """
        )

        rows = cursor.fetchall()

        return [
            row["name"]
            for row in rows
        ]

    finally:
        connection.close()


def clear_all_alerts():
    """
    Delete all alert records.

    Intended primarily for development/testing.

    Use carefully because this permanently removes alert
    history.
    """

    _execute(
        """
        DELETE FROM alerts
        """,
        commit=True,
    )


def clear_all_system_logs():
    """
    Delete all system logs.

    Intended primarily for development/testing.
    """

    _execute(
        """
        DELETE FROM system_logs
        """,
        commit=True,
    )


# ============================================================
# DATABASE HEALTH CHECK
# ============================================================

def database_health_check():
    """
    Verify that the database can be opened and queried.

    Returns:
        True if successful.
        False if an exception occurs.
    """

    connection = None

    try:
        connection = get_connection()

        cursor = connection.cursor()

        cursor.execute(
            "SELECT 1"
        )

        cursor.fetchone()

        return True

    except Exception:
        return False

    finally:
        if connection is not None:
            connection.close()


# ============================================================
# TEST / DIRECT EXECUTION
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        "SMART PATIENT ASSISTANCE AND "
        "EMERGENCY ALERT SYSTEM"
    )

    print(
        "DATABASE SERVICE TEST"
    )

    print(
        "=============================================="
    )

    # --------------------------------------------------------
    # Initialize database
    # --------------------------------------------------------

    initialize_database()

    print(
        "\nDatabase initialized successfully."
    )

    # --------------------------------------------------------
    # Database path
    # --------------------------------------------------------

    print(
        "\nDatabase:"
    )

    print(
        get_database_path()
    )

    # --------------------------------------------------------
    # Database health
    # --------------------------------------------------------

    print(
        "\nDatabase health:"
    )

    if database_health_check():
        print(
            "  OK"
        )
    else:
        print(
            "  FAILED"
        )

    # --------------------------------------------------------
    # Tables
    # --------------------------------------------------------

    print(
        "\nTables:"
    )

    for table in get_table_names():
        print(
            f"  - {table}"
        )

    # --------------------------------------------------------
    # Dashboard summary
    # --------------------------------------------------------

    print(
        "\nDashboard summary:"
    )

    summary = get_dashboard_summary()

    print(
        f"  Beds: {summary['beds']}"
    )

    print(
        f"  Devices: {summary['devices']}"
    )

    print(
        f"  Alerts: {summary['alerts']}"
    )

    print(
        "\n=============================================="
    )