# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# PATIENT SERVICE
# ============================================================

"""
RESPONSIBILITY:

Patient management only.

This service handles:

    Patient
        ↓
      Bed
        ↓
     Staff

It does NOT handle:

- ESP32 serial communication
- Hall Receiver communication
- LoRa communication
- Sensor data
- Device communication status
- Patient alerts received from SerialService

Serial communication is handled exclusively by:

    services.serial_service.SerialService

Database structure is handled by:

    models.py
"""

import sqlite3

from models import get_connection


# ============================================================
# PATIENT SERVICE
# ============================================================

class PatientService:
    """
    Service responsible for patient management.

    The service works with the existing database tables:

        patients
        staff
        beds
        wards
        patient_assignments

    It does not communicate directly with ESP32 devices.
    """

    # ========================================================
    # ASSIGN PATIENT TO BED
    # ========================================================

    @staticmethod
    def assign_patient_to_bed(
        bed_id,
        patient_id,
        staff_id
    ):
        """
        Assign a patient and nurse/doctor to a bed.

        Rules:

            - Bed must exist.
            - Patient must exist.
            - Staff member must exist.
            - Patient cannot occupy two beds.
            - One bed can have only one patient.
            - Bed becomes Occupied after assignment.

        Returns:

            (True, success_message)

        or:

            (False, error_message)
        """

        bed_id = str(bed_id).strip()
        patient_id = str(patient_id).strip()
        staff_id = str(staff_id).strip()

        # ----------------------------------------------------
        # VALIDATION
        # ----------------------------------------------------

        if not bed_id:
            return False, "Bed ID is required."

        if not patient_id:
            return False, "Patient ID is required."

        if not staff_id:
            return False, "Nurse / Doctor ID is required."

        connection = get_connection()
        cursor = connection.cursor()

        try:

            # ------------------------------------------------
            # CHECK BED
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    bed_id,
                    ward_id,
                    status
                FROM beds
                WHERE bed_id = ?
                """,
                (bed_id,)
            )

            bed = cursor.fetchone()

            if bed is None:
                return False, "Bed ID does not exist."

            # ------------------------------------------------
            # CHECK PATIENT
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT patient_id
                FROM patients
                WHERE patient_id = ?
                """,
                (patient_id,)
            )

            if cursor.fetchone() is None:
                return False, "Patient ID does not exist."

            # ------------------------------------------------
            # CHECK STAFF
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT staff_id
                FROM staff
                WHERE staff_id = ?
                """,
                (staff_id,)
            )

            if cursor.fetchone() is None:
                return False, "Nurse / Doctor ID does not exist."

            # ------------------------------------------------
            # CHECK WHETHER PATIENT IS ALREADY ASSIGNED
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    bed_id
                FROM patient_assignments
                WHERE patient_id = ?
                  AND bed_id != ?
                """,
                (
                    patient_id,
                    bed_id
                )
            )

            existing_patient_assignment = cursor.fetchone()

            if existing_patient_assignment is not None:
                return (
                    False,
                    "This patient is already assigned to another bed."
                )

            # ------------------------------------------------
            # CHECK EXISTING BED ASSIGNMENT
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    id,
                    patient_id,
                    staff_id
                FROM patient_assignments
                WHERE bed_id = ?
                """,
                (bed_id,)
            )

            existing_assignment = cursor.fetchone()

            # ------------------------------------------------
            # CREATE OR UPDATE ASSIGNMENT
            # ------------------------------------------------

            if existing_assignment:

                cursor.execute(
                    """
                    UPDATE patient_assignments

                    SET
                        patient_id = ?,
                        staff_id = ?,
                        updated_at = CURRENT_TIMESTAMP

                    WHERE bed_id = ?
                    """,
                    (
                        patient_id,
                        staff_id,
                        bed_id
                    )
                )

            else:

                cursor.execute(
                    """
                    INSERT INTO patient_assignments (
                        bed_id,
                        patient_id,
                        staff_id
                    )

                    VALUES (?, ?, ?)
                    """,
                    (
                        bed_id,
                        patient_id,
                        staff_id
                    )
                )

            # ------------------------------------------------
            # MARK BED AS OCCUPIED
            # ------------------------------------------------

            cursor.execute(
                """
                UPDATE beds

                SET status = 'Occupied'

                WHERE bed_id = ?
                """,
                (bed_id,)
            )

            connection.commit()

            return (
                True,
                "Patient assigned to bed successfully."
            )

        except sqlite3.IntegrityError as error:

            connection.rollback()

            return (
                False,
                f"Unable to assign patient: {error}"
            )

        except sqlite3.Error as error:

            connection.rollback()

            return (
                False,
                f"Database error while assigning patient: {error}"
            )

        finally:

            connection.close()

    # ========================================================
    # UPDATE PATIENT BED
    # ========================================================

    @staticmethod
    def update_patient_bed(
        current_bed_id,
        new_bed_id,
        patient_id,
        staff_id
    ):
        """
        Move a patient from one bed to another.

        Rules:

            - Current assignment must exist.
            - New bed must exist.
            - New bed must not already contain a patient.
            - Patient is removed from the old bed.
            - Old bed becomes Available.
            - Patient is assigned to new bed.
            - New bed becomes Occupied.

        Returns:

            (True, success_message)

        or:

            (False, error_message)
        """

        current_bed_id = str(current_bed_id).strip()
        new_bed_id = str(new_bed_id).strip()
        patient_id = str(patient_id).strip()
        staff_id = str(staff_id).strip()

        # ----------------------------------------------------
        # VALIDATION
        # ----------------------------------------------------

        if not current_bed_id:
            return False, "Current bed ID is required."

        if not new_bed_id:
            return False, "New bed ID is required."

        if not patient_id:
            return False, "Patient ID is required."

        if not staff_id:
            return False, "Nurse / Doctor ID is required."

        if current_bed_id == new_bed_id:
            return (
                False,
                "New bed must be different from current bed."
            )

        connection = get_connection()
        cursor = connection.cursor()

        try:

            # ------------------------------------------------
            # CHECK CURRENT ASSIGNMENT
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    id,
                    bed_id,
                    patient_id,
                    staff_id
                FROM patient_assignments
                WHERE bed_id = ?
                  AND patient_id = ?
                """,
                (
                    current_bed_id,
                    patient_id
                )
            )

            current_assignment = cursor.fetchone()

            if current_assignment is None:
                return (
                    False,
                    "Current patient assignment was not found."
                )

            # ------------------------------------------------
            # CHECK NEW BED
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    bed_id,
                    ward_id,
                    status
                FROM beds
                WHERE bed_id = ?
                """,
                (new_bed_id,)
            )

            new_bed = cursor.fetchone()

            if new_bed is None:
                return (
                    False,
                    "New bed ID does not exist."
                )

            # ------------------------------------------------
            # CHECK WHETHER NEW BED ALREADY HAS A PATIENT
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    id,
                    patient_id
                FROM patient_assignments
                WHERE bed_id = ?
                """,
                (new_bed_id,)
            )

            existing_new_assignment = cursor.fetchone()

            if existing_new_assignment is not None:
                return (
                    False,
                    "The new bed already has a patient."
                )

            # ------------------------------------------------
            # CHECK STAFF
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT staff_id
                FROM staff
                WHERE staff_id = ?
                """,
                (staff_id,)
            )

            if cursor.fetchone() is None:
                return (
                    False,
                    "Nurse / Doctor ID does not exist."
                )

            # ------------------------------------------------
            # MOVE PATIENT
            # ------------------------------------------------

            cursor.execute(
                """
                DELETE FROM patient_assignments

                WHERE bed_id = ?
                  AND patient_id = ?
                """,
                (
                    current_bed_id,
                    patient_id
                )
            )

            # ------------------------------------------------
            # FREE OLD BED
            # ------------------------------------------------

            cursor.execute(
                """
                UPDATE beds

                SET status = 'Available'

                WHERE bed_id = ?
                """,
                (current_bed_id,)
            )

            # ------------------------------------------------
            # CREATE NEW ASSIGNMENT
            # ------------------------------------------------

            cursor.execute(
                """
                INSERT INTO patient_assignments (
                    bed_id,
                    patient_id,
                    staff_id
                )

                VALUES (?, ?, ?)
                """,
                (
                    new_bed_id,
                    patient_id,
                    staff_id
                )
            )

            # ------------------------------------------------
            # OCCUPY NEW BED
            # ------------------------------------------------

            cursor.execute(
                """
                UPDATE beds

                SET status = 'Occupied'

                WHERE bed_id = ?
                """,
                (new_bed_id,)
            )

            connection.commit()

            return (
                True,
                "Patient moved successfully."
            )

        except sqlite3.IntegrityError as error:

            connection.rollback()

            return (
                False,
                f"Unable to move patient: {error}"
            )

        except sqlite3.Error as error:

            connection.rollback()

            return (
                False,
                f"Database error while moving patient: {error}"
            )

        finally:

            connection.close()

    # ========================================================
    # DISCHARGE PATIENT
    # ========================================================

    @staticmethod
    def discharge_patient(
        bed_id,
        patient_id
    ):
        """
        Discharge a patient from a bed.

        The patient record itself is NOT deleted.

        Only the current patient-bed assignment is removed.

        The bed is then marked as Available.

        Returns:

            (True, success_message)

        or:

            (False, error_message)
        """

        bed_id = str(bed_id).strip()
        patient_id = str(patient_id).strip()

        # ----------------------------------------------------
        # VALIDATION
        # ----------------------------------------------------

        if not bed_id:
            return False, "Bed ID is required."

        if not patient_id:
            return False, "Patient ID is required."

        connection = get_connection()
        cursor = connection.cursor()

        try:

            # ------------------------------------------------
            # CHECK ASSIGNMENT
            # ------------------------------------------------

            cursor.execute(
                """
                SELECT
                    id
                FROM patient_assignments
                WHERE bed_id = ?
                  AND patient_id = ?
                """,
                (
                    bed_id,
                    patient_id
                )
            )

            assignment = cursor.fetchone()

            if assignment is None:
                return (
                    False,
                    "Patient assignment was not found."
                )

            # ------------------------------------------------
            # REMOVE ASSIGNMENT
            # ------------------------------------------------

            cursor.execute(
                """
                DELETE FROM patient_assignments

                WHERE bed_id = ?
                  AND patient_id = ?
                """,
                (
                    bed_id,
                    patient_id
                )
            )

            # ------------------------------------------------
            # FREE BED
            # ------------------------------------------------

            cursor.execute(
                """
                UPDATE beds

                SET status = 'Available'

                WHERE bed_id = ?
                """,
                (bed_id,)
            )

            connection.commit()

            return (
                True,
                "Patient discharged successfully."
            )

        except sqlite3.Error as error:

            connection.rollback()

            return (
                False,
                f"Unable to discharge patient: {error}"
            )

        finally:

            connection.close()

    # ========================================================
    # GET PATIENT ASSIGNMENTS
    # ========================================================

    @staticmethod
    def get_patient_assignments():
        """
        Return all current patient-bed assignments.

        Returned records contain:

            id
            bed_id
            patient_id
            staff_id
            created_at
            updated_at
            bed_status
            ward_id
            ward_type
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT

                    pa.id,
                    pa.bed_id,
                    pa.patient_id,
                    pa.staff_id,
                    pa.created_at,
                    pa.updated_at,

                    b.status AS bed_status,
                    b.ward_id,

                    w.ward_type

                FROM patient_assignments pa

                LEFT JOIN beds b
                    ON pa.bed_id = b.bed_id

                LEFT JOIN wards w
                    ON b.ward_id = w.ward_id

                ORDER BY
                    b.ward_id,
                    pa.bed_id
                """
            )

            return cursor.fetchall()

        finally:

            connection.close()

    # ========================================================
    # GET PATIENT ASSIGNMENT
    # ========================================================

    @staticmethod
    def get_patient_assignment(
        patient_id
    ):
        """
        Return the current assignment for one patient.

        Returns:

            sqlite3.Row

        or:

            None
        """

        patient_id = str(patient_id).strip()

        if not patient_id:
            return None

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT

                    pa.id,
                    pa.bed_id,
                    pa.patient_id,
                    pa.staff_id,
                    pa.created_at,
                    pa.updated_at,

                    b.status AS bed_status,
                    b.ward_id,

                    w.ward_type

                FROM patient_assignments pa

                LEFT JOIN beds b
                    ON pa.bed_id = b.bed_id

                LEFT JOIN wards w
                    ON b.ward_id = w.ward_id

                WHERE pa.patient_id = ?

                LIMIT 1
                """,
                (patient_id,)
            )

            return cursor.fetchone()

        finally:

            connection.close()

    # ========================================================
    # GET BED ASSIGNMENT
    # ========================================================

    @staticmethod
    def get_bed_assignment(
        bed_id
    ):
        """
        Return the current patient assignment for a bed.

        Returns:

            sqlite3.Row

        or:

            None
        """

        bed_id = str(bed_id).strip()

        if not bed_id:
            return None

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT

                    pa.id,
                    pa.bed_id,
                    pa.patient_id,
                    pa.staff_id,
                    pa.created_at,
                    pa.updated_at,

                    b.status AS bed_status,
                    b.ward_id,

                    w.ward_type

                FROM patient_assignments pa

                LEFT JOIN beds b
                    ON pa.bed_id = b.bed_id

                LEFT JOIN wards w
                    ON b.ward_id = w.ward_id

                WHERE pa.bed_id = ?

                LIMIT 1
                """,
                (bed_id,)
            )

            return cursor.fetchone()

        finally:

            connection.close()

    # ========================================================
    # GET AVAILABLE BEDS
    # ========================================================

    @staticmethod
    def get_available_beds(
        ward_id=None
    ):
        """
        Return all currently available beds.

        If ward_id is supplied, only beds belonging to that
        ward are returned.

        Returns records containing:

            bed_id
            ward_id
            ward_type
            status
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            if ward_id:

                ward_id = str(ward_id).strip()

                cursor.execute(
                    """
                    SELECT

                        b.bed_id,
                        b.ward_id,
                        w.ward_type,
                        b.status

                    FROM beds b

                    LEFT JOIN wards w
                        ON b.ward_id = w.ward_id

                    WHERE b.ward_id = ?
                      AND b.status = 'Available'

                    ORDER BY
                        b.bed_id
                    """,
                    (ward_id,)
                )

            else:

                cursor.execute(
                    """
                    SELECT

                        b.bed_id,
                        b.ward_id,
                        w.ward_type,
                        b.status

                    FROM beds b

                    LEFT JOIN wards w
                        ON b.ward_id = w.ward_id

                    WHERE b.status = 'Available'

                    ORDER BY
                        b.ward_id,
                        b.bed_id
                    """
                )

            return cursor.fetchall()

        finally:

            connection.close()

    # ========================================================
    # GET OCCUPIED BEDS
    # ========================================================

    @staticmethod
    def get_occupied_beds(
        ward_id=None
    ):
        """
        Return all occupied beds.

        This is useful for the patient management UI.
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            if ward_id:

                ward_id = str(ward_id).strip()

                cursor.execute(
                    """
                    SELECT

                        b.bed_id,
                        b.ward_id,
                        w.ward_type,
                        b.status,

                        pa.patient_id,
                        pa.staff_id

                    FROM beds b

                    LEFT JOIN wards w
                        ON b.ward_id = w.ward_id

                    LEFT JOIN patient_assignments pa
                        ON b.bed_id = pa.bed_id

                    WHERE b.ward_id = ?
                      AND b.status = 'Occupied'

                    ORDER BY
                        b.bed_id
                    """,
                    (ward_id,)
                )

            else:

                cursor.execute(
                    """
                    SELECT

                        b.bed_id,
                        b.ward_id,
                        w.ward_type,
                        b.status,

                        pa.patient_id,
                        pa.staff_id

                    FROM beds b

                    LEFT JOIN wards w
                        ON b.ward_id = w.ward_id

                    LEFT JOIN patient_assignments pa
                        ON b.bed_id = pa.bed_id

                    WHERE b.status = 'Occupied'

                    ORDER BY
                        b.ward_id,
                        b.bed_id
                    """
                )

            return cursor.fetchall()

        finally:

            connection.close()

    # ========================================================
    # GET PATIENTS ASSIGNED TO STAFF
    # ========================================================

    @staticmethod
    def get_staff_patients(
        staff_id
    ):
        """
        Return all patients currently assigned to a particular
        nurse or doctor.
        """

        staff_id = str(staff_id).strip()

        if not staff_id:
            return []

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT

                    pa.id,
                    pa.patient_id,
                    pa.bed_id,
                    pa.staff_id,

                    b.ward_id,
                    w.ward_type,

                    b.status AS bed_status,

                    pa.created_at,
                    pa.updated_at

                FROM patient_assignments pa

                LEFT JOIN beds b
                    ON pa.bed_id = b.bed_id

                LEFT JOIN wards w
                    ON b.ward_id = w.ward_id

                WHERE pa.staff_id = ?

                ORDER BY
                    b.ward_id,
                    pa.bed_id
                """,
                (staff_id,)
            )

            return cursor.fetchall()

        finally:

            connection.close()

    # ========================================================
    # CHECK WHETHER PATIENT IS ASSIGNED
    # ========================================================

    @staticmethod
    def is_patient_assigned(
        patient_id
    ):
        """
        Check whether a patient currently has a bed.
        """

        patient_id = str(patient_id).strip()

        if not patient_id:
            return False

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT id
                FROM patient_assignments
                WHERE patient_id = ?
                LIMIT 1
                """,
                (patient_id,)
            )

            return cursor.fetchone() is not None

        finally:

            connection.close()

    # ========================================================
    # CHECK WHETHER BED IS OCCUPIED
    # ========================================================

    @staticmethod
    def is_bed_occupied(
        bed_id
    ):
        """
        Check whether a bed currently has a patient.
        """

        bed_id = str(bed_id).strip()

        if not bed_id:
            return False

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT id
                FROM patient_assignments
                WHERE bed_id = ?
                LIMIT 1
                """,
                (bed_id,)
            )

            return cursor.fetchone() is not None

        finally:

            connection.close()

    # ========================================================
    # GET PATIENT COUNT
    # ========================================================

    @staticmethod
    def get_patient_count():
        """
        Return the number of registered patients.
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT COUNT(*) AS total
                FROM patients
                """
            )

            result = cursor.fetchone()

            return (
                result["total"]
                if result
                else 0
            )

        finally:

            connection.close()

    # ========================================================
    # GET ASSIGNED PATIENT COUNT
    # ========================================================

    @staticmethod
    def get_assigned_patient_count():
        """
        Return the number of patients currently assigned
        to beds.
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT COUNT(*) AS total
                FROM patient_assignments
                """
            )

            result = cursor.fetchone()

            return (
                result["total"]
                if result
                else 0
            )

        finally:

            connection.close()

    # ========================================================
    # GET AVAILABLE BED COUNT
    # ========================================================

    @staticmethod
    def get_available_bed_count(
        ward_id=None
    ):
        """
        Return the number of available beds.

        If ward_id is provided, only beds in that ward
        are counted.
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            if ward_id:

                ward_id = str(ward_id).strip()

                cursor.execute(
                    """
                    SELECT COUNT(*) AS total

                    FROM beds

                    WHERE ward_id = ?
                      AND status = 'Available'
                    """,
                    (ward_id,)
                )

            else:

                cursor.execute(
                    """
                    SELECT COUNT(*) AS total

                    FROM beds

                    WHERE status = 'Available'
                    """
                )

            result = cursor.fetchone()

            return (
                result["total"]
                if result
                else 0
            )

        finally:

            connection.close()

    # ========================================================
    # GET OCCUPIED BED COUNT
    # ========================================================

    @staticmethod
    def get_occupied_bed_count(
        ward_id=None
    ):
        """
        Return the number of occupied beds.

        If ward_id is provided, only beds in that ward
        are counted.
        """

        connection = get_connection()
        cursor = connection.cursor()

        try:

            if ward_id:

                ward_id = str(ward_id).strip()

                cursor.execute(
                    """
                    SELECT COUNT(*) AS total

                    FROM beds

                    WHERE ward_id = ?
                      AND status = 'Occupied'
                    """,
                    (ward_id,)
                )

            else:

                cursor.execute(
                    """
                    SELECT COUNT(*) AS total

                    FROM beds

                    WHERE status = 'Occupied'
                    """
                )

            result = cursor.fetchone()

            return (
                result["total"]
                if result
                else 0
            )

        finally:

            connection.close()


# ============================================================
# MODULE-LEVEL FUNCTIONS
# ============================================================

def assign_patient_to_bed(
    bed_id,
    patient_id,
    staff_id
):
    """
    Assign a patient to a bed.
    """

    return PatientService.assign_patient_to_bed(
        bed_id,
        patient_id,
        staff_id
    )


def update_patient_bed(
    current_bed_id,
    new_bed_id,
    patient_id,
    staff_id
):
    """
    Move a patient to another bed.
    """

    return PatientService.update_patient_bed(
        current_bed_id,
        new_bed_id,
        patient_id,
        staff_id
    )


def discharge_patient(
    bed_id,
    patient_id
):
    """
    Discharge a patient from a bed.
    """

    return PatientService.discharge_patient(
        bed_id,
        patient_id
    )


def get_patient_assignments():
    """
    Return all patient-bed assignments.
    """

    return PatientService.get_patient_assignments()


def get_patient_assignment(
    patient_id
):
    """
    Return one patient's current assignment.
    """

    return PatientService.get_patient_assignment(
        patient_id
    )


def get_bed_assignment(
    bed_id
):
    """
    Return the patient currently assigned to a bed.
    """

    return PatientService.get_bed_assignment(
        bed_id
    )


def get_available_beds(
    ward_id=None
):
    """
    Return available beds.
    """

    return PatientService.get_available_beds(
        ward_id
    )


def get_occupied_beds(
    ward_id=None
):
    """
    Return occupied beds.
    """

    return PatientService.get_occupied_beds(
        ward_id
    )


def get_staff_patients(
    staff_id
):
    """
    Return patients assigned to a staff member.
    """

    return PatientService.get_staff_patients(
        staff_id
    )


def is_patient_assigned(
    patient_id
):
    """
    Check whether a patient is assigned.
    """

    return PatientService.is_patient_assigned(
        patient_id
    )


def is_bed_occupied(
    bed_id
):
    """
    Check whether a bed is occupied.
    """

    return PatientService.is_bed_occupied(
        bed_id
    )


def get_patient_count():
    """
    Return total registered patients.
    """

    return PatientService.get_patient_count()


def get_assigned_patient_count():
    """
    Return total currently assigned patients.
    """

    return PatientService.get_assigned_patient_count()


def get_available_bed_count(
    ward_id=None
):
    """
    Return number of available beds.
    """

    return PatientService.get_available_bed_count(
        ward_id
    )


def get_occupied_bed_count(
    ward_id=None
):
    """
    Return number of occupied beds.
    """

    return PatientService.get_occupied_bed_count(
        ward_id
    )


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        "SMART PATIENT ASSISTANCE AND "
        "EMERGENCY ALERT SYSTEM"
    )

    print(
        "PATIENT SERVICE"
    )

    print(
        "=============================================="
    )

    try:

        print(
            f"Registered patients: "
            f"{get_patient_count()}"
        )

        print(
            f"Assigned patients: "
            f"{get_assigned_patient_count()}"
        )

        print(
            f"Available beds: "
            f"{get_available_bed_count()}"
        )

        print(
            f"Occupied beds: "
            f"{get_occupied_bed_count()}"
        )

        print(
            "\nPatient assignments:"
        )

        assignments = get_patient_assignments()

        if assignments:

            for assignment in assignments:

                print(
                    f"  Patient: "
                    f"{assignment['patient_id']} | "
                    f"Bed: "
                    f"{assignment['bed_id']} | "
                    f"Staff: "
                    f"{assignment['staff_id']} | "
                    f"Ward: "
                    f"{assignment['ward_id']} | "
                    f"Status: "
                    f"{assignment['bed_status']}"
                )

        else:

            print(
                "  No patient assignments found."
            )

    except Exception as error:

        print(
            f"Patient service test failed: {error}"
        )

    print(
        "=============================================="
    )