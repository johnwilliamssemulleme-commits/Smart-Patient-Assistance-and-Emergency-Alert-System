# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# SERIAL SERVICE
#
# Communication flow:
#
# Bed / Patient ESP32
#        ↓
#      LoRa
#        ↓
#   Hall ESP32
#        ↓
#    USB Serial
#        ↓
#  Desktop Application
#
# ============================================================
#
# RESPONSIBILITIES
#
# 1. Automatically detects the Hall ESP32 serial port.
# 2. Connects to the Hall ESP32 through USB.
# 3. Receives messages forwarded by the LoRa receiver.
# 4. Supports JSON messages.
# 5. Supports CSV / text messages.
# 6. Detects patient events:
#
#       CRITICAL
#       EMERGENCY
#       ASSISTANCE
#       CANCEL
#       ATTENDED
#
# 7. Sends patient alert events to main.py.
# 8. Sends all valid messages to the general callback.
# 9. Reports raw serial data when requested.
# 10. Automatically reconnects after USB disconnection.
# 11. Allows main.py to send commands to the Hall ESP32.
#
# IMPORTANT
#
# - COM ports are NOT hardcoded.
# - This service does NOT contain Flask routes.
# - This service does NOT contain API code.
# - This service does NOT contain database operations.
# - This service does NOT contain MQTT.
# - This service does NOT contain UI code.
# - Patient / bed / ward lookup belongs to the appropriate
#   service / main.py.
#
# ============================================================


from __future__ import annotations


# ============================================================
# IMPORTS
# ============================================================

import json
import logging
import threading
import time

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Optional


# ============================================================
# PY SERIAL
# ============================================================

try:

    import serial

    from serial import SerialException

    from serial.tools import list_ports

except ImportError:

    serial = None

    SerialException = Exception

    list_ports = None


# ============================================================
# LOGGING
# ============================================================

logger = logging.getLogger(__name__)


# ============================================================
# SERIAL CONFIGURATION
# ============================================================

DEFAULT_BAUD_RATE = 115200

SERIAL_TIMEOUT = 1.0

SERIAL_WRITE_TIMEOUT = 1.0

RECONNECT_DELAY = 2.0

MAX_LINE_LENGTH = 8192


# ============================================================
# MESSAGE TYPES
# ============================================================

PATIENT_ALERT_MESSAGE = "PATIENT_ALERT"

STATUS_MESSAGE = "STATUS"

DEVICE_MESSAGE = "DEVICE"

UNKNOWN_MESSAGE = "UNKNOWN"


# ============================================================
# PATIENT EVENT TYPES
# ============================================================

CRITICAL_EVENT = "CRITICAL"

EMERGENCY_EVENT = "EMERGENCY"

ASSISTANCE_EVENT = "ASSISTANCE"

CANCEL_EVENT = "CANCEL"

ATTENDED_EVENT = "ATTENDED"


PATIENT_EVENT_TYPES = {
    CRITICAL_EVENT,
    EMERGENCY_EVENT,
    ASSISTANCE_EVENT,
    CANCEL_EVENT,
    ATTENDED_EVENT,
}


ACTIVE_PATIENT_EVENT_TYPES = {
    CRITICAL_EVENT,
    EMERGENCY_EVENT,
    ASSISTANCE_EVENT,
}


# ============================================================
# COMPATIBILITY EVENT TYPES
# ============================================================

# These allow older / simpler firmware messages to continue
# working without changing the main application callback.

COMPATIBLE_ALERT_TYPES = {
    "CALL",
    "PATIENT_CALL",
    "EMERGENCY_CALL",
    "EMERGENCY_ALERT",
    "ALERT",
}


# ============================================================
# HALL MESSAGE
# ============================================================

@dataclass
class HallMessage:
    """
    Represents one complete message received from the
    Hall ESP32.

    Example JSON:

    {
        "message_type": "PATIENT_ALERT",
        "event_type": "EMERGENCY",
        "sender_device_id": "BED_001",
        "receiver_device_id": "HALL_001",
        "ward_id": "WARD_A",
        "bed_id": "BED_01",
        "patient_id": "PATIENT_001",
        "staff_id": null,
        "alert_type": "EMERGENCY",
        "alert_status": "ACTIVE",
        "timestamp": "2026-09-08T12:30:00"
    }
    """

    message_type: str

    event_type: Optional[str] = None

    sender_device_id: Optional[str] = None

    receiver_device_id: Optional[str] = None

    ward_id: Optional[str] = None

    bed_id: Optional[str] = None

    patient_id: Optional[str] = None

    staff_id: Optional[str] = None

    alert_type: Optional[str] = None

    alert_status: Optional[str] = None

    timestamp: Optional[str] = None

    payload: dict[str, Any] = field(
        default_factory=dict
    )

    received_at: str = field(
        default_factory=lambda:
        datetime.now().isoformat()
    )


# ============================================================
# SERIAL SERVICE
# ============================================================

class SerialService:
    """
    Handles USB serial communication between the desktop
    application and the Hall ESP32.

    Communication:

        Bed ESP32
            ↓
          LoRa
            ↓
        Hall ESP32
            ↓
        USB Serial
            ↓
       SerialService
            ↓
         main.py
    """


    # ========================================================
    # INITIALIZATION
    # ========================================================

    def __init__(
        self,
        baud_rate: int = DEFAULT_BAUD_RATE,

        # ----------------------------------------------------
        # General message callback
        # ----------------------------------------------------

        on_message: Optional[
            Callable[[HallMessage], None]
        ] = None,

        # ----------------------------------------------------
        # Patient event callback
        #
        # main.py compatibility:
        #
        # on_patient_call=
        #     process_received_patient_alert
        # ----------------------------------------------------

        on_patient_call: Optional[
            Callable[[HallMessage], None]
        ] = None,

        # ----------------------------------------------------
        # Connection callback
        #
        # main.py uses:
        #
        # on_connection_change=
        #     handle_hall_receiver_connection
        # ----------------------------------------------------

        on_connection_change: Optional[
            Callable[[bool], None]
        ] = None,

        # ----------------------------------------------------
        # Backward-compatible callback name
        # ----------------------------------------------------

        on_connection_changed: Optional[
            Callable[[bool], None]
        ] = None,

        # ----------------------------------------------------
        # Raw serial callback
        # ----------------------------------------------------

        on_raw_data: Optional[
            Callable[[str], None]
        ] = None,
    ):

        self.baud_rate = int(
            baud_rate
        )

        self.on_message = on_message

        self.on_patient_call = on_patient_call

        # ----------------------------------------------------
        # Support both callback names.
        # ----------------------------------------------------

        if on_connection_change is not None:

            self.on_connection_change = (
                on_connection_change
            )

        else:

            self.on_connection_change = (
                on_connection_changed
            )

        self.on_raw_data = on_raw_data

        # ----------------------------------------------------
        # Serial connection
        # ----------------------------------------------------

        self.serial_connection = None

        self.port_name: Optional[str] = None

        # ----------------------------------------------------
        # Service state
        # ----------------------------------------------------

        self.running = False

        self.connected = False

        # ----------------------------------------------------
        # Background reader thread
        # ----------------------------------------------------

        self.reader_thread: Optional[
            threading.Thread
        ] = None

        # ----------------------------------------------------
        # Lock for serial access
        # ----------------------------------------------------

        self.lock = threading.RLock()

        # ----------------------------------------------------
        # Prevent duplicate connection callbacks
        # ----------------------------------------------------

        self._last_connection_state = False


    # ========================================================
    # FIND ESP32 PORT
    # ========================================================

    @staticmethod
    def find_esp32_port() -> Optional[str]:
        """
        Automatically locate an ESP32 / USB-UART device.

        No COM port is hardcoded.

        The method first looks for recognizable ESP32 or
        USB-UART identifiers.

        If exactly one serial device exists, that device
        is accepted as the Hall ESP32.
        """

        if list_ports is None:

            logger.error(
                "pyserial is not installed."
            )

            return None

        try:

            ports = list(
                list_ports.comports()
            )

        except Exception as error:

            logger.error(
                "Could not enumerate serial ports: %s",
                error
            )

            return None

        if not ports:

            return None

        # ----------------------------------------------------
        # Common ESP32 / USB-UART identifiers.
        # ----------------------------------------------------

        keywords = (
            "esp32",
            "espressif",
            "cp210",
            "silicon labs",
            "ch340",
            "ch341",
            "wch",
            "usb serial",
            "usb-to-uart",
            "uart",
            "ftdi",
        )

        candidates = []

        for port in ports:

            information = " ".join(
                [
                    str(
                        getattr(
                            port,
                            "device",
                            ""
                        )
                    ),

                    str(
                        getattr(
                            port,
                            "description",
                            ""
                        )
                    ),

                    str(
                        getattr(
                            port,
                            "manufacturer",
                            ""
                        )
                    ),

                    str(
                        getattr(
                            port,
                            "product",
                            ""
                        )
                    ),

                    str(
                        getattr(
                            port,
                            "hwid",
                            ""
                        )
                    ),
                ]
            ).lower()

            if any(
                keyword in information
                for keyword in keywords
            ):

                candidates.append(
                    port
                )

        # ----------------------------------------------------
        # Prefer identified USB-UART / ESP32 devices.
        # ----------------------------------------------------

        if candidates:

            if len(candidates) == 1:

                return candidates[0].device

            # ------------------------------------------------
            # Multiple candidates.
            #
            # Do not blindly connect to a random ESP32.
            # ------------------------------------------------

            logger.warning(
                "Multiple ESP32/USB-UART devices detected."
            )

            for port in candidates:

                logger.warning(
                    "Candidate serial device: %s - %s",
                    port.device,
                    port.description
                )

            # ------------------------------------------------
            # For a multi-device system, use the first
            # recognizable device while clearly logging
            # the selection.
            # ------------------------------------------------

            return candidates[0].device

        # ----------------------------------------------------
        # Exactly one unknown serial device.
        # ----------------------------------------------------

        if len(ports) == 1:

            return ports[0].device

        # ----------------------------------------------------
        # Multiple unknown devices.
        # ----------------------------------------------------

        logger.warning(
            "Multiple serial devices detected, "
            "but no ESP32-compatible device was identified."
        )

        for port in ports:

            logger.warning(
                "Available serial device: %s - %s",
                port.device,
                port.description
            )

        return None


    # ========================================================
    # GET AVAILABLE PORTS
    # ========================================================

    @staticmethod
    def get_available_ports() -> list[dict[str, Any]]:
        """
        Return information about all currently available
        serial devices.
        """

        if list_ports is None:

            return []

        result: list[dict[str, Any]] = []

        try:

            ports = list(
                list_ports.comports()
            )

        except Exception as error:

            logger.error(
                "Could not list serial ports: %s",
                error
            )

            return []

        for port in ports:

            result.append(
                {
                    "device":
                        getattr(
                            port,
                            "device",
                            None
                        ),

                    "description":
                        getattr(
                            port,
                            "description",
                            None
                        ),

                    "manufacturer":
                        getattr(
                            port,
                            "manufacturer",
                            None
                        ),

                    "product":
                        getattr(
                            port,
                            "product",
                            None
                        ),

                    "vid":
                        getattr(
                            port,
                            "vid",
                            None
                        ),

                    "pid":
                        getattr(
                            port,
                            "pid",
                            None
                        ),

                    "serial_number":
                        getattr(
                            port,
                            "serial_number",
                            None
                        ),

                    "hwid":
                        getattr(
                            port,
                            "hwid",
                            None
                        ),
                }
            )

        return result


    # ========================================================
    # CONNECT
    # ========================================================

    def connect(self) -> bool:
        """
        Automatically locate and connect to the Hall ESP32.
        """

        if serial is None:

            logger.error(
                "pyserial is not installed."
            )

            return False

        # ----------------------------------------------------
        # Do not hold the lock while performing callbacks.
        # ----------------------------------------------------

        with self.lock:

            if (
                self.serial_connection is not None
                and self.serial_connection.is_open
            ):

                if not self.connected:

                    self.connected = True

                already_connected = True

            else:

                already_connected = False

        if already_connected:

            self._notify_connection_change(
                True
            )

            return True

        # ----------------------------------------------------
        # Find Hall ESP32.
        # ----------------------------------------------------

        port = self.find_esp32_port()

        if not port:

            self._set_disconnected_state()

            return False

        connection = None

        try:

            logger.info(
                "Connecting to Hall ESP32 on %s",
                port
            )

            connection = serial.Serial(
                port=port,

                baudrate=self.baud_rate,

                timeout=SERIAL_TIMEOUT,

                write_timeout=SERIAL_WRITE_TIMEOUT,
            )

            # ------------------------------------------------
            # Clear stale data.
            # ------------------------------------------------

            try:

                connection.reset_input_buffer()

            except Exception:

                pass

            with self.lock:

                # ------------------------------------------------
                # Another connection should not normally exist,
                # but close this new one if one appeared.
                # ------------------------------------------------

                if (
                    self.serial_connection is not None
                    and self.serial_connection.is_open
                ):

                    try:

                        connection.close()

                    except Exception:

                        pass

                    self.connected = True

                    return True

                self.serial_connection = connection

                self.port_name = port

                self.connected = True

            logger.info(
                "Hall ESP32 connected on %s",
                port
            )

            self._notify_connection_change(
                True
            )

            return True

        except (
            SerialException,
            OSError,
            Exception,
        ) as error:

            logger.error(
                "Failed to connect to %s: %s",
                port,
                error
            )

            try:

                if connection is not None:

                    connection.close()

            except Exception:

                pass

            self._set_disconnected_state()

            return False


    # ========================================================
    # SET DISCONNECTED STATE
    # ========================================================

    def _set_disconnected_state(self):
        """
        Mark the service as disconnected and close the
        serial connection if necessary.
        """

        with self.lock:

            connection = self.serial_connection

            self.serial_connection = None

            self.port_name = None

            was_connected = self.connected

            self.connected = False

        if connection is not None:

            try:

                if connection.is_open:

                    connection.close()

            except Exception as error:

                logger.debug(
                    "Serial close error: %s",
                    error
                )

        if was_connected:

            self._notify_connection_change(
                False
            )


    # ========================================================
    # DISCONNECT
    # ========================================================

    def disconnect(self):
        """
        Disconnect from the Hall ESP32.
        """

        self._set_disconnected_state()


    # ========================================================
    # START
    # ========================================================

    def start(self):
        """
        Start the background serial communication service.

        The service will automatically keep trying to locate
        and connect to the Hall ESP32.
        """

        if self.running:

            return

        self.running = True

        self.reader_thread = threading.Thread(
            target=self._communication_loop,

            name="HallESP32SerialService",

            daemon=True,
        )

        self.reader_thread.start()

        logger.info(
            "Hall ESP32 serial service started."
        )


    # ========================================================
    # STOP
    # ========================================================

    def stop(self):
        """
        Stop the serial communication service.
        """

        self.running = False

        self.disconnect()

        thread = self.reader_thread

        if (
            thread is not None
            and thread.is_alive()
            and thread is not threading.current_thread()
        ):

            thread.join(
                timeout=3
            )

        self.reader_thread = None

        logger.info(
            "Hall ESP32 serial service stopped."
        )


    # ========================================================
    # COMMUNICATION LOOP
    # ========================================================

    def _communication_loop(self):
        """
        Continuously:

        1. Connect if disconnected.
        2. Read serial data.
        3. Detect USB disconnection.
        4. Reconnect automatically.
        """

        while self.running:

            # ------------------------------------------------
            # Connect if necessary.
            # ------------------------------------------------

            if not self.connected:

                if not self.connect():

                    self._interruptible_sleep(
                        RECONNECT_DELAY
                    )

                    continue

            # ------------------------------------------------
            # Read serial data.
            # ------------------------------------------------

            try:

                self._read_serial()

            except Exception as error:

                logger.exception(
                    "Unexpected serial communication error: %s",
                    error
                )

                self.disconnect()

                self._interruptible_sleep(
                    RECONNECT_DELAY
                )


    # ========================================================
    # INTERRUPTIBLE SLEEP
    # ========================================================

    def _interruptible_sleep(
        self,
        seconds: float
    ):
        """
        Sleep without making shutdown unnecessarily slow.
        """

        end_time = (
            time.monotonic()
            + seconds
        )

        while (
            self.running
            and time.monotonic() < end_time
        ):

            time.sleep(
                min(
                    0.1,
                    max(
                        0.0,
                        end_time
                        - time.monotonic()
                    )
                )
            )


    # ========================================================
    # READ SERIAL
    # ========================================================

    def _read_serial(self):
        """
        Read one newline-terminated message from the
        Hall ESP32.
        """

        with self.lock:

            connection = self.serial_connection

            if (
                connection is None
                or not connection.is_open
            ):

                self.connected = False

                return

        try:

            raw_line = connection.readline()

        except (
            SerialException,
            OSError,
        ) as error:

            logger.error(
                "Serial read error: %s",
                error
            )

            self.disconnect()

            return

        if not raw_line:

            return

        # ----------------------------------------------------
        # Decode.
        # ----------------------------------------------------

        try:

            line = raw_line.decode(
                "utf-8",
                errors="replace"
            ).strip()

        except Exception as error:

            logger.warning(
                "Could not decode serial data: %s",
                error
            )

            return

        if not line:

            return

        # ----------------------------------------------------
        # Protect against oversized messages.
        # ----------------------------------------------------

        if len(line) > MAX_LINE_LENGTH:

            logger.warning(
                "Ignoring oversized serial message."
            )

            return

        logger.info(
            "Hall ESP32 → PC: %s",
            line
        )

        # ----------------------------------------------------
        # Raw callback.
        # ----------------------------------------------------

        self._call_raw_callback(
            line
        )

        # ----------------------------------------------------
        # Parse.
        # ----------------------------------------------------

        message = self._parse_message(
            line
        )

        if message is None:

            return

        # ----------------------------------------------------
        # General message callback.
        #
        # Every parsed message reaches this callback.
        # ----------------------------------------------------

        self._call_message_callback(
            message
        )

        # ----------------------------------------------------
        # Patient event callback.
        #
        # Active patient events and compatible alert messages
        # reach main.py through on_patient_call.
        #
        # CANCEL and ATTENDED remain available through
        # on_message, because they are state-changing events,
        # not new patient emergency calls.
        # ----------------------------------------------------

        if self._is_patient_alert(
            message
        ):

            logger.info(
                "Patient event received: %s",
                message.event_type
                or message.alert_type
                or message.message_type
            )

            if self.on_patient_call is not None:

                try:

                    self.on_patient_call(
                        message
                    )

                except Exception as error:

                    logger.exception(
                        "Patient alert callback error: %s",
                        error
                    )


    # ========================================================
    # RAW CALLBACK
    # ========================================================

    def _call_raw_callback(
        self,
        line: str
    ):
        """
        Safely invoke the raw serial callback.
        """

        if self.on_raw_data is None:

            return

        try:

            self.on_raw_data(
                line
            )

        except Exception as error:

            logger.exception(
                "Raw-data callback error: %s",
                error
            )


    # ========================================================
    # MESSAGE CALLBACK
    # ========================================================

    def _call_message_callback(
        self,
        message: HallMessage
    ):
        """
        Safely invoke the general message callback.
        """

        if self.on_message is None:

            return

        try:

            self.on_message(
                message
            )

        except Exception as error:

            logger.exception(
                "Message callback error: %s",
                error
            )


    # ========================================================
    # PARSE MESSAGE
    # ========================================================

    def _parse_message(
        self,
        line: str
    ) -> Optional[HallMessage]:
        """
        Parse JSON first.

        If JSON fails, attempt CSV/text parsing.
        """

        # ----------------------------------------------------
        # JSON protocol.
        # ----------------------------------------------------

        try:

            data = json.loads(
                line
            )

            if isinstance(
                data,
                dict
            ):

                return self._create_message(
                    data
                )

        except (
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):

            pass

        # ----------------------------------------------------
        # CSV/text protocol.
        # ----------------------------------------------------

        return self._parse_text_message(
            line
        )


    # ========================================================
    # CREATE MESSAGE FROM JSON
    # ========================================================

    @staticmethod
    def _create_message(
        data: dict[str, Any]
    ) -> HallMessage:
        """
        Convert a JSON dictionary into HallMessage.

        Supports multiple reasonable field names so that the
        Hall ESP32 firmware does not need unnecessary changes.
        """

        # ----------------------------------------------------
        # Message type.
        # ----------------------------------------------------

        message_type = (
            data.get("message_type")
            or data.get("type")
            or data.get("message")
            or data.get("event")
            or PATIENT_ALERT_MESSAGE
            if (
                data.get("event_type")
                or data.get("alert_type")
            )
            else UNKNOWN_MESSAGE
        )

        message_type = str(
            message_type
        ).strip().upper()

        # ----------------------------------------------------
        # Event type.
        # ----------------------------------------------------

        event_type = (
            data.get("event_type")
            or data.get("event")
            or data.get("alert_type")
            or data.get("call_type")
        )

        if event_type is not None:

            event_type = str(
                event_type
            ).strip().upper()

        # ----------------------------------------------------
        # Sender.
        # ----------------------------------------------------

        sender_device_id = (
            data.get("sender_device_id")
            or data.get("sender_id")
            or data.get("source_device_id")
            or data.get("source_id")
            or data.get("device_id")
        )

        # ----------------------------------------------------
        # Receiver.
        # ----------------------------------------------------

        receiver_device_id = (
            data.get("receiver_device_id")
            or data.get("receiver_id")
            or data.get("destination_device_id")
            or data.get("destination_id")
        )

        # ----------------------------------------------------
        # Patient / location.
        # ----------------------------------------------------

        ward_id = data.get(
            "ward_id"
        )

        bed_id = data.get(
            "bed_id"
        )

        patient_id = data.get(
            "patient_id"
        )

        staff_id = data.get(
            "staff_id"
        )

        # ----------------------------------------------------
        # Alert information.
        # ----------------------------------------------------

        alert_type = (
            data.get("alert_type")
            or data.get("alert")
            or data.get("call_type")
            or event_type
        )

        alert_status = (
            data.get("alert_status")
            or data.get("status")
        )

        # ----------------------------------------------------
        # Derive status for event messages when firmware
        # does not explicitly send it.
        # ----------------------------------------------------

        if (
            alert_status is None
            and event_type in ACTIVE_PATIENT_EVENT_TYPES
        ):

            alert_status = "ACTIVE"

        elif (
            alert_status is None
            and event_type == CANCEL_EVENT
        ):

            alert_status = "CANCELLED"

        elif (
            alert_status is None
            and event_type == ATTENDED_EVENT
        ):

            alert_status = "ATTENDED"

        # ----------------------------------------------------
        # Timestamp.
        # ----------------------------------------------------

        timestamp = (
            data.get("timestamp")
            or data.get("time")
            or data.get("created_at")
        )

        # ----------------------------------------------------
        # Construct.
        # ----------------------------------------------------

        return HallMessage(

            message_type=message_type,

            event_type=(
                str(event_type)
                if event_type is not None
                else None
            ),

            sender_device_id=(
                str(sender_device_id)
                if sender_device_id is not None
                else None
            ),

            receiver_device_id=(
                str(receiver_device_id)
                if receiver_device_id is not None
                else None
            ),

            ward_id=(
                str(ward_id)
                if ward_id is not None
                else None
            ),

            bed_id=(
                str(bed_id)
                if bed_id is not None
                else None
            ),

            patient_id=(
                str(patient_id)
                if patient_id is not None
                else None
            ),

            staff_id=(
                str(staff_id)
                if staff_id is not None
                else None
            ),

            alert_type=(
                str(alert_type)
                if alert_type is not None
                else None
            ),

            alert_status=(
                str(alert_status)
                if alert_status is not None
                else None
            ),

            timestamp=(
                str(timestamp)
                if timestamp is not None
                else None
            ),

            payload=data,
        )


    # ========================================================
    # TEXT MESSAGE PARSER
    # ========================================================

    @staticmethod
    def _parse_text_message(
        line: str
    ) -> Optional[HallMessage]:
        """
        Parse simple CSV/text messages.

        Supported formats include:

        CRITICAL,BED_001,HALL_001,WARD_A,BED_01,PATIENT_001

        EMERGENCY,BED_001,HALL_001,WARD_A,BED_01,PATIENT_001

        ASSISTANCE,BED_001,HALL_001,WARD_A,BED_01,PATIENT_001

        CANCEL,BED_001,HALL_001,WARD_A,BED_01,PATIENT_001

        ATTENDED,BED_001,HALL_001,WARD_A,BED_01,PATIENT_001

        PATIENT_ALERT,BED_001,HALL_001,WARD_A,BED_01,PATIENT_001,EMERGENCY

        ALERT,BED_001,HALL_001,WARD_A,BED_01,EMERGENCY

        CALL,BED_001,HALL_001,WARD_A,BED_01

        STATUS,HALL_001,ONLINE

        DEVICE,BED_001,HALL_001
        """

        parts = [
            part.strip()
            for part in line.split(",")
        ]

        if not parts:

            return None

        message_type = (
            parts[0]
            .strip()
            .upper()
        )

        # ====================================================
        # STANDARD PATIENT EVENTS
        # ====================================================

        if message_type in PATIENT_EVENT_TYPES:

            return SerialService._build_csv_patient_event(
                event_type=message_type,
                parts=parts,
                line=line,
            )

        # ====================================================
        # PATIENT_ALERT
        # ====================================================

        if message_type == "PATIENT_ALERT":

            # ------------------------------------------------
            # Expected:
            #
            # PATIENT_ALERT,
            # BED,
            # HALL,
            # WARD,
            # BED,
            # PATIENT,
            # EVENT,
            # STATUS
            # ------------------------------------------------

            if len(parts) >= 6:

                event_type = (
                    parts[6].upper()
                    if len(parts) >= 7
                    else "ASSISTANCE"
                )

                if event_type not in PATIENT_EVENT_TYPES:

                    event_type = "ASSISTANCE"

                status = (
                    parts[7]
                    if len(parts) >= 8
                    else (
                        "ACTIVE"
                        if event_type
                        in ACTIVE_PATIENT_EVENT_TYPES
                        else event_type
                    )
                )

                return HallMessage(

                    message_type=PATIENT_ALERT_MESSAGE,

                    event_type=event_type,

                    sender_device_id=parts[1],

                    receiver_device_id=parts[2],

                    ward_id=parts[3],

                    bed_id=parts[4],

                    patient_id=parts[5],

                    alert_type=event_type,

                    alert_status=status,

                    payload={
                        "raw": line
                    },
                )

            return HallMessage(

                message_type=PATIENT_ALERT_MESSAGE,

                event_type=None,

                alert_status="UNKNOWN",

                payload={
                    "raw": line
                },
            )

        # ====================================================
        # GENERIC ALERT
        # ====================================================

        if (
            message_type == "ALERT"
            and len(parts) >= 6
        ):

            event_type = (
                parts[5]
                .strip()
                .upper()
            )

            if event_type in COMPATIBLE_ALERT_TYPES:

                event_type = (
                    "EMERGENCY"
                    if event_type
                    in {
                        "EMERGENCY",
                        "EMERGENCY_CALL",
                        "EMERGENCY_ALERT",
                    }
                    else "ASSISTANCE"
                )

            if event_type not in PATIENT_EVENT_TYPES:

                event_type = "ASSISTANCE"

            return HallMessage(

                message_type=PATIENT_ALERT_MESSAGE,

                event_type=event_type,

                sender_device_id=parts[1],

                receiver_device_id=parts[2],

                ward_id=parts[3],

                bed_id=parts[4],

                alert_type=event_type,

                alert_status="ACTIVE",

                payload={
                    "raw": line
                },
            )

        # ====================================================
        # CALL
        # ====================================================

        if (
            message_type == "CALL"
            and len(parts) >= 5
        ):

            return HallMessage(

                message_type=PATIENT_ALERT_MESSAGE,

                event_type=ASSISTANCE_EVENT,

                sender_device_id=parts[1],

                receiver_device_id=parts[2],

                ward_id=parts[3],

                bed_id=parts[4],

                alert_type=ASSISTANCE_EVENT,

                alert_status="ACTIVE",

                payload={
                    "raw": line
                },
            )

        # ====================================================
        # STATUS
        # ====================================================

        if message_type == "STATUS":

            return HallMessage(

                message_type=STATUS_MESSAGE,

                sender_device_id=(
                    parts[1]
                    if len(parts) >= 2
                    else None
                ),

                receiver_device_id=(
                    parts[2]
                    if len(parts) >= 3
                    else None
                ),

                alert_status=(
                    parts[3]
                    if len(parts) >= 4
                    else None
                ),

                payload={
                    "raw": line
                },
            )

        # ====================================================
        # DEVICE
        # ====================================================

        if message_type == "DEVICE":

            return HallMessage(

                message_type=DEVICE_MESSAGE,

                sender_device_id=(
                    parts[1]
                    if len(parts) >= 2
                    else None
                ),

                receiver_device_id=(
                    parts[2]
                    if len(parts) >= 3
                    else None
                ),

                payload={
                    "raw": line
                },
            )

        # ====================================================
        # UNKNOWN
        # ====================================================

        logger.warning(
            "Unknown Hall ESP32 message: %s",
            line
        )

        return HallMessage(

            message_type=UNKNOWN_MESSAGE,

            payload={
                "raw": line
            },
        )


    # ========================================================
    # BUILD CSV PATIENT EVENT
    # ========================================================

    @staticmethod
    def _build_csv_patient_event(
        event_type: str,
        parts: list[str],
        line: str,
    ) -> HallMessage:
        """
        Build a patient event from CSV.

        Preferred format:

        EVENT,
        DEVICE_ID,
        HALL_ID,
        WARD_ID,
        BED_ID,
        PATIENT_ID

        Example:

        EMERGENCY,
        BED_001,
        HALL_001,
        WARD_A,
        BED_01,
        PATIENT_001
        """

        return HallMessage(

            message_type=PATIENT_ALERT_MESSAGE,

            event_type=event_type,

            sender_device_id=(
                parts[1]
                if len(parts) >= 2
                else None
            ),

            receiver_device_id=(
                parts[2]
                if len(parts) >= 3
                else None
            ),

            ward_id=(
                parts[3]
                if len(parts) >= 4
                else None
            ),

            bed_id=(
                parts[4]
                if len(parts) >= 5
                else None
            ),

            patient_id=(
                parts[5]
                if len(parts) >= 6
                else None
            ),

            alert_type=event_type,

            alert_status=(
                "ACTIVE"
                if event_type
                in ACTIVE_PATIENT_EVENT_TYPES
                else (
                    "CANCELLED"
                    if event_type == CANCEL_EVENT
                    else "ATTENDED"
                )
            ),

            payload={
                "raw": line
            },
        )


    # ========================================================
    # DETERMINE WHETHER MESSAGE IS A PATIENT ALERT
    # ========================================================

    @staticmethod
    def _is_patient_alert(
        message: HallMessage
    ) -> bool:
        """
        Determine whether a message represents a new
        patient assistance / emergency request.

        Only active patient events are sent through
        on_patient_call.

        CANCEL and ATTENDED are still delivered through
        on_message.
        """

        event_type = (
            message.event_type
            or message.alert_type
            or ""
        )

        event_type = (
            str(event_type)
            .strip()
            .upper()
        )

        if event_type in ACTIVE_PATIENT_EVENT_TYPES:

            return True

        # ----------------------------------------------------
        # Backward compatibility.
        # ----------------------------------------------------

        if event_type in {
            "CALL",
            "PATIENT_CALL",
            "EMERGENCY_CALL",
            "EMERGENCY_ALERT",
            "EMERGENCY",
        }:

            return True

        # ----------------------------------------------------
        # Older message-type formats.
        # ----------------------------------------------------

        message_type = (
            message.message_type
            or ""
        ).strip().upper()

        if message_type in {
            "PATIENT_ALERT",
            "PATIENT_CALL",
            "ALERT",
            "CALL",
            "EMERGENCY",
            "EMERGENCY_ALERT",
        }:

            return True

        return False


    # ========================================================
    # SEND JSON
    # ========================================================

    def send_json(
        self,
        data: dict[str, Any]
    ) -> bool:
        """
        Send a JSON command to the Hall ESP32.

        A newline is added so the Hall ESP32 can read the
        command using Serial.readStringUntil('\\n').
        """

        if not isinstance(
            data,
            dict
        ):

            logger.error(
                "send_json() requires a dictionary."
            )

            return False

        message = (
            json.dumps(
                data,
                separators=(
                    ",",
                    ":"
                )
            )
            + "\n"
        )

        return self._write(
            message
        )


    # ========================================================
    # SEND TEXT COMMAND
    # ========================================================

    def send_command(
        self,
        command: str
    ) -> bool:
        """
        Send a plain-text command to the Hall ESP32.
        """

        if command is None:

            return False

        command = str(
            command
        ).strip()

        if not command:

            return False

        if not command.endswith(
            "\n"
        ):

            command += "\n"

        return self._write(
            command
        )


    # ========================================================
    # WRITE SERIAL
    # ========================================================

    def _write(
        self,
        message: str
    ) -> bool:
        """
        Thread-safe serial write operation.
        """

        with self.lock:

            connection = self.serial_connection

            if (
                not self.connected
                or connection is None
                or not connection.is_open
            ):

                logger.warning(
                    "Cannot write to Hall ESP32: "
                    "device is not connected."
                )

                return False

            try:

                connection.write(
                    message.encode(
                        "utf-8"
                    )
                )

                connection.flush()

            except (
                SerialException,
                OSError,
            ) as error:

                logger.error(
                    "Serial write error: %s",
                    error
                )

                # ------------------------------------------------
                # Do not hold the lock while disconnecting.
                # ------------------------------------------------

                pass_error = True

            else:

                pass_error = False

        if pass_error:

            self.disconnect()

            return False

        logger.info(
            "PC → Hall ESP32: %s",
            message.strip()
        )

        return True


    # ========================================================
    # REQUEST STATUS
    # ========================================================

    def request_status(self) -> bool:
        """
        Ask the Hall ESP32 for its current status.
        """

        return self.send_json(
            {
                "command": "STATUS"
            }
        )


    # ========================================================
    # CONNECTION CALLBACK
    # ========================================================

    def _notify_connection_change(
        self,
        connected: bool
    ):
        """
        Notify main.py when the USB connection changes.

        Duplicate notifications are suppressed.
        """

        if (
            connected
            == self._last_connection_state
        ):

            return

        self._last_connection_state = (
            connected
        )

        if self.on_connection_change is None:

            return

        try:

            self.on_connection_change(
                connected
            )

        except Exception as error:

            logger.exception(
                "Connection callback error: %s",
                error
            )


    # ========================================================
    # STATUS
    # ========================================================

    def get_status(
        self
    ) -> dict[str, Any]:
        """
        Return the current serial service state.
        """

        with self.lock:

            return {
                "connected":
                    self.connected,

                "port":
                    self.port_name,

                "baud_rate":
                    self.baud_rate,

                "running":
                    self.running,
            }


# ============================================================
# DEVELOPMENT / DIRECT TEST
# ============================================================

if __name__ == "__main__":

    logging.basicConfig(

        level=logging.INFO,

        format=(
            "%(asctime)s | "
            "%(levelname)s | "
            "%(message)s"
        ),
    )

    print()

    print(
        "============================================================"
    )

    print(
        "SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM"
    )

    print(
        "HALL ESP32 SERIAL SERVICE TEST"
    )

    print(
        "============================================================"
    )

    print()

    # ========================================================
    # SHOW SERIAL DEVICES
    # ========================================================

    print(
        "Available serial devices:"
    )

    ports = (
        SerialService.get_available_ports()
    )

    if not ports:

        print(
            "  No serial devices detected."
        )

    else:

        for port in ports:

            print(
                f"  {port['device']} - "
                f"{port['description']}"
            )

    print()

    # ========================================================
    # GENERAL MESSAGE CALLBACK
    # ========================================================

    def handle_message(
        message: HallMessage
    ):

        print()

        print(
            "---------------- MESSAGE ----------------"
        )

        print(
            f"Type:       {message.message_type}"
        )

        print(
            f"Event:      {message.event_type}"
        )

        print(
            f"Sender:     {message.sender_device_id}"
        )

        print(
            f"Receiver:   {message.receiver_device_id}"
        )

        print(
            f"Ward:       {message.ward_id}"
        )

        print(
            f"Bed:        {message.bed_id}"
        )

        print(
            f"Patient:    {message.patient_id}"
        )

        print(
            f"Staff:      {message.staff_id}"
        )

        print(
            f"Alert:      {message.alert_type}"
        )

        print(
            f"Status:     {message.alert_status}"
        )

        print(
            f"Timestamp:  {message.timestamp}"
        )

        print(
            f"Payload:    {message.payload}"
        )

        print(
            "------------------------------------------"
        )


    # ========================================================
    # PATIENT ALERT CALLBACK
    # ========================================================

    def handle_patient_call(
        message: HallMessage
    ):

        print()

        print(
            "############################################################"
        )

        print(
            "                PATIENT ALERT RECEIVED"
        )

        print(
            "############################################################"
        )

        print(
            f"Event:   {message.event_type}"
        )

        print(
            f"Patient: {message.patient_id}"
        )

        print(
            f"Ward:    {message.ward_id}"
        )

        print(
            f"Bed:     {message.bed_id}"
        )

        print(
            f"Device:  {message.sender_device_id}"
        )

        print(
            f"Status:  {message.alert_status}"
        )

        print(
            "############################################################"
        )


    # ========================================================
    # CONNECTION CALLBACK
    # ========================================================

    def connection_changed(
        connected: bool
    ):

        if connected:

            print(
                "\n[USB] Hall ESP32 connected."
            )

        else:

            print(
                "\n[USB] Hall ESP32 disconnected."
            )


    # ========================================================
    # CREATE SERVICE
    # ========================================================

    service = SerialService(

        baud_rate=115200,

        on_patient_call=(
            handle_patient_call
        ),

        on_message=(
            handle_message
        ),

        on_connection_change=(
            connection_changed
        ),
    )


    # ========================================================
    # START
    # ========================================================

    service.start()

    print(
        "Listening for Hall ESP32 / LoRa data..."
    )

    print(
        "Waiting for patient events..."
    )

    print(
        "Press Ctrl+C to stop."
    )

    print()


    # ========================================================
    # KEEP PROGRAM RUNNING
    # ========================================================

    try:

        while True:

            time.sleep(
                1
            )

    except KeyboardInterrupt:

        print()

        print(
            "Stopping serial service..."
        )

        service.stop()

        print(
            "Serial service stopped."
        )