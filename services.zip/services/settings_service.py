# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# SETTINGS SERVICE
# ============================================================

#
# RESPONSIBILITY:
#
# System configuration and administrator settings only.
#
# This service handles:
#
# Administrator
# ↓
# System Settings
# ↓
# Hall Receiver Configuration
# ↓
# Device Communication Configuration
# ↓
# Alert Configuration
# ↓
# Notification Configuration
# ↓
# Response Timing
# ↓
# Startup Configuration
# ↓
# System Logs
# ↓
# Database Backup / Restore
#
# This service does NOT handle:
#
# - Patient management
# - Bed assignment
# - Staff assignment
# - Device-bed assignment
# - ESP32 sensor processing
# - Hall Receiver serial communication
# - LoRa communication
# - PDF report generation
#
# ============================================================

import json
import os
import shutil
import sqlite3

from pathlib import Path
from datetime import datetime

from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)

from models import (
    create_database,
    get_connection
)


# ============================================================
# PROJECT DIRECTORIES
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"
BACKUPS_DIR = BASE_DIR / "backups"


# ============================================================
# DATABASE
# ============================================================

DATABASE_FILE = DATA_DIR / "smart_patient_assistance.db"


# ============================================================
# SYSTEM INFORMATION
# ============================================================

APP_NAME = (
    "Smart Patient Assistance and Emergency Alert System"
)

APP_VERSION = "1.0.0"


# ============================================================
# SETTINGS FILE
# ============================================================

SETTINGS_FILE = DATA_DIR / "system_settings.json"


# ============================================================
# DEFAULT SETTINGS
# ============================================================

DEFAULT_SETTINGS = {

    # --------------------------------------------------------
    # HALL RECEIVER
    # --------------------------------------------------------

    "hall_receiver": {

        "device_id": "HALL-001",

        "communication_enabled": True,

        "auto_reconnect": True
    },


    # --------------------------------------------------------
    # PATIENT DEVICE COMMUNICATION
    # --------------------------------------------------------

    "device_communication": {

        "communication_enabled": True,

        "connection_timeout": 10,

        "reconnect_attempts": 3
    },


    # --------------------------------------------------------
    # ALERT SETTINGS
    # --------------------------------------------------------

    "alert": {

        "assistance_alert_enabled": True,

        "emergency_alert_enabled": True,

        "critical_alert_enabled": True
    },


    # --------------------------------------------------------
    # NOTIFICATION / SOUND
    # --------------------------------------------------------

    "notification_sound": {

        "sound_enabled": True,

        "volume": 100,

        "repeat_sound": True,

        "repeat_interval": 5
    },


    # --------------------------------------------------------
    # RESPONSE TIMING
    # --------------------------------------------------------

    "response_timing": {

        "response_timeout": 60,

        "alert_repeat_interval": 5
    },


    # --------------------------------------------------------
    # STARTUP
    # --------------------------------------------------------

    "startup": {

        "automatic_startup": False
    }
}


# ============================================================
# INITIALIZE SETTINGS SERVICE
# ============================================================

def initialize_settings_service():
    """
    Initialize the database, required directories,
    and default system settings.
    """

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    BACKUPS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    create_database()

    load_settings()

    return True


# ============================================================
# DEFAULT SETTINGS
# ============================================================

def get_default_settings():
    """
    Return a completely independent copy of the default
    settings.

    A JSON round-trip is used so callers cannot accidentally
    modify DEFAULT_SETTINGS directly.
    """

    return json.loads(
        json.dumps(DEFAULT_SETTINGS)
    )


# ============================================================
# LOAD SETTINGS
# ============================================================

def load_settings():
    """
    Load system settings from the JSON configuration file.

    If the file does not exist, default settings are created.

    If the file is corrupted or invalid, default settings
    are returned.
    """

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # CREATE DEFAULT SETTINGS FILE
    # --------------------------------------------------------

    if not SETTINGS_FILE.exists():

        settings = get_default_settings()

        save_settings(settings)

        return settings

    # --------------------------------------------------------
    # LOAD SETTINGS
    # --------------------------------------------------------

    try:

        with open(
            SETTINGS_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            settings = json.load(file)

        if not isinstance(settings, dict):

            raise ValueError(
                "Settings file must contain an object."
            )

        # ----------------------------------------------------
        # Merge missing default sections/settings.
        #
        # This prevents an older settings file from breaking
        # after new settings are added to the application.
        # ----------------------------------------------------

        defaults = get_default_settings()

        changed = False

        for section, default_values in defaults.items():

            if section not in settings:

                settings[section] = default_values

                changed = True

                continue

            if not isinstance(
                settings[section],
                dict
            ):

                settings[section] = default_values

                changed = True

                continue

            for key, default_value in default_values.items():

                if key not in settings[section]:

                    settings[section][key] = default_value

                    changed = True

        if changed:

            save_settings(settings)

        return settings

    except (
        json.JSONDecodeError,
        OSError,
        ValueError
    ):

        # ----------------------------------------------------
        # Do not destroy the existing file automatically.
        # Simply return safe defaults.
        # ----------------------------------------------------

        return get_default_settings()


# ============================================================
# SAVE SETTINGS
# ============================================================

def save_settings(settings):
    """
    Save system settings safely to JSON.

    A temporary file is written first and then atomically
    replaced over the existing settings file.
    """

    if not isinstance(settings, dict):

        raise ValueError(
            "Settings must be a dictionary."
        )

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    temporary_file = SETTINGS_FILE.with_suffix(
        ".tmp"
    )

    try:

        with open(
            temporary_file,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                settings,
                file,
                indent=4
            )

        os.replace(
            temporary_file,
            SETTINGS_FILE
        )

    except Exception:

        if temporary_file.exists():

            try:
                temporary_file.unlink()
            except OSError:
                pass

        raise


# ============================================================
# GET ALL SYSTEM SETTINGS
# ============================================================

def get_system_settings():
    """
    Return all system settings.
    """

    return load_settings()


# ============================================================
# UPDATE ONE SETTING
# ============================================================

def update_setting(
    section,
    setting,
    value
):
    """
    Update one individual setting.
    """

    section = str(section).strip()
    setting = str(setting).strip()

    settings = load_settings()

    if section not in settings:

        raise ValueError(
            f"Unknown settings section: {section}"
        )

    if setting not in settings[section]:

        raise ValueError(
            f"Unknown setting: {setting}"
        )

    settings[section][setting] = value

    save_settings(settings)

    return settings


# ============================================================
# RESET SETTINGS TO DEFAULT
# ============================================================

def reset_system_settings():
    """
    Reset all system settings to their default values.
    """

    settings = get_default_settings()

    save_settings(settings)

    return settings


# ============================================================
# HALL RECEIVER SETTINGS
# ============================================================

def get_hall_receiver_settings():
    """
    Return Hall Receiver configuration.
    """

    settings = load_settings()

    return dict(
        settings["hall_receiver"]
    )


def update_hall_receiver_settings(
    device_id=None,
    communication_enabled=None,
    auto_reconnect=None
):
    """
    Update Hall Receiver configuration.

    The Hall Receiver is a system-level device.

    It is NOT assigned to a patient bed.
    """

    settings = load_settings()

    hall = settings["hall_receiver"]

    # --------------------------------------------------------
    # DEVICE ID
    # --------------------------------------------------------

    if device_id is not None:

        device_id = str(
            device_id
        ).strip()

        if not device_id:

            raise ValueError(
                "Hall Receiver Device ID cannot be empty."
            )

        hall["device_id"] = device_id

    # --------------------------------------------------------
    # COMMUNICATION
    # --------------------------------------------------------

    if communication_enabled is not None:

        hall[
            "communication_enabled"
        ] = bool(
            communication_enabled
        )

    # --------------------------------------------------------
    # AUTO RECONNECT
    # --------------------------------------------------------

    if auto_reconnect is not None:

        hall[
            "auto_reconnect"
        ] = bool(
            auto_reconnect
        )

    save_settings(settings)

    return dict(hall)


# ============================================================
# DEVICE COMMUNICATION SETTINGS
# ============================================================

def get_device_communication_settings():
    """
    Return communication configuration for patient devices.
    """

    settings = load_settings()

    return dict(
        settings["device_communication"]
    )


def update_device_communication_settings(
    communication_enabled=None,
    connection_timeout=None,
    reconnect_attempts=None
):
    """
    Update patient-device communication settings.
    """

    settings = load_settings()

    communication = settings[
        "device_communication"
    ]

    # --------------------------------------------------------
    # ENABLE / DISABLE COMMUNICATION
    # --------------------------------------------------------

    if communication_enabled is not None:

        communication[
            "communication_enabled"
        ] = bool(
            communication_enabled
        )

    # --------------------------------------------------------
    # CONNECTION TIMEOUT
    # --------------------------------------------------------

    if connection_timeout is not None:

        try:

            connection_timeout = int(
                connection_timeout
            )

        except (
            TypeError,
            ValueError
        ):

            raise ValueError(
                "Connection timeout must be a number."
            )

        if connection_timeout <= 0:

            raise ValueError(
                "Connection timeout must be greater than zero."
            )

        communication[
            "connection_timeout"
        ] = connection_timeout

    # --------------------------------------------------------
    # RECONNECT ATTEMPTS
    # --------------------------------------------------------

    if reconnect_attempts is not None:

        try:

            reconnect_attempts = int(
                reconnect_attempts
            )

        except (
            TypeError,
            ValueError
        ):

            raise ValueError(
                "Reconnect attempts must be a number."
            )

        if reconnect_attempts < 0:

            raise ValueError(
                "Reconnect attempts cannot be negative."
            )

        communication[
            "reconnect_attempts"
        ] = reconnect_attempts

    save_settings(settings)

    return dict(communication)


# ============================================================
# ALERT SETTINGS
# ============================================================

def get_alert_settings():
    """
    Return alert configuration.
    """

    settings = load_settings()

    return dict(
        settings["alert"]
    )


def update_alert_settings(
    assistance_alert_enabled=None,
    emergency_alert_enabled=None,
    critical_alert_enabled=None
):
    """
    Update alert configuration.
    """

    settings = load_settings()

    alert = settings["alert"]

    if assistance_alert_enabled is not None:

        alert[
            "assistance_alert_enabled"
        ] = bool(
            assistance_alert_enabled
        )

    if emergency_alert_enabled is not None:

        alert[
            "emergency_alert_enabled"
        ] = bool(
            emergency_alert_enabled
        )

    if critical_alert_enabled is not None:

        alert[
            "critical_alert_enabled"
        ] = bool(
            critical_alert_enabled
        )

    save_settings(settings)

    return dict(alert)


# ============================================================
# NOTIFICATION / SOUND SETTINGS
# ============================================================

def get_notification_sound_settings():
    """
    Return notification and sound settings.
    """

    settings = load_settings()

    return dict(
        settings["notification_sound"]
    )


def update_notification_sound_settings(
    sound_enabled=None,
    volume=None,
    repeat_sound=None,
    repeat_interval=None
):
    """
    Update notification and sound settings.
    """

    settings = load_settings()

    sound = settings[
        "notification_sound"
    ]

    # --------------------------------------------------------
    # SOUND ENABLED
    # --------------------------------------------------------

    if sound_enabled is not None:

        sound[
            "sound_enabled"
        ] = bool(
            sound_enabled
        )

    # --------------------------------------------------------
    # VOLUME
    # --------------------------------------------------------

    if volume is not None:

        try:

            volume = int(volume)

        except (
            TypeError,
            ValueError
        ):

            raise ValueError(
                "Volume must be a number."
            )

        if volume < 0 or volume > 100:

            raise ValueError(
                "Volume must be between 0 and 100."
            )

        sound["volume"] = volume

    # --------------------------------------------------------
    # REPEAT SOUND
    # --------------------------------------------------------

    if repeat_sound is not None:

        sound[
            "repeat_sound"
        ] = bool(
            repeat_sound
        )

    # --------------------------------------------------------
    # REPEAT INTERVAL
    # --------------------------------------------------------

    if repeat_interval is not None:

        try:

            repeat_interval = int(
                repeat_interval
            )

        except (
            TypeError,
            ValueError
        ):

            raise ValueError(
                "Repeat interval must be a number."
            )

        if repeat_interval <= 0:

            raise ValueError(
                "Repeat interval must be greater than zero."
            )

        sound[
            "repeat_interval"
        ] = repeat_interval

    save_settings(settings)

    return dict(sound)


# ============================================================
# RESPONSE TIMING SETTINGS
# ============================================================

def get_response_timing_settings():
    """
    Return response and alert timing configuration.
    """

    settings = load_settings()

    return dict(
        settings["response_timing"]
    )


def update_response_timing_settings(
    response_timeout=None,
    alert_repeat_interval=None
):
    """
    Update response and alert timing settings.
    """

    settings = load_settings()

    timing = settings[
        "response_timing"
    ]

    # --------------------------------------------------------
    # RESPONSE TIMEOUT
    # --------------------------------------------------------

    if response_timeout is not None:

        try:

            response_timeout = int(
                response_timeout
            )

        except (
            TypeError,
            ValueError
        ):

            raise ValueError(
                "Response timeout must be a number."
            )

        if response_timeout <= 0:

            raise ValueError(
                "Response timeout must be greater than zero."
            )

        timing[
            "response_timeout"
        ] = response_timeout

    # --------------------------------------------------------
    # ALERT REPEAT INTERVAL
    # --------------------------------------------------------

    if alert_repeat_interval is not None:

        try:

            alert_repeat_interval = int(
                alert_repeat_interval
            )

        except (
            TypeError,
            ValueError
        ):

            raise ValueError(
                "Alert repeat interval must be a number."
            )

        if alert_repeat_interval <= 0:

            raise ValueError(
                "Alert repeat interval must be greater than zero."
            )

        timing[
            "alert_repeat_interval"
        ] = alert_repeat_interval

    save_settings(settings)

    return dict(timing)


# ============================================================
# STARTUP SETTINGS
# ============================================================

def get_startup_settings():
    """
    Return automatic startup configuration.
    """

    settings = load_settings()

    return dict(
        settings["startup"]
    )


def update_startup_settings(
    automatic_startup
):
    """
    Enable or disable automatic system startup.
    """

    settings = load_settings()

    settings[
        "startup"
    ][
        "automatic_startup"
    ] = bool(
        automatic_startup
    )

    save_settings(settings)

    return dict(
        settings["startup"]
    )


# ============================================================
# ADMIN ACCOUNT
# ============================================================

def admin_exists():
    """
    Check whether the administrator account exists.
    """

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            SELECT admin_id
            FROM admin
            WHERE admin_id = 1
            LIMIT 1
        """)

        result = cursor.fetchone()

        return result is not None

    finally:

        connection.close()


# ============================================================
# GET ADMIN
# ============================================================

def get_admin():
    """
    Retrieve the administrator account.

    Password and recovery key values are returned because
    this function is an internal service function.

    UI/API layers should never expose these hashes directly.
    """

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            SELECT
                admin_id,
                username,
                password_hash,
                recovery_key_hash,
                created_at,
                updated_at
            FROM admin
            WHERE admin_id = 1
            LIMIT 1
        """)

        return cursor.fetchone()

    finally:

        connection.close()


# ============================================================
# CREATE ADMIN
# ============================================================

def create_admin(
    username,
    password,
    recovery_key
):
    """
    Create the single administrator account.

    This is intended for first-time system setup.
    """

    if admin_exists():

        return (
            False,
            "Administrator account already exists."
        )

    # --------------------------------------------------------
    # USERNAME
    # --------------------------------------------------------

    username = str(
        username
    ).strip()

    if not username:

        return (
            False,
            "Username cannot be empty."
        )

    # --------------------------------------------------------
    # PASSWORD
    # --------------------------------------------------------

    if not password:

        return (
            False,
            "Password cannot be empty."
        )

    # --------------------------------------------------------
    # RECOVERY KEY
    # --------------------------------------------------------

    if not recovery_key:

        return (
            False,
            "Recovery key cannot be empty."
        )

    password_hash = generate_password_hash(
        password
    )

    recovery_key_hash = generate_password_hash(
        recovery_key
    )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO admin (
                admin_id,
                username,
                password_hash,
                recovery_key_hash
            )
            VALUES (?, ?, ?, ?)
        """, (
            1,
            username,
            password_hash,
            recovery_key_hash
        ))

        connection.commit()

        return (
            True,
            "Administrator account created successfully."
        )

    except sqlite3.IntegrityError:

        connection.rollback()

        return (
            False,
            "Unable to create administrator account."
        )

    finally:

        connection.close()


# ============================================================
# ADMIN LOGIN
# ============================================================

def login_admin(
    username,
    password
):
    """
    Verify administrator login credentials.
    """

    admin = get_admin()

    if admin is None:

        return (
            False,
            "First-Time Setup is required."
        )

    username = str(
        username
    ).strip()

    if username != admin["username"]:

        return (
            False,
            "Invalid username or password."
        )

    if not check_password_hash(
        admin["password_hash"],
        password
    ):

        return (
            False,
            "Invalid username or password."
        )

    return (
        True,
        "Login successful."
    )


# ============================================================
# VERIFY CURRENT PASSWORD
# ============================================================

def verify_current_password(
    password
):
    """
    Verify the administrator's current password.
    """

    admin = get_admin()

    if admin is None:

        return False

    return check_password_hash(
        admin["password_hash"],
        password
    )


# ============================================================
# VERIFY CURRENT USERNAME
# ============================================================

def verify_current_username(
    username
):
    """
    Verify the administrator's current username.
    """

    admin = get_admin()

    if admin is None:

        return False

    return (
        str(username).strip()
        == admin["username"]
    )


# ============================================================
# VERIFY RECOVERY KEY
# ============================================================

def verify_recovery_key(
    recovery_key
):
    """
    Verify the administrator recovery key.
    """

    admin = get_admin()

    if admin is None:

        return False

    return check_password_hash(
        admin["recovery_key_hash"],
        recovery_key
    )


# ============================================================
# CHANGE PASSWORD
# ============================================================

def change_password(
    current_password,
    new_password,
    confirm_password
):
    """
    Change administrator password.
    """

    if not verify_current_password(
        current_password
    ):

        return (
            False,
            "Current password is incorrect."
        )

    if not new_password:

        return (
            False,
            "New password cannot be empty."
        )

    if new_password != confirm_password:

        return (
            False,
            "New passwords do not match."
        )

    new_password_hash = generate_password_hash(
        new_password
    )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            UPDATE admin
            SET
                password_hash = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE admin_id = 1
        """, (
            new_password_hash,
        ))

        connection.commit()

        return (
            True,
            "Password changed successfully."
        )

    finally:

        connection.close()


# ============================================================
# CHANGE USERNAME
# ============================================================

def change_username(
    current_username,
    new_username,
    confirm_username
):
    """
    Change administrator username.
    """

    if not verify_current_username(
        current_username
    ):

        return (
            False,
            "Current username is incorrect."
        )

    new_username = str(
        new_username
    ).strip()

    confirm_username = str(
        confirm_username
    ).strip()

    if not new_username:

        return (
            False,
            "New username cannot be empty."
        )

    if new_username != confirm_username:

        return (
            False,
            "New usernames do not match."
        )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            UPDATE admin
            SET
                username = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE admin_id = 1
        """, (
            new_username,
        ))

        connection.commit()

        return (
            True,
            "Username changed successfully."
        )

    except sqlite3.IntegrityError:

        connection.rollback()

        return (
            False,
            "That username cannot be used."
        )

    finally:

        connection.close()


# ============================================================
# RESET PASSWORD USING RECOVERY KEY
# ============================================================

def reset_password(
    recovery_key,
    new_password,
    confirm_password
):
    """
    Reset administrator password using recovery key.
    """

    if not verify_recovery_key(
        recovery_key
    ):

        return (
            False,
            "Recovery key is incorrect."
        )

    if not new_password:

        return (
            False,
            "New password cannot be empty."
        )

    if new_password != confirm_password:

        return (
            False,
            "New passwords do not match."
        )

    new_password_hash = generate_password_hash(
        new_password
    )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            UPDATE admin
            SET
                password_hash = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE admin_id = 1
        """, (
            new_password_hash,
        ))

        connection.commit()

        return (
            True,
            "Password reset successfully."
        )

    finally:

        connection.close()


# ============================================================
# CHANGE RECOVERY KEY
# ============================================================

def change_recovery_key(
    current_recovery_key,
    new_recovery_key,
    confirm_recovery_key
):
    """
    Change administrator recovery key.
    """

    if not verify_recovery_key(
        current_recovery_key
    ):

        return (
            False,
            "Current recovery key is incorrect."
        )

    if not new_recovery_key:

        return (
            False,
            "New recovery key cannot be empty."
        )

    if new_recovery_key != confirm_recovery_key:

        return (
            False,
            "New recovery keys do not match."
        )

    new_recovery_key_hash = generate_password_hash(
        new_recovery_key
    )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            UPDATE admin
            SET
                recovery_key_hash = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE admin_id = 1
        """, (
            new_recovery_key_hash,
        ))

        connection.commit()

        return (
            True,
            "Recovery key changed successfully."
        )

    finally:

        connection.close()


# ============================================================
# SYSTEM LOGS
# ============================================================

def get_system_logs(
    limit=500,
    event_type=None
):
    """
    Retrieve system logs.

    Results are returned newest first.
    """

    try:

        limit = int(limit)

    except (
        TypeError,
        ValueError
    ):

        limit = 500

    if limit <= 0:

        limit = 500

    connection = get_connection()

    try:

        cursor = connection.cursor()

        if event_type:

            cursor.execute("""
                SELECT
                    id,
                    event_type,
                    description,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    created_at
                FROM system_logs
                WHERE event_type = ?
                ORDER BY datetime(created_at) DESC
                LIMIT ?
            """, (
                event_type,
                limit
            ))

        else:

            cursor.execute("""
                SELECT
                    id,
                    event_type,
                    description,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    created_at
                FROM system_logs
                ORDER BY datetime(created_at) DESC
                LIMIT ?
            """, (
                limit,
            ))

        return cursor.fetchall()

    finally:

        connection.close()


# ============================================================
# ADD SYSTEM LOG
# ============================================================

def add_system_log(
    event_type,
    description,
    device_id=None,
    ward_id=None,
    bed_id=None,
    patient_id=None
):
    """
    Add an event to the system log.
    """

    event_type = str(
        event_type
    ).strip()

    description = str(
        description
    ).strip()

    if not event_type:

        raise ValueError(
            "Event type is required."
        )

    if not description:

        raise ValueError(
            "Log description is required."
        )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO system_logs (
                event_type,
                description,
                device_id,
                ward_id,
                bed_id,
                patient_id
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            event_type,
            description,
            device_id,
            ward_id,
            bed_id,
            patient_id
        ))

        connection.commit()

        return cursor.lastrowid

    finally:

        connection.close()


# ============================================================
# BACKUP DATABASE
# ============================================================

def backup_database(
    destination=None
):
    """
    Create a backup copy of the SQLite database.
    """

    if not DATABASE_FILE.exists():

        raise FileNotFoundError(
            "Database file does not exist."
        )

    BACKUPS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    if destination is None:

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        destination = (
            BACKUPS_DIR
            /
            (
                "smart_patient_assistance_backup_"
                f"{timestamp}.db"
            )
        )

    else:

        destination = Path(
            destination
        )

        destination.parent.mkdir(
            parents=True,
            exist_ok=True
        )

    # --------------------------------------------------------
    # Prevent accidental overwrite of current database.
    # --------------------------------------------------------

    if destination.resolve() == DATABASE_FILE.resolve():

        raise ValueError(
            "Backup destination cannot be the current database."
        )

    shutil.copy2(
        DATABASE_FILE,
        destination
    )

    return destination


# ============================================================
# RESTORE DATABASE
# ============================================================

def restore_database(
    backup_file
):
    """
    Restore the database from a backup.

    A safety backup of the current database is created first.
    """

    backup_file = Path(
        backup_file
    )

    if not backup_file.exists():

        raise FileNotFoundError(
            "Selected backup file does not exist."
        )

    if not backup_file.is_file():

        raise ValueError(
            "Selected backup is not a file."
        )

    if backup_file.resolve() == DATABASE_FILE.resolve():

        raise ValueError(
            "The current database cannot be restored over itself."
        )

    # --------------------------------------------------------
    # Safety backup
    # --------------------------------------------------------

    safety_backup = backup_database()

    # --------------------------------------------------------
    # Restore
    # --------------------------------------------------------

    shutil.copy2(
        backup_file,
        DATABASE_FILE
    )

    return {
        "restored_from": str(
            backup_file
        ),

        "safety_backup": str(
            safety_backup
        )
    }


# ============================================================
# LIST DATABASE BACKUPS
# ============================================================

def list_backups():
    """
    Return all available database backups.

    Newest backups are returned first.
    """

    BACKUPS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    backups = []

    for file in sorted(
        BACKUPS_DIR.glob("*.db"),
        key=lambda item: item.stat().st_mtime,
        reverse=True
    ):

        try:

            stat = file.stat()

            backups.append({

                "file_name":
                    file.name,

                "path":
                    str(file),

                "size":
                    stat.st_size,

                "created_at":
                    datetime.fromtimestamp(
                        stat.st_mtime
                    ).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
            })

        except OSError:

            # Ignore files that disappear while scanning.
            continue

    return backups


# ============================================================
# EXPORT SYSTEM SETTINGS
# ============================================================

def export_system_settings(
    destination
):
    """
    Export current system settings to JSON.
    """

    destination = Path(
        destination
    )

    destination.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    settings = load_settings()

    with open(
        destination,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            settings,
            file,
            indent=4
        )

    return destination


# ============================================================
# IMPORT SYSTEM SETTINGS
# ============================================================

def import_system_settings(
    source
):
    """
    Import system settings from a JSON file.

    The imported file must contain every required settings
    section and setting.
    """

    source = Path(
        source
    )

    if not source.exists():

        raise FileNotFoundError(
            "Settings file does not exist."
        )

    if not source.is_file():

        raise ValueError(
            "Selected settings source is not a file."
        )

    try:

        with open(
            source,
            "r",
            encoding="utf-8"
        ) as file:

            settings = json.load(file)

    except json.JSONDecodeError:

        raise ValueError(
            "Invalid JSON settings file."
        )

    if not isinstance(
        settings,
        dict
    ):

        raise ValueError(
            "Invalid system settings file."
        )

    defaults = get_default_settings()

    # --------------------------------------------------------
    # Validate sections
    # --------------------------------------------------------

    missing_sections = (
        set(defaults.keys())
        - set(settings.keys())
    )

    if missing_sections:

        raise ValueError(
            "Invalid settings file. Missing sections: "
            +
            ", ".join(
                sorted(missing_sections)
            )
        )

    # --------------------------------------------------------
    # Validate individual settings
    # --------------------------------------------------------

    for section, default_values in defaults.items():

        if not isinstance(
            settings[section],
            dict
        ):

            raise ValueError(
                f"Invalid settings section: {section}"
            )

        missing_settings = (
            set(default_values.keys())
            -
            set(settings[section].keys())
        )

        if missing_settings:

            raise ValueError(
                f"Invalid {section} settings. "
                "Missing settings: "
                +
                ", ".join(
                    sorted(missing_settings)
                )
            )

    # --------------------------------------------------------
    # Save validated settings
    # --------------------------------------------------------

    save_settings(
        settings
    )

    return settings


# ============================================================
# SYSTEM STATUS
# ============================================================

def get_system_status():
    """
    Return basic backend status information.
    """

    return {

        "application":
            APP_NAME,

        "version":
            APP_VERSION,

        "database":
            str(DATABASE_FILE),

        "settings_file":
            str(SETTINGS_FILE),

        "admin_configured":
            admin_exists(),

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# DATABASE STATUS
# ============================================================

def get_database_status():
    """
    Return basic database information.
    """

    exists = DATABASE_FILE.exists()

    if exists:

        try:

            size = DATABASE_FILE.stat().st_size

        except OSError:

            size = 0

    else:

        size = 0

    return {

        "exists":
            exists,

        "path":
            str(DATABASE_FILE),

        "size":
            size
    }


# ============================================================
# INITIALIZE DATABASE AND SETTINGS
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        APP_NAME
    )

    print(
        "SETTINGS SERVICE INITIALIZATION"
    )

    print(
        "=============================================="
    )

    initialize_settings_service()

    print(
        "Database initialized."
    )

    print(
        f"Database: {DATABASE_FILE}"
    )

    print(
        f"Settings: {SETTINGS_FILE}"
    )

    print(
        f"Admin configured: {admin_exists()}"
    )

    print(
        "Settings service initialized successfully."
    )

    print(
        "=============================================="
    )