# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# REPORT SERVICE
# ============================================================
#
# RESPONSIBILITY:
#
# Reporting only.
#
# This service handles:
#
# - Daily reports
# - Weekly reports
# - Monthly reports
# - Response reports
# - Alert statistics
# - Ward statistics
# - System functioning summaries
# - System issue/event summaries
# - PDF report generation
#
# This service does NOT handle:
#
# - ESP32 communication
# - Serial communication
# - Hall Receiver communication
# - LoRa communication
# - Sensor data collection
# - Patient assignment
# - Device assignment
# - Admin authentication
# - System settings
# - Database backup / restore
# - Alert reception
# - UI callbacks
#
# Database schema is defined by:
#
#     models.py
#
# ============================================================


import sqlite3

from pathlib import Path
from datetime import datetime, timedelta
from calendar import monthrange


# ============================================================
# REPORTLAB
# ============================================================

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import (
    getSampleStyleSheet,
    ParagraphStyle,
)
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
)


# ============================================================
# PROJECT MODULES
# ============================================================

from models import get_connection


# ============================================================
# PROJECT DIRECTORIES
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

REPORTS_DIR = BASE_DIR / "reports"


# ============================================================
# REPORT INFORMATION
# ============================================================

REPORT_TITLE = (
    "SMART PATIENT ASSISTANCE AND "
    "EMERGENCY ALERT SYSTEM"
)

APP_VERSION = "1.0.0"


# ============================================================
# REPORT DIRECTORY
# ============================================================

def initialize_report_directory():
    """
    Create the report directory if it does not exist.
    """

    REPORTS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


# ============================================================
# REPORT DATE RANGE
# ============================================================

def get_report_period(
    report_type,
    report_date=None
):
    """
    Calculate the start and end of a reporting period.

    Supported report types:

        daily
        weekly
        monthly

    The returned end value is inclusive.
    """

    if report_date is None:
        report_date = datetime.now()

    if isinstance(report_date, str):
        report_date = datetime.strptime(
            report_date,
            "%Y-%m-%d"
        )

    if not isinstance(report_date, datetime):
        raise TypeError(
            "report_date must be a datetime "
            "object or YYYY-MM-DD string."
        )

    report_type = str(
        report_type
    ).strip().lower()

    # --------------------------------------------------------
    # DAILY
    # --------------------------------------------------------

    if report_type == "daily":

        start = report_date.replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )

        end = start + timedelta(
            days=1
        ) - timedelta(
            microseconds=1
        )

    # --------------------------------------------------------
    # WEEKLY
    # Monday -> Sunday
    # --------------------------------------------------------

    elif report_type == "weekly":

        start = (
            report_date
            - timedelta(
                days=report_date.weekday()
            )
        ).replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )

        end = (
            start
            + timedelta(days=7)
            - timedelta(microseconds=1)
        )

    # --------------------------------------------------------
    # MONTHLY
    # --------------------------------------------------------

    elif report_type == "monthly":

        start = report_date.replace(
            day=1,
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )

        last_day = monthrange(
            start.year,
            start.month
        )[1]

        end = start.replace(
            day=last_day,
            hour=23,
            minute=59,
            second=59,
            microsecond=999999
        )

    else:

        raise ValueError(
            "Invalid report type. "
            "Use daily, weekly or monthly."
        )

    return start, end


# ============================================================
# DATE NORMALIZATION
# ============================================================

def _normalize_date(value, end_of_day=False):
    """
    Convert a datetime or YYYY-MM-DD string to datetime.
    """

    if value is None:
        return None

    if isinstance(value, datetime):
        return value

    if isinstance(value, str):

        result = datetime.strptime(
            value,
            "%Y-%m-%d"
        )

        if end_of_day:

            result = result.replace(
                hour=23,
                minute=59,
                second=59,
                microsecond=999999
            )

        return result

    raise TypeError(
        "Date must be a datetime object "
        "or YYYY-MM-DD string."
    )


# ============================================================
# SQL DATE VALUES
# ============================================================

def _sql_datetime(value):
    """
    Convert datetime into the format stored by SQLite.
    """

    return value.strftime(
        "%Y-%m-%d %H:%M:%S"
    )


# ============================================================
# REPORT STYLES
# ============================================================

def get_report_styles():
    """
    Create styles used by system reports.
    """

    styles = getSampleStyleSheet()

    styles.add(
        ParagraphStyle(
            name="ReportTitleCustom",
            parent=styles["Title"],
            fontSize=18,
            leading=22,
            alignment=TA_CENTER,
            spaceAfter=8
        )
    )

    styles.add(
        ParagraphStyle(
            name="ReportSubtitleCustom",
            parent=styles["Normal"],
            fontSize=12,
            leading=15,
            alignment=TA_CENTER,
            spaceAfter=12
        )
    )

    styles.add(
        ParagraphStyle(
            name="SectionHeadingCustom",
            parent=styles["Heading2"],
            fontSize=12,
            leading=15,
            alignment=TA_LEFT,
            spaceBefore=10,
            spaceAfter=6
        )
    )

    styles.add(
        ParagraphStyle(
            name="SmallTextCustom",
            parent=styles["Normal"],
            fontSize=8,
            leading=10
        )
    )

    return styles


# ============================================================
# REPORT TABLE
# ============================================================

def create_report_table(
    data,
    column_widths=None,
    header=True
):
    """
    Create a formatted ReportLab table.
    """

    table = Table(
        data,
        colWidths=column_widths,
        repeatRows=1 if header else 0,
        hAlign="LEFT"
    )

    table_style = [
        (
            "GRID",
            (0, 0),
            (-1, -1),
            0.5,
            colors.grey
        ),
        (
            "VALIGN",
            (0, 0),
            (-1, -1),
            "MIDDLE"
        ),
        (
            "LEFTPADDING",
            (0, 0),
            (-1, -1),
            5
        ),
        (
            "RIGHTPADDING",
            (0, 0),
            (-1, -1),
            5
        ),
        (
            "TOPPADDING",
            (0, 0),
            (-1, -1),
            5
        ),
        (
            "BOTTOMPADDING",
            (0, 0),
            (-1, -1),
            5
        )
    ]

    if header:

        table_style.extend([
            (
                "BACKGROUND",
                (0, 0),
                (-1, 0),
                colors.lightgrey
            ),
            (
                "FONTNAME",
                (0, 0),
                (-1, 0),
                "Helvetica-Bold"
            ),
            (
                "ALIGN",
                (0, 0),
                (-1, 0),
                "CENTER"
            )
        ])

    table.setStyle(
        TableStyle(table_style)
    )

    return table


# ============================================================
# REPORT HEADER
# ============================================================

def add_report_header(
    story,
    styles,
    report_type,
    start,
    end
):
    """
    Add the standard report header.
    """

    story.append(
        Paragraph(
            REPORT_TITLE,
            styles["ReportTitleCustom"]
        )
    )

    story.append(
        Paragraph(
            f"{str(report_type).upper()} REPORT",
            styles["ReportSubtitleCustom"]
        )
    )

    information = [
        [
            "Report Type",
            str(report_type).capitalize()
        ],
        [
            "Reporting Period",
            (
                f"{start.strftime('%d %B %Y %H:%M')} "
                f"to "
                f"{end.strftime('%d %B %Y %H:%M')}"
            )
        ],
        [
            "Generated On",
            datetime.now().strftime(
                "%d %B %Y %H:%M:%S"
            )
        ],
        [
            "System Version",
            APP_VERSION
        ]
    ]

    story.append(
        create_report_table(
            information,
            column_widths=[
                45 * mm,
                130 * mm
            ],
            header=False
        )
    )

    story.append(
        Spacer(1, 8)
    )


# ============================================================
# ALERT SUMMARY
# ============================================================

def get_alert_summary(
    start,
    end
):
    """
    Return alert statistics grouped by alert type.
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT
                alert_type,

                COUNT(*) AS total,

                SUM(
                    CASE
                        WHEN alert_status = 'ATTENDED'
                        THEN 1
                        ELSE 0
                    END
                ) AS attended,

                SUM(
                    CASE
                        WHEN alert_status = 'CANCELLED'
                        THEN 1
                        ELSE 0
                    END
                ) AS cancelled,

                SUM(
                    CASE
                        WHEN alert_status = 'ACTIVE'
                        THEN 1
                        ELSE 0
                    END
                ) AS active

            FROM alerts

            WHERE datetime(created_at)
                  BETWEEN datetime(?)
                  AND datetime(?)

            GROUP BY alert_type

            ORDER BY alert_type
            """,
            (
                _sql_datetime(start),
                _sql_datetime(end)
            )
        )

        return cursor.fetchall()

    finally:

        connection.close()


# ============================================================
# TOTAL ALERTS
# ============================================================

def get_total_alerts(
    start,
    end
):
    """
    Return total number of alerts.
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT COUNT(*) AS total

            FROM alerts

            WHERE datetime(created_at)
                  BETWEEN datetime(?)
                  AND datetime(?)
            """,
            (
                _sql_datetime(start),
                _sql_datetime(end)
            )
        )

        result = cursor.fetchone()

        if result is None:
            return 0

        return result["total"] or 0

    finally:

        connection.close()


# ============================================================
# RESPONSE INFORMATION
# ============================================================

def get_response_information(
    start,
    end
):
    """
    Return alert response information.

    Response time is calculated as:

        created_at -> attended_at
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT

                id,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                staff_id,
                alert_type,
                alert_status,
                created_at,
                attended_at,

                CASE

                    WHEN attended_at IS NOT NULL

                    THEN
                        strftime(
                            '%s',
                            attended_at
                        )
                        -
                        strftime(
                            '%s',
                            created_at
                        )

                    ELSE NULL

                END AS response_seconds

            FROM alerts

            WHERE datetime(created_at)
                  BETWEEN datetime(?)
                  AND datetime(?)

            ORDER BY datetime(created_at) DESC
            """,
            (
                _sql_datetime(start),
                _sql_datetime(end)
            )
        )

        return cursor.fetchall()

    finally:

        connection.close()


# ============================================================
# FORMAT RESPONSE TIME
# ============================================================

def format_response_time(seconds):
    """
    Convert seconds into HH:MM:SS.

    Example:

        65 -> 00:01:05
    """

    if seconds is None:
        return "—"

    try:
        seconds = max(
            0,
            int(seconds)
        )

    except (
        TypeError,
        ValueError
    ):
        return "—"

    hours = seconds // 3600

    minutes = (
        seconds % 3600
    ) // 60

    remaining_seconds = (
        seconds % 60
    )

    return (
        f"{hours:02d}:"
        f"{minutes:02d}:"
        f"{remaining_seconds:02d}"
    )


# ============================================================
# RESPONSE STATISTICS
# ============================================================

def get_response_statistics(
    start,
    end
):
    """
    Calculate response-time statistics.
    """

    rows = get_response_information(
        start,
        end
    )

    completed_times = [
        row["response_seconds"]
        for row in rows
        if row["response_seconds"] is not None
    ]

    if completed_times:

        average = (
            sum(completed_times)
            / len(completed_times)
        )

        fastest = min(
            completed_times
        )

        longest = max(
            completed_times
        )

    else:

        average = None
        fastest = None
        longest = None

    unattended = sum(
        1
        for row in rows
        if row["response_seconds"] is None
    )

    return {
        "total_alerts": len(rows),
        "responded_alerts": len(completed_times),
        "unattended_alerts": unattended,
        "average_response_seconds": average,
        "fastest_response_seconds": fastest,
        "longest_response_seconds": longest,
        "average_response_time": format_response_time(
            average
        ),
        "fastest_response_time": format_response_time(
            fastest
        ),
        "longest_response_time": format_response_time(
            longest
        )
    }


# ============================================================
# WARD STATISTICS
# ============================================================

def get_ward_statistics(
    start,
    end
):
    """
    Return alert statistics grouped by ward.
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT

                ward_id,

                COUNT(*) AS total,

                SUM(
                    CASE
                        WHEN alert_status = 'ATTENDED'
                        THEN 1
                        ELSE 0
                    END
                ) AS attended,

                SUM(
                    CASE
                        WHEN alert_status = 'CANCELLED'
                        THEN 1
                        ELSE 0
                    END
                ) AS cancelled,

                SUM(
                    CASE
                        WHEN alert_status = 'ACTIVE'
                        THEN 1
                        ELSE 0
                    END
                ) AS active

            FROM alerts

            WHERE datetime(created_at)
                  BETWEEN datetime(?)
                  AND datetime(?)

            GROUP BY ward_id

            ORDER BY ward_id
            """,
            (
                _sql_datetime(start),
                _sql_datetime(end)
            )
        )

        return cursor.fetchall()

    finally:

        connection.close()


# ============================================================
# SYSTEM FUNCTIONING
# ============================================================

def get_system_functioning():
    """
    Return the current status of registered ESP32 devices.

    This is read-only reporting information.

    It does not communicate with any device.
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT

                d.device_id,
                da.ward_id,
                da.bed_id,
                d.status,
                d.last_seen

            FROM devices d

            LEFT JOIN device_assignments da
                ON d.device_id = da.device_id

            ORDER BY d.device_id
            """
        )

        devices = cursor.fetchall()

    finally:

        connection.close()

    result = []

    for device in devices:

        status = (
            device["status"]
            or "Unknown"
        )

        if status == "Online":

            issue = "Normal"

        elif status == "Offline":

            issue = "No communication"

        else:

            issue = "Device issue"

        result.append({
            "device_id": device["device_id"],
            "ward_id": (
                device["ward_id"]
                or "—"
            ),
            "bed_id": (
                device["bed_id"]
                or "—"
            ),
            "status": status,
            "issue": issue,
            "last_seen": (
                device["last_seen"]
                or "—"
            )
        })

    return result


# ============================================================
# SYSTEM ISSUES
# ============================================================

def get_system_issues(
    start,
    end
):
    """
    Return system events recorded during
    the reporting period.
    """

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT

                event_type,
                description,
                device_id,
                ward_id,
                bed_id,
                patient_id,
                created_at

            FROM system_logs

            WHERE datetime(created_at)
                  BETWEEN datetime(?)
                  AND datetime(?)

            ORDER BY datetime(created_at) DESC
            """,
            (
                _sql_datetime(start),
                _sql_datetime(end)
            )
        )

        return cursor.fetchall()

    finally:

        connection.close()


# ============================================================
# GENERATE PERIOD REPORT
# ============================================================

def generate_period_report(
    report_type,
    output_file,
    report_date=None
):
    """
    Generate a Daily, Weekly or Monthly PDF report.
    """

    initialize_report_directory()

    start, end = get_report_period(
        report_type,
        report_date
    )

    output_file = Path(
        output_file
    )

    output_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    styles = get_report_styles()

    document = SimpleDocTemplate(
        str(output_file),
        pagesize=landscape(A4),
        rightMargin=12 * mm,
        leftMargin=12 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm
    )

    story = []

    # ========================================================
    # HEADER
    # ========================================================

    add_report_header(
        story,
        styles,
        report_type,
        start,
        end
    )

    # ========================================================
    # ALERT SUMMARY
    # ========================================================

    story.append(
        Paragraph(
            "ALERT SUMMARY",
            styles["SectionHeadingCustom"]
        )
    )

    alert_rows = [
        [
            "Alert Type",
            "Total",
            "Attended",
            "Cancelled",
            "Active"
        ]
    ]

    summaries = get_alert_summary(
        start,
        end
    )

    for row in summaries:

        alert_rows.append([
            row["alert_type"],
            row["total"] or 0,
            row["attended"] or 0,
            row["cancelled"] or 0,
            row["active"] or 0
        ])

    if len(alert_rows) == 1:

        alert_rows.append([
            "No alerts recorded",
            0,
            0,
            0,
            0
        ])

    story.append(
        create_report_table(
            alert_rows,
            column_widths=[
                55 * mm,
                30 * mm,
                30 * mm,
                30 * mm,
                30 * mm
            ]
        )
    )

    # ========================================================
    # RESPONSE PERFORMANCE
    # ========================================================

    story.append(
        Paragraph(
            "RESPONSE PERFORMANCE",
            styles["SectionHeadingCustom"]
        )
    )

    response_statistics = get_response_statistics(
        start,
        end
    )

    response_summary = [
        [
            "Metric",
            "Result"
        ],
        [
            "Total Alerts",
            response_statistics[
                "total_alerts"
            ]
        ],
        [
            "Responded Alerts",
            response_statistics[
                "responded_alerts"
            ]
        ],
        [
            "Average Response Time",
            response_statistics[
                "average_response_time"
            ]
        ],
        [
            "Fastest Response",
            response_statistics[
                "fastest_response_time"
            ]
        ],
        [
            "Longest Response",
            response_statistics[
                "longest_response_time"
            ]
        ],
        [
            "Unattended Alerts",
            response_statistics[
                "unattended_alerts"
            ]
        ]
    ]

    story.append(
        create_report_table(
            response_summary,
            column_widths=[
                75 * mm,
                70 * mm
            ]
        )
    )

    # ========================================================
    # SYSTEM FUNCTIONING
    # ========================================================

    story.append(
        Paragraph(
            "SYSTEM FUNCTIONING",
            styles["SectionHeadingCustom"]
        )
    )

    functioning = get_system_functioning()

    device_rows = [
        [
            "Device ID",
            "Ward ID",
            "Bed ID",
            "Status",
            "Issue / Condition",
            "Last Seen"
        ]
    ]

    for device in functioning:

        device_rows.append([
            device["device_id"],
            device["ward_id"],
            device["bed_id"],
            device["status"],
            device["issue"],
            device["last_seen"]
        ])

    if len(device_rows) == 1:

        device_rows.append([
            "No devices",
            "—",
            "—",
            "—",
            "—",
            "—"
        ])

    story.append(
        create_report_table(
            device_rows,
            column_widths=[
                30 * mm,
                30 * mm,
                30 * mm,
                30 * mm,
                65 * mm,
                45 * mm
            ]
        )
    )

    # ========================================================
    # SYSTEM ISSUES
    # ========================================================

    story.append(
        Paragraph(
            "SYSTEM ISSUES AND EVENTS",
            styles["SectionHeadingCustom"]
        )
    )

    issues = get_system_issues(
        start,
        end
    )

    issue_rows = [
        [
            "Date / Time",
            "Event",
            "Description",
            "Device ID",
            "Ward ID",
            "Bed ID"
        ]
    ]

    for issue in issues:

        issue_rows.append([
            issue["created_at"],
            issue["event_type"],
            issue["description"],
            issue["device_id"] or "—",
            issue["ward_id"] or "—",
            issue["bed_id"] or "—"
        ])

    if len(issue_rows) == 1:

        issue_rows.append([
            "—",
            "No Issues",
            "No recorded system issues/events",
            "—",
            "—",
            "—"
        ])

    story.append(
        create_report_table(
            issue_rows,
            column_widths=[
                35 * mm,
                35 * mm,
                85 * mm,
                30 * mm,
                30 * mm,
                30 * mm
            ]
        )
    )

    # ========================================================
    # WARD STATISTICS
    # ========================================================

    story.append(
        Paragraph(
            "WARD ALERT STATISTICS",
            styles["SectionHeadingCustom"]
        )
    )

    ward_rows = [
        [
            "Ward ID",
            "Total Alerts",
            "Attended",
            "Cancelled",
            "Active"
        ]
    ]

    ward_statistics = get_ward_statistics(
        start,
        end
    )

    for ward in ward_statistics:

        ward_rows.append([
            ward["ward_id"] or "Unassigned",
            ward["total"] or 0,
            ward["attended"] or 0,
            ward["cancelled"] or 0,
            ward["active"] or 0
        ])

    if len(ward_rows) == 1:

        ward_rows.append([
            "No ward activity",
            0,
            0,
            0,
            0
        ])

    story.append(
        create_report_table(
            ward_rows,
            column_widths=[
                50 * mm,
                35 * mm,
                35 * mm,
                35 * mm,
                35 * mm
            ]
        )
    )

    # ========================================================
    # BUILD PDF
    # ========================================================

    document.build(
        story
    )

    return output_file


# ============================================================
# DAILY REPORT
# ============================================================

def generate_daily_report(
    output_file=None,
    report_date=None
):
    """
    Generate a Daily Report PDF.
    """

    if output_file is None:

        if isinstance(
            report_date,
            str
        ):

            date_text = report_date

        elif isinstance(
            report_date,
            datetime
        ):

            date_text = report_date.strftime(
                "%Y-%m-%d"
            )

        else:

            date_text = datetime.now().strftime(
                "%Y-%m-%d"
            )

        output_file = (
            REPORTS_DIR
            / f"daily_report_{date_text}.pdf"
        )

    return generate_period_report(
        "daily",
        output_file,
        report_date
    )


# ============================================================
# WEEKLY REPORT
# ============================================================

def generate_weekly_report(
    output_file=None,
    report_date=None
):
    """
    Generate a Weekly Report PDF.
    """

    if output_file is None:

        if isinstance(
            report_date,
            datetime
        ):

            date_text = report_date.strftime(
                "%Y-%m-%d"
            )

        elif isinstance(
            report_date,
            str
        ):

            date_text = report_date

        else:

            date_text = datetime.now().strftime(
                "%Y-%m-%d"
            )

        output_file = (
            REPORTS_DIR
            / f"weekly_report_{date_text}.pdf"
        )

    return generate_period_report(
        "weekly",
        output_file,
        report_date
    )


# ============================================================
# MONTHLY REPORT
# ============================================================

def generate_monthly_report(
    output_file=None,
    report_date=None
):
    """
    Generate a Monthly Report PDF.
    """

    if output_file is None:

        if isinstance(
            report_date,
            datetime
        ):

            date_text = report_date.strftime(
                "%Y-%m"
            )

        elif isinstance(
            report_date,
            str
        ):

            parsed_date = datetime.strptime(
                report_date,
                "%Y-%m-%d"
            )

            date_text = parsed_date.strftime(
                "%Y-%m"
            )

        else:

            date_text = datetime.now().strftime(
                "%Y-%m"
            )

        output_file = (
            REPORTS_DIR
            / f"monthly_report_{date_text}.pdf"
        )

    return generate_period_report(
        "monthly",
        output_file,
        report_date
    )


# ============================================================
# RESPONSE REPORT
# ============================================================

def generate_response_report(
    output_file=None,
    start_date=None,
    end_date=None
):
    """
    Generate a detailed Response Report PDF.
    """

    initialize_report_directory()

    if start_date is None:

        start_date = datetime.now().replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )

    else:

        start_date = _normalize_date(
            start_date
        )

    if end_date is None:

        end_date = datetime.now().replace(
            hour=23,
            minute=59,
            second=59,
            microsecond=999999
        )

    else:

        end_date = _normalize_date(
            end_date,
            end_of_day=True
        )

    if output_file is None:

        output_file = (
            REPORTS_DIR
            / "response_report.pdf"
        )

    output_file = Path(
        output_file
    )

    output_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    styles = get_report_styles()

    document = SimpleDocTemplate(
        str(output_file),
        pagesize=landscape(A4),
        rightMargin=12 * mm,
        leftMargin=12 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm
    )

    story = []

    add_report_header(
        story,
        styles,
        "Response",
        start_date,
        end_date
    )

    rows = get_response_information(
        start_date,
        end_date
    )

    response_table = [
        [
            "Alert ID",
            "Device ID",
            "Ward ID",
            "Bed ID",
            "Patient ID",
            "Staff ID",
            "Alert Type",
            "Status",
            "Created",
            "Attended",
            "Response Time"
        ]
    ]

    for row in rows:

        response_table.append([
            row["id"],
            row["device_id"] or "—",
            row["ward_id"] or "—",
            row["bed_id"] or "—",
            row["patient_id"] or "—",
            row["staff_id"] or "—",
            row["alert_type"],
            row["alert_status"],
            row["created_at"],
            row["attended_at"] or "—",
            format_response_time(
                row["response_seconds"]
            )
        ])

    if len(response_table) == 1:

        response_table.append([
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "No responses",
            "—",
            "—",
            "—",
            "—"
        ])

    story.append(
        create_report_table(
            response_table,
            column_widths=[
                16 * mm,
                24 * mm,
                24 * mm,
                24 * mm,
                24 * mm,
                24 * mm,
                27 * mm,
                25 * mm,
                37 * mm,
                37 * mm,
                30 * mm
            ]
        )
    )

    document.build(
        story
    )

    return output_file


# ============================================================
# ALERT STATISTICS REPORT
# ============================================================

def generate_alert_statistics_report(
    output_file=None,
    start_date=None,
    end_date=None
):
    """
    Generate an Alert Statistics PDF.
    """

    initialize_report_directory()

    if start_date is None:

        start_date = datetime.now().replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )

    else:

        start_date = _normalize_date(
            start_date
        )

    if end_date is None:

        end_date = datetime.now().replace(
            hour=23,
            minute=59,
            second=59,
            microsecond=999999
        )

    else:

        end_date = _normalize_date(
            end_date,
            end_of_day=True
        )

    if output_file is None:

        output_file = (
            REPORTS_DIR
            / "alert_statistics.pdf"
        )

    output_file = Path(
        output_file
    )

    output_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    styles = get_report_styles()

    document = SimpleDocTemplate(
        str(output_file),
        pagesize=landscape(A4),
        rightMargin=12 * mm,
        leftMargin=12 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm
    )

    story = []

    add_report_header(
        story,
        styles,
        "Alert Statistics",
        start_date,
        end_date
    )

    # ========================================================
    # ALERT TYPE STATISTICS
    # ========================================================

    story.append(
        Paragraph(
            "ALERT TYPE STATISTICS",
            styles["SectionHeadingCustom"]
        )
    )

    summaries = get_alert_summary(
        start_date,
        end_date
    )

    statistics_table = [
        [
            "Alert Type",
            "Total",
            "Attended",
            "Cancelled",
            "Active"
        ]
    ]

    for row in summaries:

        statistics_table.append([
            row["alert_type"],
            row["total"] or 0,
            row["attended"] or 0,
            row["cancelled"] or 0,
            row["active"] or 0
        ])

    if len(statistics_table) == 1:

        statistics_table.append([
            "No alerts",
            0,
            0,
            0,
            0
        ])

    story.append(
        create_report_table(
            statistics_table,
            column_widths=[
                55 * mm,
                35 * mm,
                35 * mm,
                35 * mm,
                35 * mm
            ]
        )
    )

    # ========================================================
    # WARD STATISTICS
    # ========================================================

    story.append(
        Paragraph(
            "WARD ALERT STATISTICS",
            styles["SectionHeadingCustom"]
        )
    )

    ward_statistics = get_ward_statistics(
        start_date,
        end_date
    )

    ward_table = [
        [
            "Ward ID",
            "Total Alerts",
            "Attended",
            "Cancelled",
            "Active"
        ]
    ]

    for ward in ward_statistics:

        ward_table.append([
            ward["ward_id"] or "Unassigned",
            ward["total"] or 0,
            ward["attended"] or 0,
            ward["cancelled"] or 0,
            ward["active"] or 0
        ])

    if len(ward_table) == 1:

        ward_table.append([
            "No ward activity",
            0,
            0,
            0,
            0
        ])

    story.append(
        create_report_table(
            ward_table,
            column_widths=[
                50 * mm,
                35 * mm,
                35 * mm,
                35 * mm,
                35 * mm
            ]
        )
    )

    # ========================================================
    # RESPONSE STATISTICS
    # ========================================================

    story.append(
        Paragraph(
            "RESPONSE STATISTICS",
            styles["SectionHeadingCustom"]
        )
    )

    response_statistics = get_response_statistics(
        start_date,
        end_date
    )

    response_table = [
        [
            "Metric",
            "Result"
        ],
        [
            "Total Alerts",
            response_statistics[
                "total_alerts"
            ]
        ],
        [
            "Responded Alerts",
            response_statistics[
                "responded_alerts"
            ]
        ],
        [
            "Unattended Alerts",
            response_statistics[
                "unattended_alerts"
            ]
        ],
        [
            "Average Response",
            response_statistics[
                "average_response_time"
            ]
        ],
        [
            "Fastest Response",
            response_statistics[
                "fastest_response_time"
            ]
        ],
        [
            "Longest Response",
            response_statistics[
                "longest_response_time"
            ]
        ]
    ]

    story.append(
        create_report_table(
            response_table,
            column_widths=[
                75 * mm,
                70 * mm
            ]
        )
    )

    document.build(
        story
    )

    return output_file


# ============================================================
# REPORT DATA SUMMARY
# ============================================================

def get_report_summary(
    report_type="daily",
    report_date=None
):
    """
    Return report statistics as a Python dictionary.

    This is useful for the desktop UI or API without
    generating a PDF.
    """

    start, end = get_report_period(
        report_type,
        report_date
    )

    response_statistics = get_response_statistics(
        start,
        end
    )

    alert_summary = get_alert_summary(
        start,
        end
    )

    ward_statistics = get_ward_statistics(
        start,
        end
    )

    functioning = get_system_functioning()

    issues = get_system_issues(
        start,
        end
    )

    return {
        "report_type": report_type,
        "start": start.strftime(
            "%Y-%m-%d %H:%M:%S"
        ),
        "end": end.strftime(
            "%Y-%m-%d %H:%M:%S"
        ),
        "total_alerts": get_total_alerts(
            start,
            end
        ),
        "alert_summary": [
            dict(row)
            for row in alert_summary
        ],
        "response_statistics":
            response_statistics,
        "ward_statistics": [
            dict(row)
            for row in ward_statistics
        ],
        "system_functioning":
            functioning,
        "system_issues": [
            dict(row)
            for row in issues
        ]
    }


# ============================================================
# GENERATE ALL REPORTS
# ============================================================

def generate_all_reports(
    report_date=None
):
    """
    Generate:

        1. Daily Report
        2. Weekly Report
        3. Monthly Report
        4. Response Report
        5. Alert Statistics Report
    """

    generated_files = []

    generated_files.append(
        generate_daily_report(
            report_date=report_date
        )
    )

    generated_files.append(
        generate_weekly_report(
            report_date=report_date
        )
    )

    generated_files.append(
        generate_monthly_report(
            report_date=report_date
        )
    )

    generated_files.append(
        generate_response_report()
    )

    generated_files.append(
        generate_alert_statistics_report()
    )

    return generated_files


# ============================================================
# TEST / DEVELOPMENT
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        "SMART PATIENT ASSISTANCE AND "
        "EMERGENCY ALERT SYSTEM"
    )

    print(
        "REPORT SERVICE TEST"
    )

    print(
        "=============================================="
    )

    initialize_report_directory()

    print(
        f"Reports directory:"
    )

    print(
        REPORTS_DIR
    )

    print(
        "\nGenerating daily report..."
    )

    try:

        daily_report = generate_daily_report()

        print(
            f"Daily report generated:"
        )

        print(
            daily_report
        )

    except Exception as error:

        print(
            "Unable to generate daily report:"
        )

        print(
            error
        )

    print(
        "=============================================="
    )