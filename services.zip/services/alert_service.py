# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# ALERT SERVICE
# ============================================================
#
# Responsibility:
#
#   Patient ESP32
#        ↓
#   LoRa
#        ↓
#   Hall ESP32
#        ↓
#   USB Serial
#        ↓
#   SerialService
#        ↓
#   AlertService
#        ↓
#   Database
#        ↓
#   Desktop UI / Sound / TTS
#
# IMPORTANT:
#
# This service intentionally does NOT hard-code the final
# ESP32 serial message protocol.
#
# SerialService is responsible for receiving/parsing serial
# data. This service accepts:
#
#   - dictionaries
#   - HallMessage/dataclass objects
#   - other objects exposing the expected fields
#
# The exact SerialService implementation can therefore be
# corrected later during ESP32 testing without redesigning
# the alert processing logic.
#
# ============================================================


import threading
import time
from datetime import datetime
from typing import Any, Callable, Optional


# ============================================================
# PROJECT MODULES
# ============================================================

from models import get_connection


# ============================================================
# CONSTANTS
# ============================================================

DEFAULT_ALERT_STATUS = "ACTIVE"

ASSISTANCE_ALERT = "CALL"
EMERGENCY_ALERT = "EMERGENCY"
CRITICAL_ALERT = "CRITICAL"

PATIENT_ALERT_MESSAGE_TYPES = {
    "PATIENT_ALERT",
    "PATIENT_CALL",
    "ASSISTANCE",
    "EMERGENCY",
    "CRITICAL",
    "CALL",
}


# ============================================================
# ALERT SERVICE
# ============================================================

class AlertService:
    """
    Central service responsible for processing patient alerts.

    SerialService remains responsible for USB/serial reception.

    AlertService is responsible for:

        1. Receiving normalized or semi-normalized messages
        2. Extracting alert information
        3. Resolving device → ward → bed → patient → staff
        4. Storing alerts in SQLite
        5. Updating device communication status
        6. Creating system logs
        7. Notifying the desktop UI
        8. Playing notification sound / TTS
        9. Managing repeated notification
       10. Providing alert lookup functions

    Bedside controls are responsible for changing an active
    alert to ATTENDED or CANCELLED.
    """

    # ========================================================
    # INITIALIZATION
    # ========================================================

    def __init__(
        self,
        on_alert: Optional[Callable[[dict], None]] = None,
        on_connection_change: Optional[Callable[[bool], None]] = None,
        sound_enabled: bool = True,
        volume: int = 100,
        repeat_sound: bool = True,
        repeat_interval: int = 5,
        response_timeout: int = 60,
    ):
        """
        Create AlertService.

        Parameters
        ----------
        on_alert:
            Callback called whenever a new alert is stored.

        on_connection_change:
            Optional callback for Hall Receiver connection changes.

        sound_enabled:
            Enable/disable audible notifications.

        volume:
            TTS volume from 0 to 100.

        repeat_sound:
            Repeat notification while an alert remains ACTIVE.

        repeat_interval:
            Seconds between repeated notifications.

        response_timeout:
            Response timeout in seconds.
        """

        self.on_alert = on_alert

        self.on_connection_change = (
            on_connection_change
        )

        self.sound_enabled = bool(
            sound_enabled
        )

        self.volume = self._safe_volume(
            volume
        )

        self.repeat_sound = bool(
            repeat_sound
        )

        self.repeat_interval = (
            self._safe_positive_int(
                repeat_interval,
                5
            )
        )

        self.response_timeout = (
            self._safe_positive_int(
                response_timeout,
                60
            )
        )

        # ----------------------------------------------------
        # Threading
        # ----------------------------------------------------

        self._lock = threading.RLock()

        self._running = False

        self._notification_thread = None

        # ----------------------------------------------------
        # Active alert tracking
        #
        # Format:
        #
        # {
        #     alert_id: {
        #         "alert": {...},
        #         "created_at": datetime,
        #         "last_notification": datetime
        #     }
        # }
        # ----------------------------------------------------

        self._active_alerts = {}

        # ----------------------------------------------------
        # Text-to-speech engine
        #
        # Created lazily so the application can still start
        # if the TTS engine is unavailable.
        # ----------------------------------------------------

        self._tts_engine = None

        self._tts_lock = threading.Lock()

        self._initialize_tts()


    # ========================================================
    # SAFE VALUE HELPERS
    # ========================================================

    @staticmethod
    def _safe_volume(value):
        """
        Safely convert volume to a value from 0 to 100.
        """

        try:
            value = int(value)
        except (TypeError, ValueError):
            value = 100

        return max(
            0,
            min(
                100,
                value
            )
        )


    @staticmethod
    def _safe_positive_int(value, default):
        """
        Safely convert a value to a positive integer.
        """

        try:
            value = int(value)
        except (TypeError, ValueError):
            return default

        if value <= 0:
            return default

        return value


    # ========================================================
    # TEXT-TO-SPEECH INITIALIZATION
    # ========================================================

    def _initialize_tts(self):
        """
        Initialize pyttsx3 lazily/safely.

        Failure to initialize TTS must never prevent patient
        alerts from being stored in the database.
        """

        try:

            import pyttsx3

            self._tts_engine = pyttsx3.init()

            self._tts_engine.setProperty(
                "volume",
                self.volume / 100.0
            )

        except Exception as error:

            self._tts_engine = None

            print(
                "AlertService: TTS unavailable:",
                error
            )


    # ========================================================
    # START SERVICE
    # ========================================================

    def start(self):
        """
        Start the alert notification monitoring thread.
        """

        with self._lock:

            if self._running:
                return

            self._running = True

            self._notification_thread = (
                threading.Thread(
                    target=self._notification_loop,
                    name="AlertNotificationService",
                    daemon=True
                )
            )

            self._notification_thread.start()

        print(
            "AlertService started."
        )


    # ========================================================
    # STOP SERVICE
    # ========================================================

    def stop(self):
        """
        Stop alert notification monitoring.
        """

        with self._lock:

            self._running = False

        thread = self._notification_thread

        if (
            thread is not None
            and thread.is_alive()
        ):

            thread.join(
                timeout=2
            )

        self._notification_thread = None

        print(
            "AlertService stopped."
        )


    # ========================================================
    # STATUS
    # ========================================================

    def is_running(self):
        """
        Return whether AlertService is running.
        """

        with self._lock:
            return self._running


    # ========================================================
    # NORMALIZE MESSAGE
    # ========================================================

    def normalize_message(self, message):
        """
        Convert a SerialService message into a dictionary.

        Supported input:

            dict

        or an object such as:

            HallMessage(...)

        This deliberately does not depend on the exact
        implementation of SerialService.
        """

        if message is None:
            return None

        # ----------------------------------------------------
        # Already dictionary
        # ----------------------------------------------------

        if isinstance(message, dict):

            return dict(message)

        # ----------------------------------------------------
        # Dataclass/object with attributes
        # ----------------------------------------------------

        fields = (
            "message_type",
            "sender_device_id",
            "receiver_device_id",
            "device_id",
            "ward_id",
            "bed_id",
            "patient_id",
            "staff_id",
            "alert_type",
            "alert_status",
            "timestamp",
            "received_at",
            "payload",
        )

        normalized = {}

        found = False

        for field in fields:

            if hasattr(message, field):

                try:

                    normalized[field] = getattr(
                        message,
                        field
                    )

                    found = True

                except Exception:
                    pass

        if found:

            # ------------------------------------------------
            # Make sender_device_id available as device_id.
            # ------------------------------------------------

            if not normalized.get("device_id"):

                normalized["device_id"] = (
                    normalized.get(
                        "sender_device_id"
                    )
                )

            return normalized

        # ----------------------------------------------------
        # Generic object dictionary
        # ----------------------------------------------------

        if hasattr(
            message,
            "__dict__"
        ):

            try:

                values = dict(
                    vars(message)
                )

                if values:

                    if not values.get(
                        "device_id"
                    ):

                        values["device_id"] = (
                            values.get(
                                "sender_device_id"
                            )
                        )

                    return values

            except Exception:
                pass

        print(
            "AlertService: Unsupported message type:",
            type(message)
        )

        return None


    # ========================================================
    # DETERMINE MESSAGE TYPE
    # ========================================================

    def get_message_type(self, message):
        """
        Determine the message type from a normalized message.
        """

        message_type = (
            message.get("message_type")
            or message.get("message")
            or message.get("type")
            or ""
        )

        return str(
            message_type
        ).strip().upper()


    # ========================================================
    # DETERMINE ALERT TYPE
    # ========================================================

    def get_alert_type(self, message):
        """
        Determine the alert type.

        If the incoming message does not explicitly contain an
        alert type but is clearly a patient alert, CALL is used
        as the default assistance alert.
        """

        alert_type = (
            message.get("alert_type")
            or message.get("call_type")
            or message.get("alert")
        )

        if alert_type:

            return str(
                alert_type
            ).strip().upper()

        message_type = self.get_message_type(
            message
        )

        if message_type in (
            PATIENT_ALERT_MESSAGE_TYPES
        ):

            return ASSISTANCE_ALERT

        return None


    # ========================================================
    # DEVICE ID
    # ========================================================

    def get_device_id(self, message):
        """
        Extract patient ESP32 device ID.
        """

        device_id = (
            message.get("device_id")
            or message.get("sender_device_id")
            or message.get("sender_id")
        )

        if device_id is None:
            return None

        device_id = str(
            device_id
        ).strip()

        return device_id or None


    # ========================================================
    # PATIENT ALERT CHECK
    # ========================================================

    def is_patient_alert(self, message):
        """
        Determine whether a message represents a patient
        assistance/emergency alert.
        """

        message_type = self.get_message_type(
            message
        )

        alert_type = self.get_alert_type(
            message
        )

        if message_type in (
            PATIENT_ALERT_MESSAGE_TYPES
        ):

            return True

        if alert_type in (
            ASSISTANCE_ALERT,
            EMERGENCY_ALERT,
            CRITICAL_ALERT,
        ):

            return True

        return False


    # ========================================================
    # RESOLVE DEVICE ASSIGNMENT
    # ========================================================

    def resolve_device_assignment(
        self,
        connection,
        device_id
    ):
        """
        Resolve:

            Device
              ↓
            Ward
              ↓
            Bed
              ↓
            Patient
              ↓
            Staff
        """

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                da.ward_id,
                da.bed_id,
                p.patient_id,
                pa.staff_id

            FROM device_assignments da

            LEFT JOIN patient_assignments pa
                ON da.bed_id = pa.bed_id

            LEFT JOIN patients p
                ON pa.patient_id = p.patient_id

            WHERE da.device_id = ?

            LIMIT 1
            """,
            (
                device_id,
            )
        )

        return cursor.fetchone()


    # ========================================================
    # UPDATE DEVICE ONLINE STATUS
    # ========================================================

    def mark_device_online(
        self,
        connection,
        device_id
    ):
        """
        Mark a patient ESP32 as online when communication is
        received.
        """

        cursor = connection.cursor()

        cursor.execute(
            """
            UPDATE devices

            SET
                status = 'Online',
                last_seen = CURRENT_TIMESTAMP

            WHERE device_id = ?
            """,
            (
                device_id,
            )
        )


    # ========================================================
    # CREATE SYSTEM LOG
    # ========================================================

    def _add_system_log(
        self,
        event_type,
        description,
        device_id=None,
        ward_id=None,
        bed_id=None,
        patient_id=None
    ):
        """
        Add system log entry.
        """

        connection = get_connection()

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO system_logs (
                    event_type,
                    description,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id
                )

                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    event_type,
                    description,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id
                )
            )

            connection.commit()

        except Exception as error:

            connection.rollback()

            print(
                "AlertService: Unable to create system log:",
                error
            )

        finally:

            connection.close()


    # ========================================================
    # PROCESS PATIENT ALERT
    # ========================================================

    def process_patient_alert(
        self,
        message
    ):
        """
        Process one patient alert.

        Returns
        -------
        dict
            Stored alert information.

        None
            If the message is invalid or cannot be processed.
        """

        # ----------------------------------------------------
        # Normalize
        # ----------------------------------------------------

        message = self.normalize_message(
            message
        )

        if message is None:

            print(
                "AlertService: Invalid message."
            )

            return None

        # ----------------------------------------------------
        # Verify patient alert
        # ----------------------------------------------------

        if not self.is_patient_alert(
            message
        ):

            return None

        # ----------------------------------------------------
        # Extract fields
        # ----------------------------------------------------

        device_id = self.get_device_id(
            message
        )

        alert_type = self.get_alert_type(
            message
        )

        if not device_id:

            print(
                "AlertService: Alert has no device_id."
            )

            return None

        if not alert_type:

            print(
                "AlertService: Alert has no alert_type."
            )

            return None

        # ----------------------------------------------------
        # Incoming optional information
        # ----------------------------------------------------

        ward_id = message.get(
            "ward_id"
        )

        bed_id = message.get(
            "bed_id"
        )

        patient_id = message.get(
            "patient_id"
        )

        staff_id = message.get(
            "staff_id"
        )

        # ----------------------------------------------------
        # Database transaction
        # ----------------------------------------------------

        connection = get_connection()

        cursor = connection.cursor()

        try:

            # ------------------------------------------------
            # Resolve authoritative assignment
            # ------------------------------------------------

            assignment = (
                self.resolve_device_assignment(
                    connection,
                    device_id
                )
            )

            if assignment:

                if not ward_id:

                    ward_id = assignment[
                        "ward_id"
                    ]

                if not bed_id:

                    bed_id = assignment[
                        "bed_id"
                    ]

                if not patient_id:

                    patient_id = assignment[
                        "patient_id"
                    ]

                if not staff_id:

                    staff_id = assignment[
                        "staff_id"
                    ]

            # ------------------------------------------------
            # Device communication status
            # ------------------------------------------------

            self.mark_device_online(
                connection,
                device_id
            )

            # ------------------------------------------------
            # Insert alert
            # ------------------------------------------------

            cursor.execute(
                """
                INSERT INTO alerts (
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    staff_id,
                    alert_type,
                    alert_status
                )

                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    staff_id,
                    alert_type,
                    DEFAULT_ALERT_STATUS
                )
            )

            alert_id = cursor.lastrowid

            # ------------------------------------------------
            # Commit
            # ------------------------------------------------

            connection.commit()

        except Exception as error:

            connection.rollback()

            print(
                "AlertService: Failed to store alert:",
                error
            )

            return None

        finally:

            connection.close()

        # ----------------------------------------------------
        # Build alert object
        # ----------------------------------------------------

        alert = {
            "id": alert_id,

            "device_id": device_id,

            "ward_id": ward_id,

            "bed_id": bed_id,

            "patient_id": patient_id,

            "staff_id": staff_id,

            "alert_type": alert_type,

            "alert_status": DEFAULT_ALERT_STATUS,

            "created_at": (
                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
            ),

            "raw_message": message,
        }

        # ----------------------------------------------------
        # Log event
        # ----------------------------------------------------

        self._add_system_log(
            event_type="PATIENT_ALERT_RECEIVED",

            description=(
                f"Patient alert received from "
                f"device {device_id}: {alert_type}"
            ),

            device_id=device_id,

            ward_id=ward_id,

            bed_id=bed_id,

            patient_id=patient_id
        )

        # ----------------------------------------------------
        # Track active alert
        # ----------------------------------------------------

        with self._lock:

            self._active_alerts[
                alert_id
            ] = {

                "alert": alert,

                "created_at": datetime.now(),

                "last_notification": None,
            }

        # ----------------------------------------------------
        # Notify UI
        # ----------------------------------------------------

        self._notify_ui(
            alert
        )

        # ----------------------------------------------------
        # Initial notification
        # ----------------------------------------------------

        self._notify_user(
            alert
        )

        print(
            "AlertService: Patient alert stored:",
            alert
        )

        return alert


    # ========================================================
    # SERIAL SERVICE CALLBACK
    # ========================================================

    def handle_serial_message(
        self,
        message
    ):
        """
        General entry point for SerialService.

        SerialService can call this method whenever a message
        is received.

        Patient alerts are processed here.

        Non-alert messages are passed to the communication
        handler.
        """

        normalized = self.normalize_message(
            message
        )

        if normalized is None:

            return None

        if self.is_patient_alert(
            normalized
        ):

            return self.process_patient_alert(
                normalized
            )

        self.handle_general_message(
            normalized
        )

        return None


    # ========================================================
    # GENERAL SERIAL MESSAGE
    # ========================================================

    def handle_general_message(
        self,
        message
    ):
        """
        Process non-alert Hall Receiver messages.

        This does not create a patient alert.
        """

        device_id = self.get_device_id(
            message
        )

        if device_id:

            connection = get_connection()

            try:

                self.mark_device_online(
                    connection,
                    device_id
                )

                connection.commit()

            except Exception as error:

                connection.rollback()

                print(
                    "AlertService: "
                    "Unable to update device status:",
                    error
                )

            finally:

                connection.close()

        print(
            "AlertService: General Hall Receiver message:",
            message
        )


    # ========================================================
    # CONNECTION CALLBACK
    # ========================================================

    def handle_connection_change(
        self,
        connected
    ):
        """
        Handle Hall Receiver USB connection state.
        """

        connected = bool(
            connected
        )

        if connected:

            print(
                "AlertService: Hall Receiver connected."
            )

            self._add_system_log(
                event_type=(
                    "HALL_RECEIVER_CONNECTED"
                ),

                description=(
                    "Hall Receiver ESP32 connected "
                    "through USB."
                )
            )

        else:

            print(
                "AlertService: Hall Receiver disconnected."
            )

            self._add_system_log(
                event_type=(
                    "HALL_RECEIVER_DISCONNECTED"
                ),

                description=(
                    "Hall Receiver ESP32 disconnected."
                )
            )

        callback = (
            self.on_connection_change
        )

        if callback is not None:

            try:

                callback(
                    connected
                )

            except Exception as error:

                print(
                    "AlertService: "
                    "Connection callback error:",
                    error
                )


    # ========================================================
    # UI CALLBACK
    # ========================================================

    def _notify_ui(
        self,
        alert
    ):
        """
        Notify desktop UI of a newly received alert.
        """

        callback = self.on_alert

        if callback is None:
            return

        try:

            callback(
                alert
            )

        except Exception as error:

            print(
                "AlertService: UI callback error:",
                error
            )


    # ========================================================
    # NOTIFICATION TEXT
    # ========================================================

    def build_notification_text(
        self,
        alert
    ):
        """
        Build the notification/TTS message.
        """

        alert_type = (
            alert.get(
                "alert_type"
            )
            or "CALL"
        )

        ward_id = (
            alert.get(
                "ward_id"
            )
            or "unknown ward"
        )

        bed_id = (
            alert.get(
                "bed_id"
            )
            or "unknown bed"
        )

        patient_id = (
            alert.get(
                "patient_id"
            )
        )

        if patient_id:

            return (
                f"Patient assistance alert. "
                f"{alert_type}. "
                f"Ward {ward_id}. "
                f"Bed {bed_id}. "
                f"Patient {patient_id}."
            )

        return (
            f"Patient assistance alert. "
            f"{alert_type}. "
            f"Ward {ward_id}. "
            f"Bed {bed_id}."
        )


    # ========================================================
    # NOTIFY USER
    # ========================================================

    def _notify_user(
        self,
        alert
    ):
        """
        Produce audible notification.

        Database storage and UI notification are independent
        of sound/TTS. Therefore an audio failure cannot lose
        an alert.
        """

        if not self.sound_enabled:
            return

        text = self.build_notification_text(
            alert
        )

        # ----------------------------------------------------
        # TTS
        # ----------------------------------------------------

        self._speak(
            text
        )


    # ========================================================
    # SPEAK
    # ========================================================

    def _speak(
        self,
        text
    ):
        """
        Speak a notification using pyttsx3.
        """

        if self._tts_engine is None:

            return

        def speak_worker():

            with self._tts_lock:

                try:

                    self._tts_engine.setProperty(
                        "volume",
                        self.volume / 100.0
                    )

                    self._tts_engine.say(
                        text
                    )

                    self._tts_engine.runAndWait()

                except Exception as error:

                    print(
                        "AlertService: TTS error:",
                        error
                    )

        thread = threading.Thread(
            target=speak_worker,
            name="AlertTTS",
            daemon=True
        )

        thread.start()


    # ========================================================
    # NOTIFICATION LOOP
    # ========================================================

    def _notification_loop(self):
        """
        Monitor active alerts and repeat notifications.

        IMPORTANT:

        This service does NOT change ACTIVE → ATTENDED or
        ACTIVE → CANCELLED.

        Those status changes are controlled by the bedside
        device.

        Therefore an alert remains in this service's active
        tracking until the database says it is no longer
        ACTIVE.
        """

        while True:

            with self._lock:

                if not self._running:

                    break

                active_items = list(
                    self._active_alerts.items()
                )

            now = datetime.now()

            for alert_id, information in active_items:

                alert = information[
                    "alert"
                ]

                # --------------------------------------------
                # Check database status
                # --------------------------------------------

                current_status = (
                    self.get_alert_status(
                        alert_id
                    )
                )

                if current_status is None:

                    self.remove_active_alert(
                        alert_id
                    )

                    continue

                if current_status != "ACTIVE":

                    self.remove_active_alert(
                        alert_id
                    )

                    continue

                # --------------------------------------------
                # Response timeout
                #
                # We log timeout but do not change the alert
                # status.
                # --------------------------------------------

                created_at = information[
                    "created_at"
                ]

                elapsed = (
                    now - created_at
                ).total_seconds()

                if (
                    elapsed
                    >= self.response_timeout
                ):

                    self._handle_response_timeout(
                        alert
                    )

                    # Prevent repeated timeout logs for the
                    # same alert.
                    information[
                        "timeout_logged"
                    ] = True

                # --------------------------------------------
                # Repeated notification
                # --------------------------------------------

                if not self.repeat_sound:
                    continue

                last_notification = (
                    information[
                        "last_notification"
                    ]
                )

                if last_notification is None:

                    should_notify = True

                else:

                    elapsed_notification = (
                        now
                        - last_notification
                    ).total_seconds()

                    should_notify = (
                        elapsed_notification
                        >= self.repeat_interval
                    )

                if should_notify:

                    self._notify_user(
                        alert
                    )

                    with self._lock:

                        if (
                            alert_id
                            in self._active_alerts
                        ):

                            self._active_alerts[
                                alert_id
                            ][
                                "last_notification"
                            ] = datetime.now()

            time.sleep(
                1
            )


    # ========================================================
    # RESPONSE TIMEOUT
    # ========================================================

    def _handle_response_timeout(
        self,
        alert
    ):
        """
        Log an alert response timeout.

        The alert remains ACTIVE.

        Bedside controls still determine whether it becomes
        ATTENDED or CANCELLED.
        """

        alert_id = alert.get(
            "id"
        )

        with self._lock:

            information = (
                self._active_alerts.get(
                    alert_id
                )
            )

            if information is None:
                return

            if information.get(
                "timeout_logged",
                False
            ):

                return

            information[
                "timeout_logged"
            ] = True

        self._add_system_log(

            event_type=(
                "ALERT_RESPONSE_TIMEOUT"
            ),

            description=(
                f"Alert {alert_id} "
                f"has remained active for "
                f"at least "
                f"{self.response_timeout} seconds."
            ),

            device_id=(
                alert.get(
                    "device_id"
                )
            ),

            ward_id=(
                alert.get(
                    "ward_id"
                )
            ),

            bed_id=(
                alert.get(
                    "bed_id"
                )
            ),

            patient_id=(
                alert.get(
                    "patient_id"
                )
            )
        )


    # ========================================================
    # GET ALERT STATUS
    # ========================================================

    def get_alert_status(
        self,
        alert_id
    ):
        """
        Retrieve current database status for an alert.
        """

        connection = get_connection()

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT alert_status
                FROM alerts
                WHERE id = ?
                LIMIT 1
                """,
                (
                    alert_id,
                )
            )

            row = cursor.fetchone()

            if row is None:
                return None

            return row[
                "alert_status"
            ]

        finally:

            connection.close()


    # ========================================================
    # REMOVE ACTIVE ALERT
    # ========================================================

    def remove_active_alert(
        self,
        alert_id
    ):
        """
        Remove an alert from active notification tracking.
        """

        with self._lock:

            self._active_alerts.pop(
                alert_id,
                None
            )


    # ========================================================
    # REFRESH ACTIVE ALERTS
    # ========================================================

    def refresh_active_alerts(self):
        """
        Reload currently ACTIVE alerts from the database.

        Useful when the desktop application starts while alerts
        already exist in the database.
        """

        connection = get_connection()

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    staff_id,
                    alert_type,
                    alert_status,
                    created_at,
                    attended_at

                FROM alerts

                WHERE alert_status = 'ACTIVE'

                ORDER BY datetime(created_at) ASC
                """
            )

            rows = cursor.fetchall()

        finally:

            connection.close()

        with self._lock:

            self._active_alerts.clear()

            for row in rows:

                alert = {
                    "id": row["id"],

                    "device_id": row[
                        "device_id"
                    ],

                    "ward_id": row[
                        "ward_id"
                    ],

                    "bed_id": row[
                        "bed_id"
                    ],

                    "patient_id": row[
                        "patient_id"
                    ],

                    "staff_id": row[
                        "staff_id"
                    ],

                    "alert_type": row[
                        "alert_type"
                    ],

                    "alert_status": row[
                        "alert_status"
                    ],

                    "created_at": row[
                        "created_at"
                    ],
                }

                self._active_alerts[
                    row["id"]
                ] = {

                    "alert": alert,

                    "created_at": (
                        self._parse_datetime(
                            row["created_at"]
                        )
                    ),

                    "last_notification": None,

                    "timeout_logged": False,
                }

        return len(
            rows
        )


    # ========================================================
    # PARSE DATABASE DATETIME
    # ========================================================

    @staticmethod
    def _parse_datetime(
        value
    ):
        """
        Convert SQLite datetime text into datetime.
        """

        if isinstance(
            value,
            datetime
        ):

            return value

        if not value:

            return datetime.now()

        value = str(
            value
        )

        formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S.%f",
        ]

        for fmt in formats:

            try:

                return datetime.strptime(
                    value,
                    fmt
                )

            except ValueError:
                continue

        return datetime.now()


    # ========================================================
    # GET ACTIVE ALERTS
    # ========================================================

    def get_active_alerts(self):
        """
        Return all currently ACTIVE alerts from the database.
        """

        connection = get_connection()

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    staff_id,
                    alert_type,
                    alert_status,
                    created_at,
                    attended_at

                FROM alerts

                WHERE alert_status = 'ACTIVE'

                ORDER BY datetime(created_at) DESC
                """
            )

            rows = cursor.fetchall()

            return [
                dict(row)
                for row in rows
            ]

        finally:

            connection.close()


    # ========================================================
    # GET ALERT
    # ========================================================

    def get_alert(
        self,
        alert_id
    ):
        """
        Return one alert.
        """

        connection = get_connection()

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    staff_id,
                    alert_type,
                    alert_status,
                    created_at,
                    attended_at

                FROM alerts

                WHERE id = ?

                LIMIT 1
                """,
                (
                    alert_id,
                )
            )

            row = cursor.fetchone()

            if row is None:
                return None

            return dict(
                row
            )

        finally:

            connection.close()


    # ========================================================
    # GET RECENT ALERTS
    # ========================================================

    def get_recent_alerts(
        self,
        limit=100
    ):
        """
        Return recent alerts.
        """

        try:

            limit = int(
                limit
            )

        except (
            TypeError,
            ValueError
        ):

            limit = 100

        if limit <= 0:

            limit = 100

        connection = get_connection()

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id,
                    device_id,
                    ward_id,
                    bed_id,
                    patient_id,
                    staff_id,
                    alert_type,
                    alert_status,
                    created_at,
                    attended_at

                FROM alerts

                ORDER BY datetime(created_at) DESC

                LIMIT ?
                """,
                (
                    limit,
                )
            )

            rows = cursor.fetchall()

            return [
                dict(row)
                for row in rows
            ]

        finally:

            connection.close()


    # ========================================================
    # SERVICE STATUS
    # ========================================================

    def get_status(self):
        """
        Return AlertService status.
        """

        with self._lock:

            active_count = len(
                self._active_alerts
            )

            running = self._running

        return {
            "running": running,

            "active_alerts": active_count,

            "sound_enabled": (
                self.sound_enabled
            ),

            "volume": self.volume,

            "repeat_sound": (
                self.repeat_sound
            ),

            "repeat_interval": (
                self.repeat_interval
            ),

            "response_timeout": (
                self.response_timeout
            ),
        }


    # ========================================================
    # UPDATE SOUND SETTINGS
    # ========================================================

    def update_sound_settings(
        self,
        sound_enabled=None,
        volume=None,
        repeat_sound=None,
        repeat_interval=None
    ):
        """
        Update notification behavior at runtime.
        """

        with self._lock:

            if sound_enabled is not None:

                self.sound_enabled = bool(
                    sound_enabled
                )

            if volume is not None:

                self.volume = (
                    self._safe_volume(
                        volume
                    )
                )

                if self._tts_engine is not None:

                    try:

                        self._tts_engine.setProperty(
                            "volume",
                            self.volume / 100.0
                        )

                    except Exception:
                        pass

            if repeat_sound is not None:

                self.repeat_sound = bool(
                    repeat_sound
                )

            if repeat_interval is not None:

                self.repeat_interval = (
                    self._safe_positive_int(
                        repeat_interval,
                        self.repeat_interval
                    )
                )

        return {
            "sound_enabled": (
                self.sound_enabled
            ),

            "volume": self.volume,

            "repeat_sound": (
                self.repeat_sound
            ),

            "repeat_interval": (
                self.repeat_interval
            ),
        }


    # ========================================================
    # UPDATE RESPONSE SETTINGS
    # ========================================================

    def update_response_settings(
        self,
        response_timeout=None
    ):
        """
        Update response timeout.
        """

        if response_timeout is not None:

            self.response_timeout = (
                self._safe_positive_int(
                    response_timeout,
                    self.response_timeout
                )
            )

        return {
            "response_timeout": (
                self.response_timeout
            )
        }


# ============================================================
# OPTIONAL DEFAULT SERVICE INSTANCE
# ============================================================

_alert_service = None

_alert_service_lock = threading.Lock()


# ============================================================
# CREATE / GET SERVICE
# ============================================================

def get_alert_service(
    on_alert=None,
    on_connection_change=None
):
    """
    Return the application's shared AlertService instance.

    The instance is created only once.
    """

    global _alert_service

    with _alert_service_lock:

        if _alert_service is None:

            _alert_service = AlertService(

                on_alert=on_alert,

                on_connection_change=(
                    on_connection_change
                ),
            )

        else:

            if on_alert is not None:

                _alert_service.on_alert = (
                    on_alert
                )

            if (
                on_connection_change
                is not None
            ):

                _alert_service.on_connection_change = (
                    on_connection_change
                )

        return _alert_service


# ============================================================
# START SHARED ALERT SERVICE
# ============================================================

def start_alert_service(
    on_alert=None,
    on_connection_change=None
):
    """
    Start the application's shared AlertService.
    """

    service = get_alert_service(
        on_alert=on_alert,
        on_connection_change=(
            on_connection_change
        )
    )

    service.start()

    return service


# ============================================================
# STOP SHARED ALERT SERVICE
# ============================================================

def stop_alert_service():
    """
    Stop the application's shared AlertService.
    """

    global _alert_service

    with _alert_service_lock:

        service = _alert_service

    if service is not None:

        service.stop()


# ============================================================
# SERIAL CALLBACK HELPERS
# ============================================================

def handle_serial_message(
    message
):
    """
    Convenience callback for SerialService.

    Can be supplied as:

        on_message=handle_serial_message
    """

    service = get_alert_service()

    return service.handle_serial_message(
        message
    )


def handle_patient_call(
    message
):
    """
    Convenience callback for SerialService patient alerts.

    Can be supplied as:

        on_patient_call=handle_patient_call
    """

    service = get_alert_service()

    return service.process_patient_alert(
        message
    )


def handle_connection_change(
    connected
):
    """
    Convenience callback for SerialService connection changes.

    Can be supplied as:

        on_connection_change=handle_connection_change
    """

    service = get_alert_service()

    return service.handle_connection_change(
        connected
    )


# ============================================================
# MODULE TEST
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        "SMART PATIENT ASSISTANCE AND "
        "EMERGENCY ALERT SYSTEM"
    )

    print(
        "ALERT SERVICE TEST"
    )

    print(
        "=============================================="
    )

    service = AlertService()

    print(
        "Service status:"
    )

    print(
        service.get_status()
    )

    print(
        "=============================================="
    )