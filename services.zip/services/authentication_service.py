# ============================================================
# SMART PATIENT ASSISTANCE AND EMERGENCY ALERT SYSTEM
# AUTHENTICATION SERVICE
# ============================================================
#
# Responsibility:
#
#   Desktop UI
#       ↓
#   authentication_service.py
#       ↓
#   main.py authentication functions
#       ↓
#   models.py
#       ↓
#   SQLite database
#
# This service provides the authentication layer used by the
# PySide6 desktop application.
#
# IMPORTANT:
#
#   The database authentication functions already implemented
#   in main.py are reused here.
#
#   This service does NOT create another users table.
#
#   Administrator credentials are stored in:
#
#       admin
#
#   table created by models.py.
#
# ============================================================

from __future__ import annotations

import threading
from datetime import datetime
from typing import Optional, Dict, Any


# ============================================================
# MAIN BACKEND AUTHENTICATION FUNCTIONS
# ============================================================

from main import (
    admin_exists,
    get_admin,
    create_admin,
    login_admin,
    verify_current_password,
    verify_current_username,
    verify_recovery_key,
    change_password,
    change_username,
    reset_password,
    change_recovery_key,
    add_system_log,
)


# ============================================================
# AUTHENTICATION SERVICE
# ============================================================

class AuthenticationService:
    """
    Central authentication service for the desktop application.

    The service provides a clean interface between the GUI and
    the authentication functions implemented in main.py.

    Supported operations:

        - Check administrator configuration
        - First-time administrator setup
        - Administrator login
        - Logout
        - Password verification
        - Username verification
        - Recovery-key verification
        - Password change
        - Username change
        - Recovery-key change
        - Password reset
        - Session information
    """

    # ========================================================
    # INITIALIZATION
    # ========================================================

    def __init__(self):
        """
        Initialize the authentication service.
        """

        self._authenticated = False

        self._username: Optional[str] = None

        self._role: Optional[str] = None

        self._login_time: Optional[datetime] = None

        self._lock = threading.RLock()

    # ========================================================
    # ADMINISTRATOR STATUS
    # ========================================================

    def is_admin_configured(self) -> bool:
        """
        Return True if the administrator account exists.
        """

        try:

            return admin_exists()

        except Exception as error:

            print(
                "Unable to check administrator configuration:",
                error
            )

            return False

    # ========================================================
    # GET ADMINISTRATOR INFORMATION
    # ========================================================

    def get_admin_information(self) -> Optional[Dict[str, Any]]:
        """
        Return safe administrator information.

        Password hashes and recovery-key hashes are deliberately
        NOT returned.
        """

        try:

            admin = get_admin(self._username) if self._username else get_admin()

            if admin is None:
                return None

            return {
                "admin_id": admin["admin_id"],
                "username": admin["username"],
                "created_at": admin["created_at"],
                "updated_at": admin["updated_at"],
            }

        except Exception as error:

            print(
                "Unable to retrieve administrator information:",
                error
            )

            return None

    # ========================================================
    # FIRST-TIME ADMIN SETUP
    # ========================================================

    def setup_admin(
        self,
        username: str,
        password: str,
        recovery_key: str
    ):
        """
        Create the administrator account during first-time setup.

        Returns:

            (True, message)
            (False, error_message)
        """

        username = self._clean_text(username)

        if not username:

            return (
                False,
                "Username cannot be empty."
            )

        if not password:

            return (
                False,
                "Password cannot be empty."
            )

        if not recovery_key:

            return (
                False,
                "Recovery key cannot be empty."
            )

        # ----------------------------------------------------
        # Password validation
        # ----------------------------------------------------

        password_error = self._validate_password(password)

        if password_error:

            return (
                False,
                password_error
            )

        # ----------------------------------------------------
        # Recovery key validation
        # ----------------------------------------------------

        recovery_error = self._validate_recovery_key(
            recovery_key
        )

        if recovery_error:

            return (
                False,
                recovery_error
            )

        # ----------------------------------------------------
        if self.is_admin_configured():
            return False, "First-time setup has already been completed."

        try:

            success, message = create_admin(
                username,
                password,
                recovery_key
            )

            if success:

                self._write_log(
                    event_type="ADMIN_SETUP",
                    description=(
                        "Administrator account created "
                        "during first-time setup."
                    )
                )

            return success, message

        except Exception as error:

            print(
                "Administrator setup error:",
                error
            )

            return (
                False,
                "Unable to create administrator account."
            )

    # ========================================================
    # LOGIN
    # ========================================================

    def login(
        self,
        username: str,
        password: str
    ):
        """
        Authenticate the administrator.

        On successful login, a local desktop session is created.

        Returns:

            (True, message)
            (False, error_message)
        """

        username = self._clean_text(username)

        if not username:

            return (
                False,
                "Username is required."
            )

        if not password:

            return (
                False,
                "Password is required."
            )

        try:

            success, message = login_admin(
                username,
                password
            )

            if not success:

                self._write_log(
                    event_type="ADMIN_LOGIN_FAILED",
                    description=(
                        "Administrator login failed."
                    )
                )

                return (
                    False,
                    message
                )

            # ------------------------------------------------
            # Create authenticated session
            # ------------------------------------------------

            with self._lock:

                self._authenticated = True

                self._username = username

                account = get_admin(username)
                self._role = account["role"] if account and "role" in account.keys() else "ADMIN"

                self._login_time = datetime.now()

            self._write_log(
                event_type="ADMIN_LOGIN",
                description=(
                    "Administrator logged into "
                    "the desktop application."
                )
            )

            return (
                True,
                "Login successful."
            )

        except Exception as error:

            print(
                "Administrator login error:",
                error
            )

            return (
                False,
                "Unable to process administrator login."
            )

    # ========================================================
    # LOGOUT
    # ========================================================

    def logout(self):
        """
        End the current desktop administrator session.
        """

        with self._lock:

            was_authenticated = self._authenticated

            username = self._username

            self._authenticated = False

            self._username = None

            self._role = None

            self._login_time = None

        if was_authenticated:

            self._write_log(
                event_type="ADMIN_LOGOUT",
                description=(
                    f"Administrator '{username}' "
                    "logged out."
                )
            )

        return True, "Logout successful."

    # ========================================================
    # AUTHENTICATION STATE
    # ========================================================

    def is_authenticated(self) -> bool:
        """
        Return True when an administrator is currently logged in.
        """

        with self._lock:

            return self._authenticated

    # ========================================================
    # CURRENT USERNAME
    # ========================================================

    def get_current_username(self) -> Optional[str]:
        """
        Return the username associated with the current session.
        """

        with self._lock:

            return self._username

    def is_primary_administrator(self) -> bool:
        """Only the initial ADMIN account may create a system user."""
        with self._lock:
            return self._authenticated and self._role == "ADMIN"

    # ========================================================
    # LOGIN TIME
    # ========================================================

    def get_login_time(self) -> Optional[datetime]:
        """
        Return the time at which the current session started.
        """

        with self._lock:

            return self._login_time

    # ========================================================
    # SESSION INFORMATION
    # ========================================================

    def get_session(self) -> Dict[str, Any]:
        """
        Return current authentication session information.

        No password or recovery-key information is returned.
        """

        with self._lock:

            return {
                "authenticated":
                    self._authenticated,

                "username":
                    self._username,

                "login_time":
                    (
                        self._login_time.isoformat()
                        if self._login_time is not None
                        else None
                    )
            }

    # ========================================================
    # VERIFY CURRENT PASSWORD
    # ========================================================

    def verify_password(
        self,
        password: str
    ) -> bool:
        """
        Verify the current administrator password.

        This is useful before sensitive operations such as
        changing account credentials.
        """

        if not password:

            return False

        try:

            return verify_current_password(
                password
            )

        except Exception as error:

            print(
                "Password verification error:",
                error
            )

            return False

    # ========================================================
    # VERIFY CURRENT USERNAME
    # ========================================================

    def verify_username(
        self,
        username: str
    ) -> bool:
        """
        Verify the current administrator username.
        """

        username = self._clean_text(username)

        if not username:

            return False

        try:

            return verify_current_username(
                username
            )

        except Exception as error:

            print(
                "Username verification error:",
                error
            )

            return False

    # ========================================================
    # VERIFY RECOVERY KEY
    # ========================================================

    def verify_recovery(
        self,
        recovery_key: str
    ) -> bool:
        """
        Verify the administrator recovery key.
        """

        if not recovery_key:

            return False

        try:

            return verify_recovery_key(
                recovery_key
            )

        except Exception as error:

            print(
                "Recovery-key verification error:",
                error
            )

            return False

    # ========================================================
    # CHANGE PASSWORD
    # ========================================================

    def change_admin_password(
        self,
        current_password: str,
        new_password: str,
        confirm_password: str
    ):
        """
        Change the administrator password.

        The current password must be supplied first.
        """

        if not self.is_authenticated():

            return (
                False,
                "Administrator login is required."
            )

        if not current_password:

            return (
                False,
                "Current password is required."
            )

        if not new_password:

            return (
                False,
                "New password cannot be empty."
            )

        if new_password != confirm_password:

            return (
                False,
                "New passwords do not match."
            )

        password_error = self._validate_password(
            new_password
        )

        if password_error:

            return (
                False,
                password_error
            )

        try:

            success, message = change_password(
                current_password,
                new_password,
                confirm_password
            )

            if success:

                self._write_log(
                    event_type="PASSWORD_CHANGED",
                    description=(
                        "Administrator password "
                        "was changed."
                    )
                )

            return success, message

        except Exception as error:

            print(
                "Password change error:",
                error
            )

            return (
                False,
                "Unable to change administrator password."
            )

    # ========================================================
    # CHANGE USERNAME
    # ========================================================

    def change_admin_username(
        self,
        current_username: str,
        new_username: str,
        confirm_username: str
    ):
        """
        Change the administrator username.
        """

        if not self.is_authenticated():

            return (
                False,
                "Administrator login is required."
            )

        current_username = self._clean_text(
            current_username
        )

        new_username = self._clean_text(
            new_username
        )

        confirm_username = self._clean_text(
            confirm_username
        )

        if not current_username:

            return (
                False,
                "Current username is required."
            )

        if not new_username:

            return (
                False,
                "New username cannot be empty."
            )

        if new_username != confirm_username:

            return (
                False,
                "New usernames do not match."
            )

        try:

            success, message = change_username(
                current_username,
                new_username,
                confirm_username
            )

            if success:

                with self._lock:

                    self._username = new_username

                self._write_log(
                    event_type="USERNAME_CHANGED",
                    description=(
                        "Administrator username "
                        "was changed."
                    )
                )

            return success, message

        except Exception as error:

            print(
                "Username change error:",
                error
            )

            return (
                False,
                "Unable to change administrator username."
            )

    # ========================================================
    # CHANGE RECOVERY KEY
    # ========================================================

    def change_admin_recovery_key(
        self,
        current_recovery_key: str,
        new_recovery_key: str,
        confirm_recovery_key: str
    ):
        """
        Change the administrator recovery key.
        """

        if not self.is_authenticated():

            return (
                False,
                "Administrator login is required."
            )

        if not current_recovery_key:

            return (
                False,
                "Current recovery key is required."
            )

        if not new_recovery_key:

            return (
                False,
                "New recovery key cannot be empty."
            )

        if new_recovery_key != confirm_recovery_key:

            return (
                False,
                "New recovery keys do not match."
            )

        recovery_error = self._validate_recovery_key(
            new_recovery_key
        )

        if recovery_error:

            return (
                False,
                recovery_error
            )

        try:

            success, message = change_recovery_key(
                current_recovery_key,
                new_recovery_key,
                confirm_recovery_key
            )

            if success:

                self._write_log(
                    event_type="RECOVERY_KEY_CHANGED",
                    description=(
                        "Administrator recovery key "
                        "was changed."
                    )
                )

            return success, message

        except Exception as error:

            print(
                "Recovery-key change error:",
                error
            )

            return (
                False,
                "Unable to change recovery key."
            )

    # ========================================================
    # RESET PASSWORD
    # ========================================================

    def reset_admin_password(
        self,
        recovery_key: str,
        new_password: str,
        confirm_password: str
    ):
        """
        Reset the administrator password using the recovery key.

        This operation is intended for the Forgot / Reset
        Password workflow.
        """

        if not recovery_key:

            return (
                False,
                "Recovery key is required."
            )

        if not new_password:

            return (
                False,
                "New password cannot be empty."
            )

        if new_password != confirm_password:

            return (
                False,
                "New passwords do not match."
            )

        password_error = self._validate_password(
            new_password
        )

        if password_error:

            return (
                False,
                password_error
            )

        try:

            success, message = reset_password(
                recovery_key,
                new_password,
                confirm_password
            )

            if success:

                self._write_log(
                    event_type="PASSWORD_RESET",
                    description=(
                        "Administrator password "
                        "was reset using the recovery key."
                    )
                )

            return success, message

        except Exception as error:

            print(
                "Password reset error:",
                error
            )

            return (
                False,
                "Unable to reset administrator password."
            )

    # ========================================================
    # REQUIRE AUTHENTICATION
    # ========================================================

    def require_authentication(self):
        """
        Check whether the administrator is authenticated.

        Returns:

            (True, "Authenticated")
            (False, "Administrator login is required.")
        """

        if not self.is_authenticated():

            return (
                False,
                "Administrator login is required."
            )

        return (
            True,
            "Authenticated."
        )

    # ========================================================
    # ACCOUNT SECURITY CHECK
    # ========================================================

    def account_security_status(self) -> Dict[str, Any]:
        """
        Return basic administrator account status.

        This method intentionally does not expose password
        hashes or recovery-key hashes.
        """

        try:

            configured = self.is_admin_configured()

            admin = self.get_admin_information()

            return {
                "configured": configured,
                "username": (
                    admin["username"]
                    if admin
                    else None
                ),
                "created_at": (
                    admin["created_at"]
                    if admin
                    else None
                ),
                "updated_at": (
                    admin["updated_at"]
                    if admin
                    else None
                ),
                "authenticated":
                    self.is_authenticated()
            }

        except Exception as error:

            print(
                "Unable to retrieve account security status:",
                error
            )

            return {
                "configured": False,
                "username": None,
                "created_at": None,
                "updated_at": None,
                "authenticated": False
            }

    # ========================================================
    # PASSWORD VALIDATION
    # ========================================================

    @staticmethod
    def _validate_password(
        password: str
    ) -> Optional[str]:
        """
        Validate a password.

        The backend already hashes passwords securely using
        Werkzeug.

        This service performs basic application-level validation.
        """

        if not password:

            return "Password cannot be empty."

        if not isinstance(password, str):

            return "Password must be text."

        if len(password) < 8:

            return (
                "Password must contain at least 8 characters."
            )

        if not any(char.islower() for char in password):
            return "Password must include a lowercase letter."

        if not any(char.isupper() for char in password):
            return "Password must include an uppercase letter."

        if not any(char.isdigit() for char in password):
            return "Password must include a number."

        if not any(not char.isalnum() for char in password):
            return "Password must include a special character."

        return None

    # ========================================================
    # RECOVERY KEY VALIDATION
    # ========================================================

    @staticmethod
    def _validate_recovery_key(
        recovery_key: str
    ) -> Optional[str]:
        """
        Validate a recovery key.
        """

        if not recovery_key:

            return (
                "Recovery key cannot be empty."
            )

        if not isinstance(recovery_key, str):

            return (
                "Recovery key must be text."
            )

        if len(recovery_key) < 6:

            return (
                "Recovery key must contain at least "
                "6 characters."
            )

        return None

    # ========================================================
    # TEXT CLEANING
    # ========================================================

    @staticmethod
    def _clean_text(
        value: Any
    ) -> str:
        """
        Safely convert a value to stripped text.
        """

        if value is None:

            return ""

        return str(value).strip()

    # ========================================================
    # SYSTEM LOGGING
    # ========================================================

    @staticmethod
    def _write_log(
        event_type: str,
        description: str
    ):
        """
        Write authentication event to system_logs.

        Logging failure must never break authentication.
        """

        try:

            add_system_log(
                event_type=event_type,
                description=description
            )

        except Exception as error:

            print(
                "Authentication system-log error:",
                error
            )


# ============================================================
# SINGLE SERVICE INSTANCE
# ============================================================

_authentication_service = AuthenticationService()


# ============================================================
# SERVICE ACCESSOR
# ============================================================

def get_authentication_service() -> AuthenticationService:
    """
    Return the application's shared AuthenticationService.

    Example:

        from services.authentication_service import (
            get_authentication_service
        )

        auth = get_authentication_service()

        success, message = auth.login(
            username,
            password
        )
    """

    return _authentication_service


# ============================================================
# CONVENIENCE FUNCTIONS
# ============================================================

def is_admin_configured() -> bool:
    """
    Check whether administrator account exists.
    """

    return _authentication_service.is_admin_configured()


def setup_admin(
    username: str,
    password: str,
    recovery_key: str
):
    """
    Convenience wrapper for first-time administrator setup.
    """

    return _authentication_service.setup_admin(
        username,
        password,
        recovery_key
    )


def login_admin_user(
    username: str,
    password: str
):
    """
    Convenience wrapper for administrator login.
    """

    return _authentication_service.login(
        username,
        password
    )


def logout_admin_user():
    """
    Convenience wrapper for administrator logout.
    """

    return _authentication_service.logout()


def is_authenticated() -> bool:
    """
    Return current authentication state.
    """

    return _authentication_service.is_authenticated()


def get_current_username() -> Optional[str]:
    """
    Return currently authenticated username.
    """

    return _authentication_service.get_current_username()


def verify_password(
    password: str
) -> bool:
    """
    Verify current administrator password.
    """

    return _authentication_service.verify_password(
        password
    )


def verify_username(
    username: str
) -> bool:
    """
    Verify current administrator username.
    """

    return _authentication_service.verify_username(
        username
    )


def verify_recovery_key_user(
    recovery_key: str
) -> bool:
    """
    Verify administrator recovery key.
    """

    return _authentication_service.verify_recovery(
        recovery_key
    )


def change_admin_password(
    current_password: str,
    new_password: str,
    confirm_password: str
):
    """
    Change administrator password.
    """

    return _authentication_service.change_admin_password(
        current_password,
        new_password,
        confirm_password
    )


def change_admin_username(
    current_username: str,
    new_username: str,
    confirm_username: str
):
    """
    Change administrator username.
    """

    return _authentication_service.change_admin_username(
        current_username,
        new_username,
        confirm_username
    )


def change_admin_recovery_key(
    current_recovery_key: str,
    new_recovery_key: str,
    confirm_recovery_key: str
):
    """
    Change administrator recovery key.
    """

    return _authentication_service.change_admin_recovery_key(
        current_recovery_key,
        new_recovery_key,
        confirm_recovery_key
    )


def reset_admin_password(
    recovery_key: str,
    new_password: str,
    confirm_password: str
):
    """
    Reset administrator password using recovery key.
    """

    return _authentication_service.reset_admin_password(
        recovery_key,
        new_password,
        confirm_password
    )


def get_authentication_session() -> Dict[str, Any]:
    """
    Return current authentication session information.
    """

    return _authentication_service.get_session()


# ============================================================
# DIRECT TEST
# ============================================================

if __name__ == "__main__":

    print(
        "=============================================="
    )

    print(
        "SMART PATIENT ASSISTANCE AND "
        "EMERGENCY ALERT SYSTEM"
    )

    print(
        "AUTHENTICATION SERVICE TEST"
    )

    print(
        "=============================================="
    )

    service = get_authentication_service()

    # --------------------------------------------------------
    # Administrator configuration
    # --------------------------------------------------------

    if service.is_admin_configured():

        print(
            "Administrator account: CONFIGURED"
        )

        information = (
            service.get_admin_information()
        )

        if information:

            print(
                "Username:",
                information["username"]
            )

            print(
                "Created:",
                information["created_at"]
            )

    else:

        print(
            "Administrator account: "
            "NOT CONFIGURED"
        )

        print(
            "First-Time Setup is required."
        )

    # --------------------------------------------------------
    # Session status
    # --------------------------------------------------------

    print(
        "Authenticated:",
        service.is_authenticated()
    )

    print(
        "Session:",
        service.get_session()
    )

    print(
        "=============================================="
    )
