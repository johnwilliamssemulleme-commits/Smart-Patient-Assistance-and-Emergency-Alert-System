# websocket.py

import asyncio
import json
import logging
from typing import Any, Dict, Optional, Set

import websockets
from websockets.exceptions import ConnectionClosed


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger("WebSocket")


# ============================================================
# WEBSOCKET SERVICE
# ============================================================

class WebSocketService:
    """
    WebSocket communication service.

    This service does NOT contain patient, device, bed, alert,
    or other application-specific data.

    serial.py will provide the real data later.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8765
    ):
        self.host = host
        self.port = port

        # Currently connected Flutter clients
        self.clients: Set[Any] = set()

        # Server instance
        self.server = None

        # Used to stop the service cleanly
        self.stop_event = asyncio.Event()

        # Lock protects access to the client collection
        self.clients_lock = asyncio.Lock()

    # ========================================================
    # CLIENT CONNECTION
    # ========================================================

    async def handle_client(self, websocket):
        """
        Handles one Flutter client connection.
        """

        async with self.clients_lock:
            self.clients.add(websocket)

        client_address = websocket.remote_address

        logger.info(
            "Client connected: %s",
            client_address
        )

        try:

            # ------------------------------------------------
            # Listen for messages from Flutter
            # ------------------------------------------------

            async for message in websocket:

                await self.handle_client_message(
                    websocket,
                    message
                )

        except ConnectionClosed:
            logger.info(
                "Client disconnected: %s",
                client_address
            )

        except Exception:
            logger.exception(
                "Error handling client: %s",
                client_address
            )

        finally:

            async with self.clients_lock:
                self.clients.discard(websocket)

            logger.info(
                "Connected clients: %d",
                len(self.clients)
            )

    # ========================================================
    # HANDLE DATA FROM FLUTTER
    # ========================================================

    async def handle_client_message(
        self,
        websocket,
        message: str
    ):
        """
        Handles messages received from Flutter.

        No application-specific commands are assumed here.
        """

        try:

            data = json.loads(message)

        except json.JSONDecodeError:

            logger.warning(
                "Received invalid JSON from Flutter."
            )

            return

        # ----------------------------------------------------
        # Pass the received data to the backend if required.
        #
        # This method intentionally does not interpret the
        # contents of the data.
        # ----------------------------------------------------

        logger.info(
            "Data received from Flutter: %s",
            data
        )

    # ========================================================
    # SEND DATA TO ONE CLIENT
    # ========================================================

    async def send_to_client(
        self,
        websocket,
        data: Any
    ) -> bool:
        """
        Sends data to one connected client.
        """

        try:

            message = self.serialize(data)

            await websocket.send(message)

            return True

        except ConnectionClosed:

            return False

        except Exception:

            logger.exception(
                "Failed to send data to client."
            )

            return False

    # ========================================================
    # BROADCAST DATA
    # ========================================================

    async def broadcast(
        self,
        data: Any
    ):
        """
        Sends data received from the backend to every
        connected Flutter client.
        """

        message = self.serialize(data)

        async with self.clients_lock:

            clients = list(self.clients)

        if not clients:

            logger.debug(
                "No Flutter clients connected."
            )

            return

        disconnected = []

        for client in clients:

            try:

                await client.send(message)

            except ConnectionClosed:

                disconnected.append(client)

            except Exception:

                logger.exception(
                    "Failed to send data to a client."
                )

                disconnected.append(client)

        # ----------------------------------------------------
        # Remove disconnected clients
        # ----------------------------------------------------

        if disconnected:

            async with self.clients_lock:

                for client in disconnected:

                    self.clients.discard(client)

        logger.info(
            "Data broadcast to %d client(s).",
            len(clients) - len(disconnected)
        )

    # ========================================================
    # SERIAL DATA ENTRY POINT
    # ========================================================

    async def receive_from_serial(
        self,
        data: Any
    ):
        """
        This is the main entry point that serial.py will use.

        Whatever valid data serial.py produces is forwarded
        to Flutter without changing the application's data.
        """

        logger.info(
            "Data received from serial backend."
        )

        await self.broadcast(data)

    # ========================================================
    # SERIAL DATA ENTRY POINT FROM SYNCHRONOUS CODE
    # ========================================================

    def send_from_serial(
        self,
        data: Any
    ):
        """
        Allows serial.py to submit data from normal
        synchronous Python code.

        Example later:

            websocket_service.send_from_serial(data)

        The method schedules the broadcast on the WebSocket
        event loop.
        """

        try:

            loop = asyncio.get_running_loop()

        except RuntimeError:

            logger.error(
                "WebSocket event loop is not running."
            )

            return

        loop.create_task(
            self.receive_from_serial(data)
        )

    # ========================================================
    # SERIAL DATA VALIDATION
    # ========================================================

    @staticmethod
    def serialize(data: Any) -> str:
        """
        Converts backend data into JSON.

        No application-specific fields are added.
        """

        try:

            return json.dumps(
                data,
                ensure_ascii=False
            )

        except (TypeError, ValueError) as error:

            logger.error(
                "Data cannot be converted to JSON: %s",
                error
            )

            raise

    # ========================================================
    # START SERVER
    # ========================================================

    async def start(self):
        """
        Starts the WebSocket server.
        """

        logger.info(
            "Starting WebSocket service..."
        )

        self.server = await websockets.serve(
            self.handle_client,
            self.host,
            self.port
        )

        logger.info(
            "WebSocket service is running."
        )

        logger.info(
            "Listening on %s:%s",
            self.host,
            self.port
        )

        try:

            # Keep the service running continuously
            await self.stop_event.wait()

        finally:

            await self.stop()

    # ========================================================
    # STOP SERVER
    # ========================================================

    async def stop(self):
        """
        Stops the WebSocket server cleanly.
        """

        logger.info(
            "Stopping WebSocket service..."
        )

        if self.server is not None:

            self.server.close()

            await self.server.wait_closed()

            self.server = None

        async with self.clients_lock:

            clients = list(self.clients)

            self.clients.clear()

        # ----------------------------------------------------
        # Close connected clients
        # ----------------------------------------------------

        for client in clients:

            try:

                await client.close()

            except Exception:

                pass

        logger.info(
            "WebSocket service stopped."
        )

    # ========================================================
    # RUN FOREVER
    # ========================================================

    async def run(self):
        """
        Runs the WebSocket service continuously.
        """

        try:

            await self.start()

        except asyncio.CancelledError:

            logger.info(
                "WebSocket service cancelled."
            )

            await self.stop()

            raise

        except Exception:

            logger.exception(
                "WebSocket service stopped because of an error."
            )

            await self.stop()

            raise


# ============================================================
# GLOBAL SERVICE INSTANCE
# ============================================================

websocket_service: Optional[WebSocketService] = None


# ============================================================
# START FUNCTION
# ============================================================

async def start_websocket():
    """
    Creates and starts the WebSocket service.

    Other backend modules can import the service after
    initialization.
    """

    global websocket_service

    websocket_service = WebSocketService()

    await websocket_service.run()


# ============================================================
# MAIN
# ============================================================

def main():

    logger.info(
        "WebSocket backend starting..."
    )

    try:

        asyncio.run(
            start_websocket()
        )

    except KeyboardInterrupt:

        logger.info(
            "WebSocket backend stopped."
        )


# ============================================================
# PROGRAM ENTRY
# ============================================================

if __name__ == "__main__":
    main()