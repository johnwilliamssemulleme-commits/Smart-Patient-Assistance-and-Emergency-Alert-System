import 'package:flutter/material.dart';

// ============================================================
// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
// main.dart
// ============================================================

// ------------------------------------------------------------
// PUBLIC SCREENS
// ------------------------------------------------------------

import 'ui/live_monitoring.dart';
import 'ui/login.dart';
import 'ui/first_time_setup.dart';

// ------------------------------------------------------------
// AUTHENTICATED SCREENS
// ------------------------------------------------------------

import 'ui/dashboard.dart' as dashboard;
import 'ui/alerts.dart';
import 'ui/patients.dart';
import 'ui/beds_wards.dart';
import 'ui/devices.dart' as devices;
import 'ui/receiver.dart';
import 'ui/reports.dart';
import 'ui/settings.dart';
import 'ui/administration.dart';
import 'ui/logs.dart';

// ============================================================
// MAIN
// ============================================================

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    const SmartPatientApplication(),
  );
}

// ============================================================
// APPLICATION
// ============================================================

class SmartPatientApplication extends StatelessWidget {
  const SmartPatientApplication({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title:
          'SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM',

      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',

        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0878E8),
          brightness: Brightness.light,
        ),

        scaffoldBackgroundColor:
            const Color(0xFFF4F9FD),

        visualDensity: VisualDensity.standard,
      ),

      // ========================================================
      // INITIAL SCREEN
      // ========================================================

      home: const LiveMonitoringScreen(),

      // ========================================================
      // ROUTES
      // ========================================================

      routes: {
        // ------------------------------------------------------
        // LIVE MONITORING
        // ------------------------------------------------------

        '/live-monitoring': (context) {
          return const LiveMonitoringScreen();
        },

        // ------------------------------------------------------
        // LOGIN
        // ------------------------------------------------------

        '/login': (context) {
          return ApplicationWindow(
            child: LoginScreen(),
          );
        },

        // ------------------------------------------------------
        // FIRST TIME SETUP
        // ------------------------------------------------------

        '/first-time-setup': (context) {
          return ApplicationWindow(
            child: FirstTimeSetupScreen(),
          );
        },

        // ------------------------------------------------------
        // DASHBOARD
        // IMPORTANT:
        // dashboard.DashboardScreen()
        // ------------------------------------------------------

        '/dashboard': (context) {
          return ApplicationWindow(
            child: dashboard.DashboardScreen(),
          );
        },

        // ------------------------------------------------------
        // ALERTS
        // ------------------------------------------------------

        '/alerts': (context) {
          return ApplicationWindow(
            child: AlertsScreen(),
          );
        },

        // ------------------------------------------------------
        // PATIENTS
        // ------------------------------------------------------

        '/patients': (context) {
          return ApplicationWindow(
            child: PatientsScreen(),
          );
        },

        // ------------------------------------------------------
        // BEDS / WARDS
        // ------------------------------------------------------

        '/beds-wards': (context) {
          return ApplicationWindow(
            child: BedsWardsScreen(),
          );
        },

        // ------------------------------------------------------
        // DEVICES
        // IMPORTANT:
        // devices.DevicesScreen()
        // ------------------------------------------------------

        '/devices': (context) {
          return ApplicationWindow(
            child: devices.DevicesScreen(),
          );
        },

        // ------------------------------------------------------
        // RECEIVER
        // ------------------------------------------------------

        '/receiver': (context) {
          return ApplicationWindow(
            child: ReceiverScreen(),
          );
        },

        // ------------------------------------------------------
        // REPORTS
        // ------------------------------------------------------

        '/reports': (context) {
          return ApplicationWindow(
            child: ReportsScreen(),
          );
        },

        // ------------------------------------------------------
        // SETTINGS
        // ------------------------------------------------------

        '/settings': (context) {
          return ApplicationWindow(
            child: SettingsScreen(),
          );
        },

        // ------------------------------------------------------
        // ADMINISTRATION
        // ------------------------------------------------------

        '/administration': (context) {
          return ApplicationWindow(
            child: AdministrationScreen(),
          );
        },

        // ------------------------------------------------------
        // LOGS
        // ------------------------------------------------------

        '/logs': (context) {
          return ApplicationWindow(
            child: LogsScreen(),
          );
        },

        // ------------------------------------------------------
        // LOGOUT
        // ------------------------------------------------------

        '/logout': (context) {
          return const LiveMonitoringScreen();
        },
      },

      // ========================================================
      // UNKNOWN ROUTE
      // ========================================================

      onUnknownRoute: (settings) {
        return MaterialPageRoute(
          builder: (context) {
            return const LiveMonitoringScreen();
          },
          settings: settings,
        );
      },
    );
  }
}

// ============================================================
// APPLICATION WINDOW
// ============================================================

class ApplicationWindow extends StatelessWidget {
  const ApplicationWindow({
    super.key,
    required this.child,
  });

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF4F9FD),

      body: Column(
        children: [
          const SystemNameScroller(),

          Expanded(
            child: child,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SYSTEM NAME SCROLLER
// ============================================================

class SystemNameScroller extends StatefulWidget {
  const SystemNameScroller({
    super.key,
  });

  @override
  State<SystemNameScroller> createState() =>
      _SystemNameScrollerState();
}

class _SystemNameScrollerState
    extends State<SystemNameScroller>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  static const String systemName =
      'SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM';

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(
        seconds: 18,
      ),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      width: double.infinity,

      child: DecoratedBox(
        decoration: const BoxDecoration(
          color: Color(0xFF063B68),

          border: Border(
            bottom: BorderSide(
              color: Color(0xFF0B4777),
              width: 1,
            ),
          ),
        ),

        child: ClipRect(
          child: LayoutBuilder(
            builder: (
              context,
              constraints,
            ) {
              const double textWidth = 500;

              return AnimatedBuilder(
                animation: _controller,

                builder: (
                  context,
                  child,
                ) {
                  final double start =
                      constraints.maxWidth;

                  final double end =
                      -textWidth;

                  final double left =
                      start +
                          ((end - start) *
                              _controller.value);

                  return Stack(
                    clipBehavior:
                        Clip.hardEdge,

                    children: [
                      Positioned(
                        left: left,
                        top: 0,
                        bottom: 0,

                        child: Center(
                          child: Text(
                            systemName,
                            maxLines: 1,
                            overflow:
                                TextOverflow.clip,

                            style:
                                const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight:
                                  FontWeight.w700,
                              letterSpacing: 0.2,
                              height: 1.0,
                            ),
                          ),
                        ),
                      ),

                      Positioned(
                        left: left + 570,
                        top: 0,
                        bottom: 0,

                        child: Center(
                          child: Text(
                            systemName,
                            maxLines: 1,
                            overflow:
                                TextOverflow.clip,

                            style:
                                const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight:
                                  FontWeight.w700,
                              letterSpacing: 0.2,
                              height: 1.0,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
