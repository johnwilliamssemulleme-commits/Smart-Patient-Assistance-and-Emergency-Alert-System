import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// dashboard.dart
///
/// SCREEN — DASHBOARD
///
/// Navigation:
/// Home           -> Dashboard
/// Alerts         -> /alerts
/// Patients       -> /patients
/// Bed/Wards      -> /beds-wards
/// Devices        -> /devices
/// Receiver       -> /receiver
/// Reports        -> /reports
/// Logs           -> /logs
/// Settings       -> /settings
/// Administration -> /administration
/// Logout         -> /logout
///
/// All visible text uses 14px.
/// ============================================================

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
      route: null,
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_rounded,
      route: '/alerts',
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline_rounded,
      route: '/patients',
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.bed_outlined,
      route: '/beds-wards',
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_other_outlined,
      route: '/devices',
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
      route: '/receiver',
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_rounded,
      route: '/reports',
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.description_outlined,
      route: '/logs',
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
      route: '/settings',
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
      route: '/administration',
    ),
  ];

  void _handleMenuTap(int index) {
    final item = _menuItems[index];

    setState(() {
      _selectedIndex = index;
    });

    if (item.route == null) {
      return;
    }

    Navigator.pushNamed(
      context,
      item.route!,
    );
  }

  void _logout() {
    Navigator.pushNamed(
      context,
      '/logout',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4FAFE),
      body: SafeArea(
        child: Row(
          children: [
            _DashboardSidebar(
              selectedIndex: _selectedIndex,
              menuItems: _menuItems,
              onMenuTap: _handleMenuTap,
              onLogout: _logout,
            ),
            const Expanded(
              child: _DashboardBody(),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  const _MenuItem({
    required this.title,
    required this.icon,
    required this.route,
  });

  final String title;
  final IconData icon;
  final String? route;
}

// ============================================================
// SIDEBAR
// ============================================================

class _DashboardSidebar extends StatelessWidget {
  const _DashboardSidebar({
    required this.selectedIndex,
    required this.menuItems,
    required this.onMenuTap,
    required this.onLogout,
  });

  final int selectedIndex;
  final List<_MenuItem> menuItems;
  final ValueChanged<int> onMenuTap;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      decoration: const BoxDecoration(
        color: Color(0xFF062E58),
      ),
      child: Column(
        children: [
          const SizedBox(height: 9),

          // ----------------------------------------------------
          // SYSTEM LOGO
          // ----------------------------------------------------

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          // ----------------------------------------------------
          // NAVIGATION
          // ----------------------------------------------------

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected: selectedIndex == index,
                    onTap: () => onMenuTap(index),
                  ),
                );
              },
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          // ----------------------------------------------------
          // LOGOUT
          // ----------------------------------------------------

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: onLogout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() => _SidebarButtonState();
}

class _SidebarButtonState extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final highlighted = widget.selected || _hovering;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,
          constraints: const BoxConstraints(
            minHeight: 42,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: widget.selected
                ? const Color(0xFF0879E8)
                : highlighted
                    ? const Color(0xFF0A416E)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.visible,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// DASHBOARD BODY
// ============================================================

class _DashboardBody extends StatelessWidget {
  const _DashboardBody();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF4FAFE),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(
              9,
              7,
              9,
              8,
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: (constraints.maxHeight - 15)
                    .clamp(0.0, double.infinity),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _DashboardHeader(),
                  SizedBox(height: 7),
                  _SummaryCards(),
                  SizedBox(height: 8),
                  _DashboardTables(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// DASHBOARD HEADER
// ============================================================

class _DashboardHeader extends StatelessWidget {
  const _DashboardHeader();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Expanded(
            child: Text(
              'Overview',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Color(0xFF174C73),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 9,
              vertical: 5,
            ),
            decoration: BoxDecoration(
              color: const Color(0xFFDDF5EA),
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.circle,
                  color: Color(0xFF10A66B),
                  size: 7,
                ),
                SizedBox(width: 5),
                Text(
                  'System Online',
                  style: TextStyle(
                    color: Color(0xFF087C50),
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SUMMARY CARDS
// ============================================================

class _SummaryCards extends StatelessWidget {
  const _SummaryCards();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 650) {
          return const Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _SummaryCard(
                      title: 'Active Alerts',
                      value: '2',
                      icon: Icons.groups_rounded,
                      background: Color(0xFFE52F43),
                    ),
                  ),
                  SizedBox(width: 9),
                  Expanded(
                    child: _SummaryCard(
                      title: 'Assistance',
                      value: '4',
                      icon: Icons.medical_services_outlined,
                      background: Color(0xFFF5B51B),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 9),
              Row(
                children: [
                  Expanded(
                    child: _SummaryCard(
                      title: 'Critical',
                      value: '1',
                      icon: Icons.person_rounded,
                      background: Color(0xFFF18A16),
                    ),
                  ),
                  SizedBox(width: 9),
                  Expanded(
                    child: _SummaryCard(
                      title: 'Emergency',
                      value: '2',
                      icon: Icons.warning_rounded,
                      background: Color(0xFFD91E36),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 9),
              Row(
                children: [
                  Expanded(
                    child: _SummaryCard(
                      title: 'Total Patients',
                      value: '30',
                      icon: Icons.groups_rounded,
                      background: Color(0xFF13A86B),
                    ),
                  ),
                  SizedBox(width: 9),
                  Expanded(
                    child: SizedBox(),
                  ),
                ],
              ),
            ],
          );
        }

        return const Row(
          children: [
            Expanded(
              child: _SummaryCard(
                title: 'Active Alerts',
                value: '2',
                icon: Icons.groups_rounded,
                background: Color(0xFFE52F43),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _SummaryCard(
                title: 'Assistance',
                value: '4',
                icon: Icons.medical_services_outlined,
                background: Color(0xFFF5B51B),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _SummaryCard(
                title: 'Critical',
                value: '1',
                icon: Icons.person_rounded,
                background: Color(0xFFF18A16),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _SummaryCard(
                title: 'Emergency',
                value: '2',
                icon: Icons.warning_rounded,
                background: Color(0xFFD91E36),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _SummaryCard(
                title: 'Total Patients',
                value: '30',
                icon: Icons.groups_rounded,
                background: Color(0xFF13A86B),
              ),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// SUMMARY CARD
// ============================================================

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.background,
  });

  final String title;
  final String value;
  final IconData icon;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 61,
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(5),
        boxShadow: const [
          BoxShadow(
            color: Color(0x16000000),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 25,
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// TABLE AREA
// ============================================================

class _DashboardTables extends StatelessWidget {
  const _DashboardTables();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth >= 850) {
          return const SizedBox(
            height: 280,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: _WardOverviewCard(),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: _RecentAlertsCard(),
                ),
              ],
            ),
          );
        }

        return const Column(
          children: [
            SizedBox(
              height: 280,
              child: _WardOverviewCard(),
            ),
            SizedBox(height: 10),
            SizedBox(
              height: 280,
              child: _RecentAlertsCard(),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// WARD OVERVIEW CARD
// ============================================================

class _WardOverviewCard extends StatelessWidget {
  const _WardOverviewCard();

  @override
  Widget build(BuildContext context) {
    return _DashboardPanel(
      title: 'Ward Overview',
      action: 'View All',
      child: Column(
        children: [
          const _WardHeader(),
          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: const [
                _WardRow(
                  wardType: 'Medical',
                  wardId: 'B-03',
                  patients: '6',
                  active: '1',
                  bedId: '12',
                ),
                _WardRow(
                  wardType: 'Surgical',
                  wardId: 'A-01',
                  patients: '5',
                  active: '0',
                  bedId: '05',
                ),
                _WardRow(
                  wardType: 'General',
                  wardId: 'C-01',
                  patients: '7',
                  active: '1',
                  bedId: '08',
                ),
                _WardRow(
                  wardType: 'Isolation',
                  wardId: 'D-01',
                  patients: '4',
                  active: '0',
                  bedId: '03',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// WARD TABLE HEADER
// ============================================================

class _WardHeader extends StatelessWidget {
  const _WardHeader();

  @override
  Widget build(BuildContext context) {
    const headers = [
      'Ward Type',
      'Ward ID',
      'Patients',
      'Active',
      'Bed ID',
    ];

    const flexes = [
      27,
      18,
      18,
      18,
      19,
    ];

    return SizedBox(
      height: 34,
      child: Row(
        children: List.generate(
          headers.length,
          (index) {
            return Expanded(
              flex: flexes[index],
              child: Text(
                headers[index],
                textAlign: index == 0
                    ? TextAlign.left
                    : TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF59788D),
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// WARD ROW
// ============================================================

class _WardRow extends StatelessWidget {
  const _WardRow({
    required this.wardType,
    required this.wardId,
    required this.patients,
    required this.active,
    required this.bedId,
  });

  final String wardType;
  final String wardId;
  final String patients;
  final String active;
  final String bedId;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 43,
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE7F0F5),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 27,
            child: Text(
              wardType,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF3F637B),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 18,
            child: Text(
              wardId,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 18,
            child: Text(
              patients,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF3F637B),
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 18,
            child: Text(
              active,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: active == '0'
                    ? const Color(0xFF0B9A61)
                    : const Color(0xFFE3263D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 19,
            child: Text(
              bedId,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// RECENT ALERTS CARD
// ============================================================

class _RecentAlertsCard extends StatelessWidget {
  const _RecentAlertsCard();

  @override
  Widget build(BuildContext context) {
    return _DashboardPanel(
      title: 'Recent Alerts',
      action: 'View All',
      child: Column(
        children: [
          const _RecentAlertHeader(),
          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: const [
                _RecentAlertRow(
                  time: '14:31',
                  type: 'Emergency',
                  wardType: 'Medical',
                  wardId: 'B-03',
                  patient: '0012',
                  bedId: '12',
                ),
                _RecentAlertRow(
                  time: '14:28',
                  type: 'Assistance',
                  wardType: 'Surgical',
                  wardId: 'A-01',
                  patient: '0007',
                  bedId: '05',
                ),
                _RecentAlertRow(
                  time: '14:26',
                  type: 'Critical',
                  wardType: 'Medical',
                  wardId: 'B-02',
                  patient: '0009',
                  bedId: '02',
                ),
                _RecentAlertRow(
                  time: '14:20',
                  type: 'Emergency',
                  wardType: 'Medical',
                  wardId: 'B-03',
                  patient: '0015',
                  bedId: '03',
                ),
                _RecentAlertRow(
                  time: '14:12',
                  type: 'Assistance',
                  wardType: 'General',
                  wardId: 'C-01',
                  patient: '0021',
                  bedId: '08',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// RECENT ALERT HEADER
// ============================================================

class _RecentAlertHeader extends StatelessWidget {
  const _RecentAlertHeader();

  @override
  Widget build(BuildContext context) {
    const headers = [
      'Time',
      'Type',
      'Ward Type',
      'Ward ID',
      'Patient',
      'Bed ID',
    ];

    const flexes = [
      14,
      21,
      19,
      16,
      15,
      15,
    ];

    return SizedBox(
      height: 34,
      child: Row(
        children: List.generate(
          headers.length,
          (index) {
            return Expanded(
              flex: flexes[index],
              child: Text(
                headers[index],
                textAlign: index == 0
                    ? TextAlign.left
                    : TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF59788D),
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// RECENT ALERT ROW
// ============================================================

class _RecentAlertRow extends StatelessWidget {
  const _RecentAlertRow({
    required this.time,
    required this.type,
    required this.wardType,
    required this.wardId,
    required this.patient,
    required this.bedId,
  });

  final String time;
  final String type;
  final String wardType;
  final String wardId;
  final String patient;
  final String bedId;

  @override
  Widget build(BuildContext context) {
    Color badgeBackground;
    Color badgeForeground;

    switch (type) {
      case 'Emergency':
        badgeBackground = const Color(0xFFFFE4E7);
        badgeForeground = const Color(0xFFE3263D);
        break;

      case 'Critical':
        badgeBackground = const Color(0xFFFFE9DE);
        badgeForeground = const Color(0xFFE65A18);
        break;

      default:
        badgeBackground = const Color(0xFFFFF1D4);
        badgeForeground = const Color(0xFFC98500);
        break;
    }

    return Container(
      height: 43,
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE7F0F5),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 14,
            child: Text(
              time,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 21,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 6,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: badgeBackground,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  type,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: badgeForeground,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 19,
            child: Text(
              wardType,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 16,
            child: Text(
              wardId,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 15,
            child: Text(
              patient,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 15,
            child: Text(
              bedId,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GENERIC DASHBOARD PANEL
// ============================================================

class _DashboardPanel extends StatelessWidget {
  const _DashboardPanel({
    required this.title,
    required this.child,
    this.action,
  });

  final String title;
  final String? action;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(
        8,
        7,
        8,
        7,
      ),
      child: Column(
        children: [
          SizedBox(
            height: 28,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFF214B69),
                      fontSize: 14,
                      height: 1.0,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                if (action != null)
                  Text(
                    action!,
                    maxLines: 1,
                    style: const TextStyle(
                      color: Color(0xFF0879E8),
                      fontSize: 14,
                      height: 1.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 2),
          Expanded(
            child: child,
          ),
        ],
      ),
    );
  }
}