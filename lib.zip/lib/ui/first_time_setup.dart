import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// first_time_setup.dart
///
/// First Time Setup screen styled to match login.dart.
/// Hospital background image included.
/// Back and Create & Go to Login both return to Login.
/// Regular UI font size: 14
/// ============================================================

class FirstTimeSetupScreen extends StatefulWidget {
  const FirstTimeSetupScreen({
    super.key,
    this.onBack,
    this.onCreateAndLogin,
  });

  final VoidCallback? onBack;

  final void Function(
    String username,
    String password,
    String recoveryKey,
  )? onCreateAndLogin;

  @override
  State<FirstTimeSetupScreen> createState() => _FirstTimeSetupScreenState();
}

class _FirstTimeSetupScreenState extends State<FirstTimeSetupScreen> {
  final TextEditingController _usernameController =
      TextEditingController();

  final TextEditingController _passwordController =
      TextEditingController();

  final TextEditingController _recoveryController =
      TextEditingController();

  bool _showPassword = false;

  bool _backHover = false;
  bool _createHover = false;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _recoveryController.dispose();
    super.dispose();
  }

  // ==========================================================
  // BACK -> LOGIN
  // ==========================================================

  void _goToLogin() {
    if (widget.onBack != null) {
      widget.onBack!();
      return;
    }

    Navigator.of(context).pushReplacementNamed('/login');
  }

  // ==========================================================
  // CREATE ACCOUNT -> LOGIN
  // ==========================================================

  void _createAccount() {
    if (_usernameController.text.trim().isEmpty) {
      _showMessage('Please enter an administrator username.');
      return;
    }

    if (_passwordController.text.isEmpty) {
      _showMessage('Please enter a password.');
      return;
    }

    if (_recoveryController.text.trim().isEmpty) {
      _showMessage('Please enter a recovery key.');
      return;
    }

    widget.onCreateAndLogin?.call(
      _usernameController.text.trim(),
      _passwordController.text,
      _recoveryController.text.trim(),
    );

    Navigator.of(context).pushReplacementNamed('/login');
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ====================================================
          // HOSPITAL BACKGROUND IMAGE
          // ====================================================

          Image.asset(
            'assets/images/hospital.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                color: const Color(0xFFEAF3F9),
                child: const Center(
                  child: Text(
                    'Hospital background image not found',
                    style: TextStyle(
                      color: Color(0xFF31556D),
                      fontSize: 16,
                    ),
                  ),
                ),
              );
            },
          ),

          // ====================================================
          // LIGHT OVERLAY
          // ====================================================

          Container(
            color: const Color(0x18002545),
          ),

          // ====================================================
          // SETUP CARD
          // ====================================================

          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 30,
              ),
              child: _setupCard(),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // SETUP CARD
  // ==========================================================

  Widget _setupCard() {
    return Container(
      width: 760,
      padding: const EdgeInsets.fromLTRB(
        38,
        32,
        38,
        28,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: const Color(0xFFD3E3EC),
          width: 1,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x60000000),
            blurRadius: 25,
            spreadRadius: 1,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ====================================================
          // LOGO + TITLE
          // ====================================================

          Center(
            child: Column(
              children: [
                Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    color: const Color(0xFF07539F),
                    borderRadius: BorderRadius.circular(11),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x35000000),
                        blurRadius: 7,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.admin_panel_settings_outlined,
                    color: Colors.white,
                    size: 40,
                  ),
                ),

                const SizedBox(height: 18),

                const Text(
                  'First Time Setup',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF06427D),
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    height: 1.12,
                  ),
                ),

                const SizedBox(height: 7),

                const Text(
                  'Create your administrator account to get started',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF4383BD),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 22),

          // ====================================================
          // DIVIDER
          // ====================================================

          Container(
            width: double.infinity,
            height: 1,
            color: const Color(0xFFDCE8EF),
          ),

          const SizedBox(height: 22),

          // ====================================================
          // INFORMATION BOX
          // ====================================================

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFF0F8FD),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: const Color(0xFFD0E5F1),
              ),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.info_outline,
                  color: Color(0xFF0879E8),
                  size: 21,
                ),

                SizedBox(width: 10),

                Expanded(
                  child: Text(
                    'The first account created will be the system '
                    'administrator. Use a secure password and keep '
                    'your recovery key safe.',
                    style: TextStyle(
                      color: Color(0xFF42677F),
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 22),

          // ====================================================
          // FORM
          // ====================================================

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // =================================================
              // USERNAME + PASSWORD
              // =================================================

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _fieldLabel(
                      Icons.person,
                      'Admin Username',
                    ),

                    const SizedBox(height: 8),

                    _inputField(
                      controller: _usernameController,
                      hintText: 'Enter admin username',
                      icon: Icons.person_outline,
                    ),

                    const SizedBox(height: 19),

                    _fieldLabel(
                      Icons.lock,
                      'Password',
                    ),

                    const SizedBox(height: 8),

                    _inputField(
                      controller: _passwordController,
                      hintText: 'Enter password',
                      icon: Icons.lock_outline,
                      obscureText: !_showPassword,
                      suffixIcon: IconButton(
                        tooltip: _showPassword
                            ? 'Hide password'
                            : 'Show password',
                        onPressed: () {
                          setState(() {
                            _showPassword = !_showPassword;
                          });
                        },
                        icon: Icon(
                          _showPassword
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          size: 20,
                          color: const Color(0xFF557A96),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 20),

              // =================================================
              // RECOVERY KEY
              // =================================================

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _fieldLabel(
                      Icons.key,
                      'Recovery Key',
                    ),

                    const SizedBox(height: 8),

                    _inputField(
                      controller: _recoveryController,
                      hintText: 'Enter recovery key',
                      icon: Icons.key_outlined,
                    ),

                    const SizedBox(height: 12),

                    const Text(
                      'Keep your recovery key secure. It can be used '
                      'to recover access to the administrator account.',
                      style: TextStyle(
                        color: Color(0xFF7891A1),
                        fontSize: 14,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 28),

          // ====================================================
          // BOTTOM-RIGHT BUTTONS ONLY
          // ====================================================

          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              // ------------------------------------------------
              // BACK
              // ------------------------------------------------

              _actionButton(
                label: 'Back',
                icon: Icons.arrow_back,
                filled: false,
                hovered: _backHover,
                onEnter: () {
                  setState(() {
                    _backHover = true;
                  });
                },
                onExit: () {
                  setState(() {
                    _backHover = false;
                  });
                },
                onTap: _goToLogin,
              ),

              const SizedBox(width: 10),

              // ------------------------------------------------
              // CREATE & GO TO LOGIN
              // ------------------------------------------------

              _actionButton(
                label: 'Create & Go to Login',
                icon: Icons.check_circle_outline,
                filled: true,
                hovered: _createHover,
                width: 210,
                onEnter: () {
                  setState(() {
                    _createHover = true;
                  });
                },
                onExit: () {
                  setState(() {
                    _createHover = false;
                  });
                },
                onTap: _createAccount,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // FIELD LABEL
  // ==========================================================

  Widget _fieldLabel(
    IconData icon,
    String label,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: const Color(0xFF124B76),
        ),

        const SizedBox(width: 7),

        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF23465D),
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  // ==========================================================
  // INPUT FIELD
  // ==========================================================

  Widget _inputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    bool obscureText = false,
    Widget? suffixIcon,
  }) {
    return SizedBox(
      height: 48,
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),
        decoration: InputDecoration(
          hintText: hintText,

          hintStyle: const TextStyle(
            color: Color(0xFFA1B6C5),
            fontSize: 14,
          ),

          prefixIcon: Icon(
            icon,
            size: 19,
            color: const Color(0xFF9AB0C0),
          ),

          suffixIcon: suffixIcon,

          filled: true,
          fillColor: Colors.white,

          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),

          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // ACTION BUTTON
  // ==========================================================

  Widget _actionButton({
    required String label,
    required IconData icon,
    required bool filled,
    required bool hovered,
    required VoidCallback onEnter,
    required VoidCallback onExit,
    required VoidCallback onTap,
    double? width,
  }) {
    final Color background;

    if (filled) {
      background = hovered
          ? const Color(0xFF066FD5)
          : const Color(0xFF0879E8);
    } else {
      background = hovered
          ? const Color(0xFFE1EDF5)
          : Colors.white;
    }

    final Color foreground = filled
        ? Colors.white
        : const Color(0xFF16486B);

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => onEnter(),
      onExit: (_) => onExit(),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: width ?? 90,
          height: 45,
          padding: const EdgeInsets.symmetric(
            horizontal: 14,
          ),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: filled
                  ? (hovered
                      ? const Color(0xFF066FD5)
                      : const Color(0xFF0879E8))
                  : const Color(0xFFD0E0EA),
            ),
            boxShadow: filled
                ? const [
                    BoxShadow(
                      color: Color(0x300879E8),
                      blurRadius: 6,
                      offset: Offset(0, 3),
                    ),
                  ]
                : const [
                    BoxShadow(
                      color: Color(0x18000000),
                      blurRadius: 5,
                      offset: Offset(0, 2),
                    ),
                  ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: foreground,
                size: 18,
              ),

              const SizedBox(width: 7),

              Text(
                label,
                style: TextStyle(
                  color: foreground,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}