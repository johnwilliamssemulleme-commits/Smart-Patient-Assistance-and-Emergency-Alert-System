import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// alerts.dart
///
/// SCREEN — ALERTS & EVENTS
///
/// Columns:
/// Time | Type | Ward Type | Ward ID | Patient
/// Bed ID | Device | Status | Action
///
/// Navigation:
/// Home           -> /dashboard
/// Alerts         -> /alerts
/// Patients       -> /patients
/// Bed/Wards      -> /beds-wards
/// Devices        -> /devices
/// Receiver       -> /receiver
/// Reports        -> /reports
/// Logs           -> /logs
/// Settings       -> /settings
/// Administration -> /administration
/// Logout         -> /logout
///
/// All visible text uses 14px.
/// ============================================================

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({
    super.key,
  });

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {
  int _selectedFilter = 0;
  int _currentPage = 1;

  final List<_AlertData> _alerts = const [
    _AlertData(
      time: '14:31',
      type: 'Emergency',
      wardType: 'Medical',
      wardId: 'B-03',
      patient: '0012',
      bedId: '12',
      device: 'D-014',
      status: 'Active',
    ),
    _AlertData(
      time: '14:28',
      type: 'Assistance',
      wardType: 'Surgical',
      wardId: 'A-01',
      patient: '0007',
      bedId: '05',
      device: 'D-006',
      status: 'Active',
    ),
    _AlertData(
      time: '14:26',
      type: 'Critical',
      wardType: 'Medical',
      wardId: 'B-02',
      patient: '0009',
      bedId: '02',
      device: 'D-012',
      status: 'Active',
    ),
    _AlertData(
      time: '14:20',
      type: 'Emergency',
      wardType: 'Medical',
      wardId: 'B-03',
      patient: '0015',
      bedId: '03',
      device: 'D-015',
      status: 'Resolved',
    ),
    _AlertData(
      time: '14:12',
      type: 'Assistance',
      wardType: 'General',
      wardId: 'C-01',
      patient: '0021',
      bedId: '08',
      device: 'D-009',
      status: 'Resolved',
    ),
  ];

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
      route: '/dashboard',
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_rounded,
      route: '/alerts',
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline_rounded,
      route: '/patients',
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.bed_outlined,
      route: '/beds-wards',
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_other_outlined,
      route: '/devices',
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
      route: '/receiver',
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_rounded,
      route: '/reports',
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.description_outlined,
      route: '/logs',
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
      route: '/settings',
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
      route: '/administration',
    ),
  ];

  List<_AlertData> get _filteredAlerts {
    switch (_selectedFilter) {
      case 1:
        return _alerts
            .where((alert) => alert.type == 'Emergency')
            .toList();

      case 2:
        return _alerts
            .where((alert) => alert.type == 'Critical')
            .toList();

      case 3:
        return _alerts
            .where((alert) => alert.type == 'Assistance')
            .toList();

      default:
        return _alerts;
    }
  }

  void _handleMenuTap(int index) {
    final item = _menuItems[index];

    if (item.route == null) {
      return;
    }

    Navigator.pushNamed(
      context,
      item.route!,
    );
  }

  void _logout() {
    Navigator.pushNamed(
      context,
      '/logout',
    );
  }

  void _changeFilter(int index) {
    setState(() {
      _selectedFilter = index;
      _currentPage = 1;
    });
  }

  void _viewAlert(_AlertData alert) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Alert Details',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _DetailLine(
                label: 'Time',
                value: alert.time,
              ),
              _DetailLine(
                label: 'Type',
                value: alert.type,
              ),
              _DetailLine(
                label: 'Ward Type',
                value: alert.wardType,
              ),
              _DetailLine(
                label: 'Ward ID',
                value: alert.wardId,
              ),
              _DetailLine(
                label: 'Patient',
                value: alert.patient,
              ),
              _DetailLine(
                label: 'Bed ID',
                value: alert.bedId,
              ),
              _DetailLine(
                label: 'Device',
                value: alert.device,
              ),
              _DetailLine(
                label: 'Status',
                value: alert.status,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text(
                'Close',
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _exportAlerts() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Alerts export requested.',
          style: TextStyle(
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4FAFE),
      body: SafeArea(
        child: Row(
          children: [
            _AlertsSidebar(
              selectedIndex: 1,
              menuItems: _menuItems,
              onMenuTap: _handleMenuTap,
              onLogout: _logout,
            ),

            Expanded(
              child: _AlertsBody(
                selectedFilter: _selectedFilter,
                currentPage: _currentPage,
                alerts: _filteredAlerts,
                onExport: _exportAlerts,
                onFilterChanged: _changeFilter,
                onView: _viewAlert,
                onPageChanged: (page) {
                  setState(() {
                    _currentPage = page;
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  const _MenuItem({
    required this.title,
    required this.icon,
    required this.route,
  });

  final String title;
  final IconData icon;
  final String? route;
}

// ============================================================
// ALERTS SIDEBAR
// ============================================================

class _AlertsSidebar extends StatelessWidget {
  const _AlertsSidebar({
    required this.selectedIndex,
    required this.menuItems,
    required this.onMenuTap,
    required this.onLogout,
  });

  final int selectedIndex;
  final List<_MenuItem> menuItems;
  final ValueChanged<int> onMenuTap;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    return Container(
      // Wider than the dashboard version so
      // "Administration" is fully visible.
      width: 180,
      decoration: const BoxDecoration(
        color: Color(0xFF062E58),
      ),
      child: Column(
        children: [
          const SizedBox(height: 9),

          // ----------------------------------------------------
          // SYSTEM LOGO
          // ----------------------------------------------------

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          // ----------------------------------------------------
          // NAVIGATION
          // ----------------------------------------------------

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected: selectedIndex == index,
                    onTap: () => onMenuTap(index),
                  ),
                );
              },
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          // ----------------------------------------------------
          // LOGOUT
          // ----------------------------------------------------

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: onLogout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() => _SidebarButtonState();
}

class _SidebarButtonState extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final highlighted = widget.selected || _hovering;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,

          constraints: const BoxConstraints(
            minHeight: 42,
          ),

          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),

          decoration: BoxDecoration(
            color: widget.selected
                ? const Color(0xFF0879E8)
                : highlighted
                    ? const Color(0xFF0A416E)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),

          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),

              const SizedBox(width: 9),

              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.visible,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ALERTS BODY
// ============================================================

class _AlertsBody extends StatelessWidget {
  const _AlertsBody({
    required this.selectedFilter,
    required this.currentPage,
    required this.alerts,
    required this.onExport,
    required this.onFilterChanged,
    required this.onView,
    required this.onPageChanged,
  });

  final int selectedFilter;
  final int currentPage;
  final List<_AlertData> alerts;
  final VoidCallback onExport;
  final ValueChanged<int> onFilterChanged;
  final ValueChanged<_AlertData> onView;
  final ValueChanged<int> onPageChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF4FAFE),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          9,
          7,
          9,
          8,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _AlertsHeader(
              onExport: onExport,
            ),

            const SizedBox(height: 7),

            _AlertsToolbar(
              selectedFilter: selectedFilter,
              onFilterChanged: onFilterChanged,
            ),

            const SizedBox(height: 7),

            Expanded(
              child: _AlertsTable(
                alerts: alerts,
                onView: onView,
              ),
            ),

            const SizedBox(height: 7),

            _Pagination(
              currentPage: currentPage,
              onPageChanged: onPageChanged,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ALERT DATA
// ============================================================

class _AlertData {
  const _AlertData({
    required this.time,
    required this.type,
    required this.wardType,
    required this.wardId,
    required this.patient,
    required this.bedId,
    required this.device,
    required this.status,
  });

  final String time;
  final String type;
  final String wardType;
  final String wardId;
  final String patient;
  final String bedId;
  final String device;
  final String status;
}

// ============================================================
// HEADER
// ============================================================

class _AlertsHeader extends StatelessWidget {
  const _AlertsHeader({
    required this.onExport,
  });

  final VoidCallback onExport;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'Alerts & Events',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Color(0xFF174C73),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),

          const SizedBox(width: 10),

          OutlinedButton.icon(
            onPressed: onExport,
            icon: const Icon(
              Icons.file_download_outlined,
              size: 15,
            ),
            label: const Text(
              'Export',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF0879E8),
              side: const BorderSide(
                color: Color(0xFFBFDDF0),
              ),
              backgroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 9,
                vertical: 6,
              ),
              minimumSize: const Size(
                72,
                30,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// TOOLBAR
// ============================================================

class _AlertsToolbar extends StatelessWidget {
  const _AlertsToolbar({
    required this.selectedFilter,
    required this.onFilterChanged,
  });

  final int selectedFilter;
  final ValueChanged<int> onFilterChanged;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 34,
      child: Row(
        children: [
          _FilterButton(
            label: 'All 5',
            selected: selectedFilter == 0,
            onTap: () => onFilterChanged(0),
          ),

          const SizedBox(width: 6),

          _FilterButton(
            label: 'Emergency 2',
            selected: selectedFilter == 1,
            onTap: () => onFilterChanged(1),
          ),

          const SizedBox(width: 6),

          _FilterButton(
            label: 'Critical 1',
            selected: selectedFilter == 2,
            onTap: () => onFilterChanged(2),
          ),

          const SizedBox(width: 6),

          _FilterButton(
            label: 'Assistance 2',
            selected: selectedFilter == 3,
            onTap: () => onFilterChanged(3),
          ),

          const Spacer(),

          SizedBox(
            width: 185,
            height: 32,
            child: TextField(
              style: const TextStyle(
                fontSize: 14,
                color: Color(0xFF45677D),
              ),
              decoration: InputDecoration(
                hintText: 'Search alerts...',
                hintStyle: const TextStyle(
                  fontSize: 14,
                  color: Color(0xFF8AA3B4),
                ),
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  size: 15,
                  color: Color(0xFF5591B8),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 0,
                ),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4),
                  borderSide: const BorderSide(
                    color: Color(0xFFD1E6F2),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4),
                  borderSide: const BorderSide(
                    color: Color(0xFFD1E6F2),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4),
                  borderSide: const BorderSide(
                    color: Color(0xFF0879E8),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// FILTER BUTTON
// ============================================================

class _FilterButton extends StatelessWidget {
  const _FilterButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(4),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: selected
                ? const Color(0xFF0879E8)
                : Colors.white,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: selected
                  ? const Color(0xFF0879E8)
                  : const Color(0xFFD1E6F2),
            ),
          ),
          child: Text(
            label,
            maxLines: 1,
            softWrap: false,
            style: TextStyle(
              color: selected
                  ? Colors.white
                  : const Color(0xFF39718F),
              fontSize: 14,
              height: 1.0,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ALERTS TABLE
// ============================================================

class _AlertsTable extends StatelessWidget {
  const _AlertsTable({
    required this.alerts,
    required this.onView,
  });

  final List<_AlertData> alerts;
  final ValueChanged<_AlertData> onView;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SizedBox(
              width: constraints.maxWidth < 1050
                  ? 1050
                  : constraints.maxWidth,
              child: Column(
                children: [
                  const _AlertTableHeader(),

                  const Divider(
                    height: 1,
                    thickness: 1,
                    color: Color(0xFFDCECF6),
                  ),

                  Expanded(
                    child: ListView.builder(
                      padding: EdgeInsets.zero,
                      itemCount: alerts.length,
                      itemBuilder: (context, index) {
                        return _AlertTableRow(
                          alert: alerts[index],
                          onView: () => onView(
                            alerts[index],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// TABLE HEADER
// ============================================================

class _AlertTableHeader extends StatelessWidget {
  const _AlertTableHeader();

  static const List<String> _headers = [
    'Time',
    'Type',
    'Ward Type',
    'Ward ID',
    'Patient',
    'Bed ID',
    'Device',
    'Status',
    'Action',
  ];

  static const List<int> _flexes = [
    9,
    15,
    13,
    10,
    10,
    9,
    11,
    13,
    10,
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
      ),
      color: const Color(0xFFFBFDFF),
      child: Row(
        children: List.generate(
          _headers.length,
          (index) {
            return Expanded(
              flex: _flexes[index],
              child: Text(
                _headers[index],
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: index == 0
                    ? TextAlign.left
                    : TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF59788D),
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// TABLE ROW
// ============================================================

class _AlertTableRow extends StatelessWidget {
  const _AlertTableRow({
    required this.alert,
    required this.onView,
  });

  final _AlertData alert;
  final VoidCallback onView;

  static const List<int> _flexes = [
    9,
    15,
    13,
    10,
    10,
    9,
    11,
    13,
    10,
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 43,
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE7F0F5),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: _flexes[0],
            child: Text(
              alert.time,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[1],
            child: Center(
              child: _TypeBadge(
                type: alert.type,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[2],
            child: Text(
              alert.wardType,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[3],
            child: Text(
              alert.wardId,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[4],
            child: Text(
              alert.patient,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),

          // ----------------------------------------------------
          // BED ID
          // ----------------------------------------------------

          Expanded(
            flex: _flexes[5],
            child: Text(
              alert.bedId,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[6],
            child: Text(
              alert.device,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[7],
            child: Center(
              child: _StatusBadge(
                status: alert.status,
              ),
            ),
          ),

          Expanded(
            flex: _flexes[8],
            child: Center(
              child: _ViewButton(
                onTap: onView,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// TYPE BADGE
// ============================================================

class _TypeBadge extends StatelessWidget {
  const _TypeBadge({
    required this.type,
  });

  final String type;

  @override
  Widget build(BuildContext context) {
    Color background;
    Color foreground;

    switch (type) {
      case 'Emergency':
        background = const Color(0xFFFFE4E7);
        foreground = const Color(0xFFE3263D);
        break;

      case 'Critical':
        background = const Color(0xFFFFE9DE);
        foreground = const Color(0xFFE65A18);
        break;

      default:
        background = const Color(0xFFFFF1D4);
        foreground = const Color(0xFFC98500);
    }

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        type,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: foreground,
          fontSize: 14,
          height: 1.0,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// ============================================================
// STATUS BADGE
// ============================================================

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({
    required this.status,
  });

  final String status;

  @override
  Widget build(BuildContext context) {
    final bool resolved = status == 'Resolved';

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: resolved
            ? const Color(0xFFDDF7EC)
            : const Color(0xFFDDF7EC),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        status,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Color(0xFF0B9A61),
          fontSize: 14,
          height: 1.0,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// ============================================================
// VIEW BUTTON
// ============================================================

class _ViewButton extends StatefulWidget {
  const _ViewButton({
    required this.onTap,
  });

  final VoidCallback onTap;

  @override
  State<_ViewButton> createState() => _ViewButtonState();
}

class _ViewButtonState extends State<_ViewButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 120,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 9,
            vertical: 5,
          ),
          decoration: BoxDecoration(
            color: _hovering
                ? const Color(0xFF0879E8)
                : const Color(0xFFEAF6FD),
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: _hovering
                  ? const Color(0xFF0879E8)
                  : const Color(0xFFCBE6F4),
            ),
          ),
          child: Text(
            'View',
            style: TextStyle(
              color: _hovering
                  ? Colors.white
                  : const Color(0xFF0879E8),
              fontSize: 14,
              height: 1.0,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// PAGINATION
// ============================================================

class _Pagination extends StatelessWidget {
  const _Pagination({
    required this.currentPage,
    required this.onPageChanged,
  });

  final int currentPage;
  final ValueChanged<int> onPageChanged;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 27,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          _PageButton(
            icon: Icons.chevron_left_rounded,
            enabled: currentPage > 1,
            onTap: () {
              if (currentPage > 1) {
                onPageChanged(
                  currentPage - 1,
                );
              }
            },
          ),

          const SizedBox(width: 4),

          _PageNumberButton(
            number: 1,
            selected: currentPage == 1,
            onTap: () => onPageChanged(1),
          ),

          const SizedBox(width: 4),

          _PageNumberButton(
            number: 2,
            selected: currentPage == 2,
            onTap: () => onPageChanged(2),
          ),

          const SizedBox(width: 4),

          _PageNumberButton(
            number: 3,
            selected: currentPage == 3,
            onTap: () => onPageChanged(3),
          ),

          const SizedBox(width: 4),

          _PageButton(
            icon: Icons.chevron_right_rounded,
            enabled: currentPage < 3,
            onTap: () {
              if (currentPage < 3) {
                onPageChanged(
                  currentPage + 1,
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

// ============================================================
// PAGE BUTTON
// ============================================================

class _PageButton extends StatelessWidget {
  const _PageButton({
    required this.icon,
    required this.enabled,
    required this.onTap,
  });

  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(4),
        child: Container(
          width: 27,
          height: 27,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: const Color(0xFFD1E6F2),
            ),
          ),
          child: Icon(
            icon,
            size: 17,
            color: enabled
                ? const Color(0xFF39718F)
                : const Color(0xFFB8C9D4),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// PAGE NUMBER BUTTON
// ============================================================

class _PageNumberButton extends StatelessWidget {
  const _PageNumberButton({
    required this.number,
    required this.selected,
    required this.onTap,
  });

  final int number;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(4),
        child: Container(
          width: 27,
          height: 27,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: selected
                ? const Color(0xFF0879E8)
                : Colors.white,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: selected
                  ? const Color(0xFF0879E8)
                  : const Color(0xFFD1E6F2),
            ),
          ),
          child: Text(
            '$number',
            style: TextStyle(
              color: selected
                  ? Colors.white
                  : const Color(0xFF39718F),
              fontSize: 14,
              height: 1.0,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// DETAIL LINE
// ============================================================

class _DetailLine extends StatelessWidget {
  const _DetailLine({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 7,
      ),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: const TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Color(0xFF214B69),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}