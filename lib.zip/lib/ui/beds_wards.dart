import 'package:flutter/material.dart';

// ============================================================
// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
// beds_wards.dart
// ============================================================

class BedsWardsScreen extends StatefulWidget {
  const BedsWardsScreen({super.key});

  @override
  State<BedsWardsScreen> createState() => _BedsWardsScreenState();
}

// ============================================================
// DATA MODELS
// ============================================================

class WardData {
  String wardType;
  String wardId;
  int beds;
  int occupied;

  WardData({
    required this.wardType,
    required this.wardId,
    required this.beds,
    required this.occupied,
  });

  int get free => beds - occupied;
}

class BedData {
  String wardType;
  String wardId;
  String bedId;
  String? patientId;

  BedData({
    required this.wardType,
    required this.wardId,
    required this.bedId,
    this.patientId,
  });

  bool get isOccupied =>
      patientId != null && patientId!.trim().isNotEmpty;
}

// ============================================================
// SCREEN STATE
// ============================================================

class _BedsWardsScreenState extends State<BedsWardsScreen> {
  int _selectedMenuIndex = 3;
  int _selectedTab = 0;

  // ==========================================================
  // WARD DATA
  // ==========================================================

  final List<WardData> _wards = [
    WardData(
      wardType: 'Medical',
      wardId: 'B-02',
      beds: 6,
      occupied: 5,
    ),
    WardData(
      wardType: 'Surgical',
      wardId: 'A-01',
      beds: 8,
      occupied: 3,
    ),
    WardData(
      wardType: 'General',
      wardId: 'C-01',
      beds: 7,
      occupied: 4,
    ),
    WardData(
      wardType: 'Isolation',
      wardId: 'D-01',
      beds: 4,
      occupied: 2,
    ),
  ];

  // ==========================================================
  // BED DATA
  // ==========================================================

  final List<BedData> _beds = [
    BedData(
      wardType: 'Medical',
      wardId: 'B-02',
      bedId: 'B02-01',
      patientId: 'Patient 001',
    ),
    BedData(
      wardType: 'Medical',
      wardId: 'B-02',
      bedId: 'B02-02',
      patientId: 'Patient 002',
    ),
    BedData(
      wardType: 'Medical',
      wardId: 'B-02',
      bedId: 'B02-03',
      patientId: 'Patient 003',
    ),
    BedData(
      wardType: 'Medical',
      wardId: 'B-02',
      bedId: 'B02-04',
      patientId: 'Patient 004',
    ),
    BedData(
      wardType: 'Medical',
      wardId: 'B-02',
      bedId: 'B02-05',
      patientId: 'Patient 005',
    ),
    BedData(
      wardType: 'Medical',
      wardId: 'B-02',
      bedId: 'B02-06',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-01',
      patientId: 'Patient 006',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-02',
      patientId: 'Patient 007',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-03',
      patientId: 'Patient 008',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-04',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-05',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-06',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-07',
    ),
    BedData(
      wardType: 'Surgical',
      wardId: 'A-01',
      bedId: 'A01-08',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-01',
      patientId: 'Patient 009',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-02',
      patientId: 'Patient 010',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-03',
      patientId: 'Patient 011',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-04',
      patientId: 'Patient 012',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-05',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-06',
    ),
    BedData(
      wardType: 'General',
      wardId: 'C-01',
      bedId: 'C01-07',
    ),
    BedData(
      wardType: 'Isolation',
      wardId: 'D-01',
      bedId: 'D01-01',
      patientId: 'Patient 013',
    ),
    BedData(
      wardType: 'Isolation',
      wardId: 'D-01',
      bedId: 'D01-02',
      patientId: 'Patient 014',
    ),
    BedData(
      wardType: 'Isolation',
      wardId: 'D-01',
      bedId: 'D01-03',
    ),
    BedData(
      wardType: 'Isolation',
      wardId: 'D-01',
      bedId: 'D01-04',
    ),
  ];

  // ==========================================================
  // PATIENT IDs
  // ==========================================================

  final List<String> _patients = [
    'Patient 001',
    'Patient 002',
    'Patient 003',
    'Patient 004',
    'Patient 005',
    'Patient 006',
    'Patient 007',
    'Patient 008',
    'Patient 009',
    'Patient 010',
    'Patient 011',
    'Patient 012',
    'Patient 013',
    'Patient 014',
  ];

  // ==========================================================
  // ADD BED FORM
  // ==========================================================

  String? _addBedWardType;
  String? _addBedWardId;
  String? _addWardSelectedType = 'None';

  final TextEditingController _addBedIdController =
      TextEditingController();
  final TextEditingController _addWardTypeController =
      TextEditingController();
  final TextEditingController _addWardIdController =
      TextEditingController();

  // ==========================================================
  // DISCHARGE FORM
  // ==========================================================

  String? _dischargeWardType;
  String? _dischargeWardId;
  String? _dischargeBedId;
  String? _selectedDischargePatientId;

  // ==========================================================
  // SIDEBAR
  // ==========================================================

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
      route: '/dashboard',
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_outlined,
      route: '/alerts',
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline,
      route: '/patients',
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.local_hotel_outlined,
      route: '/beds-wards',
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_outlined,
      route: '/devices',
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
      route: '/receiver',
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_outlined,
      route: '/reports',
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.receipt_long_outlined,
      route: '/logs',
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
      route: '/settings',
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
      route: '/administration',
    ),
  ];

  // ==========================================================
  // SIDEBAR NAVIGATION
  // ==========================================================

  void _handleMenuTap(int index) {
    setState(() {
      _selectedMenuIndex = index;
    });

    final item = _menuItems[index];

    if (item.route != null) {
      Navigator.pushNamed(context, item.route!);
    }
  }

  void _logout() {
    Navigator.pushNamed(context, '/logout');
  }

  // ==========================================================
  // HELPERS
  // ==========================================================

  List<String> get _wardTypes {
    return _wards.map((ward) => ward.wardType).toList();
  }

  List<String> _wardIdsForType(String? wardType) {
    if (wardType == null) {
      return [];
    }

    return _wards
        .where((ward) => ward.wardType == wardType)
        .map((ward) => ward.wardId)
        .toList();
  }

  List<BedData> _bedsForWard(
    String? wardType,
    String? wardId,
  ) {
    if (wardType == null || wardId == null) {
      return [];
    }

    return _beds
        .where(
          (bed) =>
              bed.wardType == wardType &&
              bed.wardId == wardId,
        )
        .toList();
  }

  List<String> _occupiedBedIdsForWard(
    String? wardType,
    String? wardId,
  ) {
    return _bedsForWard(
      wardType,
      wardId,
    )
        .where((bed) => bed.isOccupied)
        .map((bed) => bed.bedId)
        .toList();
  }

  List<String> _patientIdsForWard(
    String? wardType,
    String? wardId,
  ) {
    return _bedsForWard(
      wardType,
      wardId,
    )
        .where((bed) => bed.isOccupied)
        .map((bed) => bed.patientId!)
        .toList();
  }

  // ==========================================================
  // ADD BED
  // ==========================================================

  void _addBed() {
    final wardType = _addBedWardType;
    final wardId = _addBedWardId;
    final bedId =
        _addBedIdController.text.trim().toUpperCase();

    if (wardType == null ||
        wardId == null ||
        bedId.isEmpty) {
      _showMessage(
        'Please select ward type, ward ID and enter bed ID.',
      );
      return;
    }

    final alreadyExists = _beds.any(
      (bed) =>
          bed.wardType == wardType &&
          bed.wardId == wardId &&
          bed.bedId.toUpperCase() == bedId,
    );

    if (alreadyExists) {
      _showMessage(
        'This bed already exists in the selected ward.',
      );
      return;
    }

    setState(() {
      _beds.add(
        BedData(
          wardType: wardType,
          wardId: wardId,
          bedId: bedId,
        ),
      );

      final wardIndex = _wards.indexWhere(
        (ward) =>
            ward.wardType == wardType &&
            ward.wardId == wardId,
      );

      if (wardIndex != -1) {
        _wards[wardIndex].beds++;
      }

      _addBedWardType = null;
      _addBedWardId = null;
      _addBedIdController.clear();
    });

    _showMessage(
      'Bed added successfully.',
    );
  }

  void _addWard() {
    final selectedType = _addWardSelectedType;
    final wardType = selectedType == 'None'
        ? _addWardTypeController.text.trim()
        : (selectedType ?? '');
    final wardId = _addWardIdController.text.trim().toUpperCase();

    if (wardType.isEmpty || wardId.isEmpty) {
      _showMessage('Enter a ward type and ward ID.');
      return;
    }
    if (_wards.any((ward) => ward.wardId.toUpperCase() == wardId)) {
      _showMessage('This ward ID already exists.');
      return;
    }

    setState(() {
      _wards.add(WardData(
        wardType: wardType,
        wardId: wardId,
        beds: 0,
        occupied: 0,
      ));
      _addWardSelectedType = 'None';
      _addWardTypeController.clear();
      _addWardIdController.clear();
    });
    _showMessage('Ward added successfully.');
  }

  void _deleteWard() {
    final wardId = _addWardIdController.text.trim().toUpperCase();
    final wardIndex = _wards.indexWhere((ward) => ward.wardId == wardId);
    if (wardIndex == -1) {
      _showMessage('Enter the Ward ID you want to delete.');
      return;
    }
    if (_beds.any((bed) => bed.wardId == wardId)) {
      _showMessage('Delete this ward\'s beds before deleting the ward.');
      return;
    }

    setState(() {
      _wards.removeAt(wardIndex);
      _addWardSelectedType = 'None';
      _addWardTypeController.clear();
      _addWardIdController.clear();
    });
    _showMessage('Ward $wardId deleted.');
  }

  void _deleteBed() {
    final wardType = _addBedWardType;
    final wardId = _addBedWardId;
    final bedId = _addBedIdController.text.trim().toUpperCase();
    final bedIndex = _beds.indexWhere((bed) =>
        bed.wardType == wardType && bed.wardId == wardId && bed.bedId == bedId);

    if (bedIndex == -1) {
      _showMessage('Select ward type and ward ID, then enter the Bed ID to delete.');
      return;
    }
    if (_beds[bedIndex].isOccupied) {
      _showMessage('Discharge the patient before deleting this bed.');
      return;
    }

    setState(() {
      _beds.removeAt(bedIndex);
      final wardIndex = _wards.indexWhere((ward) => ward.wardId == wardId);
      if (wardIndex != -1 && _wards[wardIndex].beds > 0) {
        _wards[wardIndex].beds--;
      }
      _addBedWardType = null;
      _addBedWardId = null;
      _addBedIdController.clear();
    });
    _showMessage('Bed $bedId deleted.');
  }

  // ==========================================================
  // DISCHARGE PATIENT
  // ==========================================================

  void _dischargeSelectedPatient() {
    if (_dischargeWardType == null ||
        _dischargeWardId == null ||
        _dischargeBedId == null ||
        _selectedDischargePatientId == null) {
      _showMessage(
        'Please select ward type, ward ID, bed ID and patient ID.',
      );
      return;
    }

    BedData? bed;

    for (final item in _beds) {
      if (item.wardType == _dischargeWardType &&
          item.wardId == _dischargeWardId &&
          item.bedId == _dischargeBedId) {
        bed = item;
        break;
      }
    }

    if (bed == null) {
      _showMessage(
        'The selected bed could not be found.',
      );
      return;
    }

    if (!bed.isOccupied) {
      _showMessage(
        'The selected bed is already free.',
      );
      return;
    }

    if (bed.patientId !=
        _selectedDischargePatientId) {
      _showMessage(
        'The selected patient ID does not belong to this bed.',
      );
      return;
    }

    final dischargedPatientId = bed.patientId;

    setState(() {
      bed!.patientId = null;

      final wardIndex = _wards.indexWhere(
        (item) =>
            item.wardType == _dischargeWardType &&
            item.wardId == _dischargeWardId,
      );

      if (wardIndex != -1 &&
          _wards[wardIndex].occupied > 0) {
        _wards[wardIndex].occupied--;
      }

      if (dischargedPatientId != null &&
          !_patients.contains(dischargedPatientId)) {
        _patients.add(dischargedPatientId);
        _patients.sort();
      }

      _dischargeBedId = null;
      _selectedDischargePatientId = null;
    });

    _showMessage(
      'Patient discharged successfully. The bed is now free.',
    );
  }

  // ==========================================================
  // SHOW MESSAGE
  // ==========================================================

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  void dispose() {
    _addBedIdController.dispose();
    _addWardTypeController.dispose();
    _addWardIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            _buildSidebar(),
            Expanded(
              child: _buildMainContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ==========================================================
  // SIDEBAR
  // ==========================================================

  Widget _buildSidebar() {
    return Container(
      width: 170,
      color: const Color(0xFF062E58),
      child: Column(
        children: [
          const SizedBox(height: 9),

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: _menuItems.length,
              itemBuilder: (context, index) {
                final item = _menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected:
                        _selectedMenuIndex == index,
                    onTap: () =>
                        _handleMenuTap(index),
                  ),
                );
              },
            ),
          ),

          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(
              horizontal: 10,
            ),
            color: const Color(0xFF1B4770),
          ),

          const SizedBox(height: 5),

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_outlined,
              selected: false,
              onTap: _logout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }

  // ==========================================================
  // MAIN CONTENT
  // ==========================================================

  Widget _buildMainContent() {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Stack(
          fit: StackFit.expand,
          children: [
            // ==================================================
            // HOSPITAL BACKGROUND
            // ==================================================

            Image.asset(
              'assets/images/hospital.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              errorBuilder:
                  (context, error, stackTrace) {
                return Container(
                  color: const Color(0xFFEAF3F9),
                  child: const Center(
                    child: Text(
                      'Hospital background image not found',
                      style: TextStyle(
                        color: Color(0xFF31556D),
                        fontSize: 14,
                      ),
                    ),
                  ),
                );
              },
            ),

            // ==================================================
            // LIGHT OVERLAY
            // ==================================================

            Container(
              color: const Color(0x18002545),
            ),

            // ==================================================
            // MAIN CONTENT
            // ==================================================

            SingleChildScrollView(
              padding: const EdgeInsets.all(10),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight:
                      constraints.maxHeight - 20,
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    _buildTabs(),

                    const SizedBox(height: 10),

                    if (_selectedTab == 0)
                      _buildWardsTab(),

                    if (_selectedTab == 1)
                      _buildBedsTab(),

                    if (_selectedTab == 2)
                      _buildDischargeTab(),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ==========================================================
  // TABS
  // ==========================================================

  Widget _buildTabs() {
    return Row(
      children: [
        _buildTabButton(
          title: 'Wards',
          index: 0,
        ),
        const SizedBox(width: 5),
        _buildTabButton(
          title: 'Beds',
          index: 1,
        ),
        const SizedBox(width: 5),
        _buildTabButton(
          title: 'Discharge',
          index: 2,
        ),
      ],
    );
  }

  Widget _buildTabButton({
    required String title,
    required int index,
  }) {
    final selected = _selectedTab == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedTab = index;
        });
      },
      child: AnimatedContainer(
        duration:
            const Duration(milliseconds: 150),
        width:
            title == 'Discharge' ? 100 : 80,
        height: 34,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF0879E8)
              : const Color(0xFFE6F3FC),
          borderRadius:
              BorderRadius.circular(5),
        ),
        child: Text(
          title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: selected
                ? Colors.white
                : const Color(0xFF1976B9),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // WARDS TAB
  // ==========================================================

  Widget _buildWardsTab() {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 230,
          child: _buildAddWardCard(),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildCurrentWardsCard(),
        ),
      ],
    );
  }

  // ==========================================================
  // ADD WARD
  // ==========================================================

  Widget _buildAddWardCard() {
    return _Panel(
      title: 'Add Ward',
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          _fieldLabel('Ward Type *'),

          _buildDropdown(
            value: _addWardSelectedType,
            hint: 'Select Ward Type',
            items: const [
              'None',
              'Medical',
              'Surgical',
              'General',
              'Isolation',
            ],
            onChanged: (value) {
              setState(() {
                _addWardSelectedType = value;
                if (value != 'None') {
                  _addWardTypeController.clear();
                }
              });
            },
          ),

          const SizedBox(height: 12),

          _fieldLabel('Enter Ward Type'),

          _buildTextField(
            hint: 'Enter Ward Type',
            controller: _addWardTypeController,
            enabled: _addWardSelectedType == 'None',
          ),

          const SizedBox(height: 12),

          _fieldLabel('Ward ID *'),

          _buildTextField(
            hint: 'Enter Ward ID',
            controller: _addWardIdController,
            textCapitalization: TextCapitalization.characters,
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: double.infinity,
            height: 38,
            child: ElevatedButton(
              onPressed: _addWard,
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF0879E8),
                foregroundColor:
                    Colors.white,
                elevation: 0,
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(5),
                ),
              ),
              child: const Text(
                'Add Ward',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),
            ),
          ),

          const SizedBox(height: 8),

          SizedBox(
            width: double.infinity,
            height: 38,
            child: OutlinedButton(
              onPressed: _deleteWard,
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFD64545),
                side: const BorderSide(color: Color(0xFFD64545)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              child: const Text('Delete Ward', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // CURRENT WARDS
  // ==========================================================

  Widget _buildCurrentWardsCard() {
    return _Panel(
      title: 'Current Wards',
      child: Column(
        children: [
          _buildWardTableHeader(),

          const SizedBox(height: 4),

          ..._wards.map(
            (ward) =>
                _buildWardTableRow(ward),
          ),
        ],
      ),
    );
  }

  Widget _buildWardTableHeader() {
    return Container(
      height: 36,
      decoration: BoxDecoration(
        color: const Color(0xFFEAF6FD),
        borderRadius:
            BorderRadius.circular(4),
      ),
      child: const Row(
        children: [
          Expanded(
            flex: 3,
            child: _TableHeader(
              'Ward Type',
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableHeader(
              'Ward ID',
            ),
          ),
          Expanded(
            flex: 1,
            child: _TableHeader(
              'Beds',
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableHeader(
              'Occupied',
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableHeader(
              'Free',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWardTableRow(
    WardData ward,
  ) {
    return Container(
      height: 42,
      decoration:
          const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5F0F7),
            width: 0.7,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child:
                _TableCell(ward.wardType),
          ),
          Expanded(
            flex: 2,
            child:
                _TableCell(ward.wardId),
          ),
          Expanded(
            flex: 1,
            child: _TableCell(
              ward.beds.toString(),
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableCell(
              ward.occupied.toString(),
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableCell(
              ward.free.toString(),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // BEDS TAB
  // ==========================================================

  Widget _buildBedsTab() {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 230,
          child: _buildAddBedCard(),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildCurrentBedsCard(),
        ),
      ],
    );
  }

  // ==========================================================
  // ADD BED CARD
  // ==========================================================

  Widget _buildAddBedCard() {
    return _Panel(
      title: 'Add Bed',
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          _fieldLabel('Ward Type *'),

          _buildDropdown(
            value: _addBedWardType,
            hint: 'Select Ward Type',
            items: _wardTypes,
            onChanged: (value) {
              setState(() {
                _addBedWardType = value;
                _addBedWardId = null;
              });
            },
          ),

          const SizedBox(height: 12),

          _fieldLabel('Ward ID *'),

          _buildDropdown(
            value: _addBedWardId,
            hint: 'Select Ward ID',
            items:
                _wardIdsForType(
              _addBedWardType,
            ),
            onChanged: (value) {
              setState(() {
                _addBedWardId = value;
              });
            },
          ),

          const SizedBox(height: 12),

          _fieldLabel('Bed ID *'),

          _buildTextField(
            hint: 'Enter Bed ID',
            controller:
                _addBedIdController,
            textCapitalization:
                TextCapitalization.characters,
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: double.infinity,
            height: 38,
            child: ElevatedButton.icon(
              onPressed: _addBed,
              icon: const Icon(
                Icons.add,
                size: 18,
              ),
              label: const Text(
                'Add Bed',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF0879E8),
                foregroundColor:
                    Colors.white,
                elevation: 0,
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(5),
                ),
              ),
            ),
          ),

          const SizedBox(height: 8),

          SizedBox(
            width: double.infinity,
            height: 38,
            child: OutlinedButton(
              onPressed: _deleteBed,
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFD64545),
                side: const BorderSide(color: Color(0xFFD64545)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              child: const Text('Delete Bed', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // CURRENT BEDS CARD
  // ==========================================================

  Widget _buildCurrentBedsCard() {
    return _Panel(
      title: 'Current Beds',
      child: Column(
        children: [
          _buildBedTable(),

          const SizedBox(height: 1),
        ],
      ),
    );
  }

  // ==========================================================
  // BED TABLE
  // ==========================================================

  Widget _buildBedTable() {
    return Column(
      children: [
        Container(
          height: 38,
          decoration: BoxDecoration(
            color:
                const Color(0xFFEAF6FD),
            borderRadius:
                BorderRadius.circular(4),
          ),
          child: const Row(
            children: [
              Expanded(
                flex: 2,
                child: _TableHeader(
                  'Ward Type',
                ),
              ),
              Expanded(
                flex: 2,
                child: _TableHeader(
                  'Ward ID',
                ),
              ),
              Expanded(
                flex: 2,
                child: _TableHeader(
                  'Bed ID',
                ),
              ),
              Expanded(
                flex: 3,
                child: _TableHeader(
                  'Patient ID',
                ),
              ),
              Expanded(
                flex: 2,
                child: _TableHeader(
                  'Status',
                ),
              ),
            ],
          ),
        ),

        ..._beds.map(
          (bed) => _buildBedRow(bed),
        ),
      ],
    );
  }

  Widget _buildBedRow(
    BedData bed,
  ) {
    return Container(
      height: 42,
      decoration:
          const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5F0F7),
            width: 0.7,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: _TableCell(
              bed.wardType,
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableCell(
              bed.wardId,
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableCell(
              bed.bedId,
            ),
          ),
          Expanded(
            flex: 3,
            child: _TableCell(
              bed.patientId ?? '-',
            ),
          ),
          Expanded(
            flex: 2,
            child: Center(
              child: Container(
                width: 70,
                height: 25,
                alignment:
                    Alignment.center,
                decoration:
                    BoxDecoration(
                  color: bed.isOccupied
                      ? const Color(
                          0xFFFFE8E8,
                        )
                      : const Color(
                          0xFFE5F8EC,
                        ),
                  borderRadius:
                      BorderRadius.circular(
                    4,
                  ),
                ),
                child: Text(
                  bed.isOccupied
                      ? 'Occupied'
                      : 'Free',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight:
                        FontWeight.w600,
                    color: bed.isOccupied
                        ? const Color(
                            0xFFD64545,
                          )
                        : const Color(
                            0xFF21884D,
                          ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // DISCHARGE TAB
  // ==========================================================

  Widget _buildDischargeTab() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _Panel(
          title: 'Discharge Patient',
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment:
                    CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: _dischargeField(
                      'Ward Type *',
                      _buildDropdown(
                        value:
                            _dischargeWardType,
                        hint:
                            'Select Ward Type',
                        items: _wardTypes,
                        onChanged:
                            (value) {
                          setState(() {
                            _dischargeWardType =
                                value;
                            _dischargeWardId =
                                null;
                            _dischargeBedId =
                                null;
                            _selectedDischargePatientId =
                                null;
                          });
                        },
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child: _dischargeField(
                      'Ward ID *',
                      _buildDropdown(
                        value:
                            _dischargeWardId,
                        hint:
                            'Select Ward ID',
                        items:
                            _wardIdsForType(
                          _dischargeWardType,
                        ),
                        onChanged:
                            (value) {
                          setState(() {
                            _dischargeWardId =
                                value;
                            _dischargeBedId =
                                null;
                            _selectedDischargePatientId =
                                null;
                          });
                        },
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child: _dischargeField(
                      'Bed ID *',
                      _buildDropdown(
                        value:
                            _dischargeBedId,
                        hint:
                            'Select Bed',
                        items:
                            _occupiedBedIdsForWard(
                          _dischargeWardType,
                          _dischargeWardId,
                        ),
                        onChanged:
                            (value) {
                          setState(() {
                            _dischargeBedId =
                                value;

                            if (value !=
                                null) {
                              BedData?
                                  matchingBed;

                              for (final bed
                                  in _beds) {
                                if (bed
                                            .wardType ==
                                        _dischargeWardType &&
                                    bed.wardId ==
                                        _dischargeWardId &&
                                    bed.bedId ==
                                        value) {
                                  matchingBed =
                                      bed;
                                  break;
                                }
                              }

                              _selectedDischargePatientId =
                                  matchingBed
                                      ?.patientId;
                            } else {
                              _selectedDischargePatientId =
                                  null;
                            }
                          });
                        },
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child: _dischargeField(
                      'Patient ID *',
                      _buildDropdown(
                        value:
                            _selectedDischargePatientId,
                        hint:
                            'Select Patient ID',
                        items:
                            _patientIdsForWard(
                          _dischargeWardType,
                          _dischargeWardId,
                        ),
                        onChanged:
                            (value) {
                          setState(() {
                            _selectedDischargePatientId =
                                value;

                            if (value !=
                                null) {
                              final matchingBeds =
                                  _bedsForWard(
                                _dischargeWardType,
                                _dischargeWardId,
                              ).where(
                                (bed) =>
                                    bed.patientId ==
                                    value,
                              );

                              if (matchingBeds
                                  .isNotEmpty) {
                                _dischargeBedId =
                                    matchingBeds
                                        .first
                                        .bedId;
                              }
                            }
                          });
                        },
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  SizedBox(
                    width: 120,
                    height: 38,
                    child:
                        ElevatedButton(
                      onPressed:
                          _dischargeSelectedPatient,
                      style:
                          ElevatedButton
                              .styleFrom(
                        backgroundColor:
                            const Color(
                          0xFF0879E8,
                        ),
                        foregroundColor:
                            Colors.white,
                        elevation: 0,
                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius
                                  .circular(
                            5,
                          ),
                        ),
                      ),
                      child:
                          const Text(
                        'Discharge',
                        style:
                            TextStyle(
                          fontSize: 14,
                          fontWeight:
                              FontWeight
                                  .w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),

        const SizedBox(height: 10),

        _buildOccupiedPatientsTable(),
      ],
    );
  }

  // ==========================================================
  // DISCHARGE FIELD
  // ==========================================================

  Widget _dischargeField(
    String label,
    Widget child,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _fieldLabel(label),
        child,
      ],
    );
  }

  // ==========================================================
  // OCCUPIED PATIENTS TABLE
  // ==========================================================

  Widget _buildOccupiedPatientsTable() {
    final occupiedBeds = _beds
        .where((bed) => bed.isOccupied)
        .toList();

    return _Panel(
      title: 'Current Patients',
      child: Column(
        children: [
          Container(
            height: 38,
            decoration: BoxDecoration(
              color:
                  const Color(0xFFEAF6FD),
              borderRadius:
                  BorderRadius.circular(4),
            ),
            child: const Row(
              children: [
                Expanded(
                  flex: 2,
                  child: _TableHeader(
                    'Ward Type',
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _TableHeader(
                    'Ward ID',
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _TableHeader(
                    'Bed ID',
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: _TableHeader(
                    'Patient ID',
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _TableHeader(
                    'Status',
                  ),
                ),
              ],
            ),
          ),

          ...occupiedBeds.map(
            (bed) =>
                _buildOccupiedPatientRow(
              bed,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOccupiedPatientRow(
    BedData bed,
  ) {
    return Container(
      height: 42,
      decoration:
          const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5F0F7),
            width: 0.7,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: _TableCell(
              bed.wardType,
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableCell(
              bed.wardId,
            ),
          ),
          Expanded(
            flex: 2,
            child: _TableCell(
              bed.bedId,
            ),
          ),
          Expanded(
            flex: 3,
            child: _TableCell(
              bed.patientId ?? '-',
            ),
          ),
          Expanded(
            flex: 2,
            child: Center(
              child: Container(
                width: 85,
                height: 25,
                alignment:
                    Alignment.center,
                decoration:
                    BoxDecoration(
                  color:
                      const Color(
                    0xFFFFE8E8,
                  ),
                  borderRadius:
                      BorderRadius.circular(
                    4,
                  ),
                ),
                child: const Text(
                  'Occupied',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight:
                        FontWeight.w600,
                    color: Color(
                      0xFFD64545,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // FIELD LABEL
  // ==========================================================

  Widget _fieldLabel(String text) {
    return Padding(
      padding:
          const EdgeInsets.only(
        bottom: 5,
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          color: Color(0xFF37749A),
          fontWeight:
              FontWeight.w600,
        ),
      ),
    );
  }

  // ==========================================================
  // TEXT FIELD
  // ==========================================================

  Widget _buildTextField({
    required String hint,
    TextEditingController?
        controller,
    bool enabled = true,
    TextCapitalization
        textCapitalization =
        TextCapitalization.none,
  }) {
    return SizedBox(
      height: 38,
      child: TextField(
        controller: controller,
        enabled: enabled,
        textCapitalization:
            textCapitalization,
        style: const TextStyle(
          fontSize: 14,
          color: Color(0xFF355F78),
        ),
        decoration:
            InputDecoration(
          hintText: hint,
          hintStyle:
              const TextStyle(
            fontSize: 14,
            color: Color(0xFF8BAFC3),
          ),
          filled: true,
          fillColor:
              const Color(0xFFF8FCFE),
          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 8,
          ),
          enabledBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide:
                const BorderSide(
              color:
                  Color(0xFFD5E9F4),
              width: 0.8,
            ),
          ),
          focusedBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide:
                const BorderSide(
              color:
                  Color(0xFF0879E8),
              width: 0.8,
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // DROPDOWN
  // ==========================================================

  Widget _buildDropdown({
    required String? value,
    required String hint,
    required List<String> items,
    required ValueChanged<String?>
        onChanged,
  }) {
    final validValue =
        items.contains(value)
            ? value
            : null;

    return SizedBox(
      height: 38,
      child:
          DropdownButtonFormField<String>(
        value: validValue,
        isExpanded: true,
        icon: const Icon(
          Icons.keyboard_arrow_down,
          size: 18,
          color: Color(0xFF4B8BB0),
        ),
        style: const TextStyle(
          fontSize: 14,
          color: Color(0xFF355F78),
        ),
        decoration:
            InputDecoration(
          hintText: hint,
          hintStyle:
              const TextStyle(
            fontSize: 14,
            color: Color(0xFF8BAFC3),
          ),
          filled: true,
          fillColor:
              const Color(0xFFF8FCFE),
          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 0,
          ),
          enabledBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide:
                const BorderSide(
              color:
                  Color(0xFFD5E9F4),
              width: 0.8,
            ),
          ),
          focusedBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide:
                const BorderSide(
              color:
                  Color(0xFF0879E8),
              width: 0.8,
            ),
          ),
        ),
        items: items
            .map(
              (item) =>
                  DropdownMenuItem<String>(
                value: item,
                child: Text(
                  item,
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style:
                      const TextStyle(
                    fontSize: 14,
                  ),
                ),
              ),
            )
            .toList(),
        onChanged: onChanged,
      ),
    );
  }
}

// ============================================================
// PANEL
// ============================================================

class _Panel extends StatelessWidget {
  final String title;
  final Widget child;

  const _Panel({
    required this.title,
    required this.child,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.fromLTRB(
        10,
        9,
        10,
        10,
      ),
      decoration:
          BoxDecoration(
        // ====================================================
        // SOLID CARD BACKGROUND
        // ====================================================
        // The hospital image stays behind the cards, while
        // the cards themselves remain solid as before.
        color: const Color(0xFFF3FAFE),
        borderRadius:
            BorderRadius.circular(7),
        border: Border.all(
          color:
              const Color(0xFFDCEFF8),
          width: 0.8,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style:
                const TextStyle(
              fontSize: 14,
              fontWeight:
                  FontWeight.w700,
              color:
                  Color(0xFF174F73),
            ),
          ),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

// ============================================================
// TABLE HEADER
// ============================================================

class _TableHeader
    extends StatelessWidget {
  final String text;

  const _TableHeader(this.text);

  @override
  Widget build(
    BuildContext context,
  ) {
    return Align(
      alignment:
          Alignment.centerLeft,
      child: Padding(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 7,
        ),
        child: Text(
          text,
          maxLines: 1,
          overflow:
              TextOverflow.ellipsis,
          style:
              const TextStyle(
            fontSize: 14,
            fontWeight:
                FontWeight.w700,
            color:
                Color(0xFF356D8E),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// TABLE CELL
// ============================================================

class _TableCell
    extends StatelessWidget {
  final String text;

  const _TableCell(this.text);

  @override
  Widget build(
    BuildContext context,
  ) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 7,
      ),
      child: Align(
        alignment:
            Alignment.centerLeft,
        child: Text(
          text,
          maxLines: 1,
          softWrap: false,
          overflow:
              TextOverflow.ellipsis,
          style:
              const TextStyle(
            fontSize: 14,
            color:
                Color(0xFF355F78),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton
    extends StatefulWidget {
  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  State<_SidebarButton>
      createState() =>
          _SidebarButtonState();
}

class _SidebarButtonState
    extends State<_SidebarButton> {
  bool _hovered = false;

  @override
  Widget build(
    BuildContext context,
  ) {
    Color background;

    if (widget.selected) {
      background =
          const Color(0xFF0879E8);
    } else if (_hovered) {
      background =
          const Color(0xFF0A416E);
    } else {
      background =
          Colors.transparent;
    }

    return MouseRegion(
      onEnter: (_) {
        setState(() {
          _hovered = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovered = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration:
              const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,
          constraints:
              const BoxConstraints(
            minHeight: 42,
          ),
          padding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),
          decoration:
              BoxDecoration(
            color: background,
            borderRadius:
                BorderRadius.circular(5),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),

              const SizedBox(width: 9),

              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow:
                      TextOverflow.visible,
                  textAlign:
                      TextAlign.left,
                  style:
                      const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  final String title;
  final IconData icon;
  final String? route;

  const _MenuItem({
    required this.title,
    required this.icon,
    required this.route,
  });
}
