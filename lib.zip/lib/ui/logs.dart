import 'package:flutter/material.dart';
import 'dashboard.dart';

// ============================================================
// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
// logs.dart
//
// LOGS SCREEN
//
// FEATURES:
// 1. System Logs
// 2. Alert Logs
// 3. Device Logs
// 4. Sidebar navigation
// 5. Home -> Dashboard
// 6. Responsive log table
// 7. Pure white log cards/tables
// ============================================================

class LogsScreen extends StatefulWidget {
  const LogsScreen({super.key});

  @override
  State<LogsScreen> createState() => _LogsScreenState();
}

class _LogsScreenState extends State<LogsScreen> {
  // Logs is the 8th item in the sidebar.
  int _selectedIndex = 7;

  // ============================================================
  // SIDEBAR MENU
  // ============================================================

  final List<Map<String, dynamic>> _menuItems = [
    {
      'title': 'Home',
      'icon': Icons.home_outlined,
    },
    {
      'title': 'Alerts',
      'icon': Icons.notifications_none_outlined,
    },
    {
      'title': 'Patients',
      'icon': Icons.person_outline,
    },
    {
      'title': 'Bed/Wards',
      'icon': Icons.bed_outlined,
    },
    {
      'title': 'Devices',
      'icon': Icons.devices_outlined,
    },
    {
      'title': 'Receiver',
      'icon': Icons.monitor_heart_outlined,
    },
    {
      'title': 'Reports',
      'icon': Icons.bar_chart_outlined,
    },
    {
      'title': 'Logs',
      'icon': Icons.history_outlined,
    },
    {
      'title': 'Settings',
      'icon': Icons.settings_outlined,
    },
    {
      'title': 'Administration',
      'icon': Icons.admin_panel_settings_outlined,
    },
  ];

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _handleMenuTap(int index) {
    final String title = _menuItems[index]['title'];

    setState(() {
      _selectedIndex = index;
    });

    switch (title) {
      case 'Home':
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const DashboardScreen(),
          ),
        );
        break;

      case 'Alerts':
        Navigator.pushNamed(context, '/alerts');
        break;

      case 'Patients':
        Navigator.pushNamed(context, '/patients');
        break;

      case 'Bed/Wards':
        Navigator.pushNamed(context, '/beds-wards');
        break;

      case 'Devices':
        Navigator.pushNamed(context, '/devices');
        break;

      case 'Receiver':
        Navigator.pushNamed(context, '/receiver');
        break;

      case 'Reports':
        Navigator.pushNamed(context, '/reports');
        break;

      case 'Logs':
        // Already on Logs.
        break;

      case 'Settings':
        Navigator.pushNamed(context, '/settings');
        break;

      case 'Administration':
        Navigator.pushNamed(context, '/administration');
        break;
    }
  }

  // ============================================================
  // LOG DATA
  // ============================================================

  final List<Map<String, String>> _systemLogs = [
    {
      'time': '14:32',
      'event': 'Device D-014',
      'details': 'Connected',
    },
    {
      'time': '14:31',
      'event': 'Alert triggered',
      'details': 'Ward 03 - Emergency',
    },
    {
      'time': '14:28',
      'event': 'Device D-006',
      'details': 'Connected',
    },
    {
      'time': '14:20',
      'event': 'Patient updated',
      'details': 'P-001 - Bed 12',
    },
    {
      'time': '14:12',
      'event': 'Device D-009',
      'details': 'Disconnected',
    },
  ];

  final List<Map<String, String>> _alertLogs = [
    {
      'time': '14:31',
      'event': 'Alert triggered',
      'details': 'Ward 03 - Emergency',
    },
    {
      'time': '14:25',
      'event': 'Alert acknowledged',
      'details': 'Ward 02 - Nurse Station',
    },
    {
      'time': '14:18',
      'event': 'Alert cleared',
      'details': 'Ward 01 - Bed 08',
    },
    {
      'time': '14:05',
      'event': 'Alert triggered',
      'details': 'Ward 04 - Emergency',
    },
  ];

  final List<Map<String, String>> _deviceLogs = [
    {
      'time': '14:32',
      'event': 'Device D-014',
      'details': 'Connected',
    },
    {
      'time': '14:28',
      'event': 'Device D-006',
      'details': 'Connected',
    },
    {
      'time': '14:12',
      'event': 'Device D-009',
      'details': 'Disconnected',
    },
    {
      'time': '14:02',
      'event': 'Device D-015',
      'details': 'Data received',
    },
  ];

  // ============================================================
  // LOG TABLE
  // ============================================================

  Widget _buildLogTable(
    List<Map<String, String>> logs,
  ) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFDCECF7),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Column(
          children: [
            // --------------------------------------------------
            // TABLE HEADER
            // --------------------------------------------------

            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 11,
              ),
              decoration: const BoxDecoration(
                color: Color(0xFFEAF6FD),
              ),
              child: const Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Time',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF07549A),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Event',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF07549A),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: Text(
                      'Details',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF07549A),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // --------------------------------------------------
            // TABLE ROWS
            // --------------------------------------------------

            Expanded(
              child: logs.isEmpty
                  ? _buildEmptyLogs()
                  : ListView.builder(
                      padding: EdgeInsets.zero,
                      itemCount: logs.length,
                      itemBuilder: (context, index) {
                        final Map<String, String> log =
                            logs[index];

                        return Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 11,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: index < logs.length - 1
                                ? const Border(
                                    bottom: BorderSide(
                                      color: Color(0xFFE5F0F7),
                                      width: 1,
                                    ),
                                  )
                                : null,
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: Text(
                                  log['time'] ?? '',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Color(0xFF1769AA),
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: Text(
                                  log['event'] ?? '',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Color(0xFF1769AA),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 3,
                                child: Text(
                                  log['details'] ?? '',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Color(0xFF1769AA),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // EMPTY LOGS
  // ============================================================

  Widget _buildEmptyLogs() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history_outlined,
            size: 38,
            color: Color(0xFF9AAEBC),
          ),
          SizedBox(height: 8),
          Text(
            'No logs available',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Color(0xFF59788D),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LOG TABS
  // ============================================================

  Widget _buildLogTabs() {
    return DefaultTabController(
      length: 3,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ----------------------------------------------------
          // TABS
          // ----------------------------------------------------

          SizedBox(
            height: 42,
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFEAF6FD),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: const Color(0xFFDCECF7),
                ),
              ),
              child: const TabBar(
                isScrollable: false,
                indicator: BoxDecoration(
                  color: Color(0xFFCDEBFF),
                  borderRadius: BorderRadius.all(
                    Radius.circular(5),
                  ),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: Color(0xFF0879E8),
                unselectedLabelColor: Color(0xFF1769AA),
                labelStyle: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
                unselectedLabelStyle: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
                tabs: [
                  Tab(
                    text: 'System Logs',
                  ),
                  Tab(
                    text: 'Alert Logs',
                  ),
                  Tab(
                    text: 'Device Logs',
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 10),

          // ----------------------------------------------------
          // TABLE AREA
          // ----------------------------------------------------

          Expanded(
            child: TabBarView(
              children: [
                _buildLogTable(_systemLogs),
                _buildLogTable(_alertLogs),
                _buildLogTable(_deviceLogs),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SIDEBAR
  // ============================================================

  Widget _buildSidebar() {
    return Container(
      width: 170,
      color: const Color(0xFF062E58),
      child: SafeArea(
        child: Column(
          children: [
            // --------------------------------------------------
            // LOGO
            // --------------------------------------------------

            Padding(
              padding: const EdgeInsets.only(
                top: 14,
                bottom: 18,
              ),
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFF0879E8),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.monitor_heart_outlined,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),

            // --------------------------------------------------
            // MENU
            // --------------------------------------------------

            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: _menuItems.length,
                itemBuilder: (context, index) {
                  final Map<String, dynamic> item =
                      _menuItems[index];

                  final bool selected =
                      _selectedIndex == index;

                  return Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 2,
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () => _handleMenuTap(index),
                        borderRadius: BorderRadius.circular(5),
                        hoverColor: const Color(0xFF0A416E),
                        child: AnimatedContainer(
                          duration: const Duration(
                            milliseconds: 150,
                          ),
                          constraints: const BoxConstraints(
                            minHeight: 42,
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: selected
                                ? const Color(0xFF0879E8)
                                : Colors.transparent,
                            borderRadius:
                                BorderRadius.circular(5),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                item['icon'] as IconData,
                                size: 18,
                                color: Colors.white,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  item['title'] as String,
                                  maxLines: 1,
                                  overflow:
                                      TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // --------------------------------------------------
            // LOGOUT
            // --------------------------------------------------

            Padding(
              padding: const EdgeInsets.all(7),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/logout',
                    );
                  },
                  borderRadius: BorderRadius.circular(5),
                  hoverColor: const Color(0xFF0A416E),
                  child: Container(
                    constraints: const BoxConstraints(
                      minHeight: 42,
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 7,
                    ),
                    child: const Row(
                      children: [
                        Icon(
                          Icons.logout_outlined,
                          size: 18,
                          color: Colors.white,
                        ),
                        SizedBox(width: 10),
                        Text(
                          'Logout',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // MAIN CONTENT
  // ============================================================

  Widget _buildMainContent() {
    return Expanded(
      child: Container(
        color: const Color(0xFFF4FAFE),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              18,
              14,
              18,
              14,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ------------------------------------------------
                // PAGE HEADER
                // ------------------------------------------------

                SizedBox(
                  height: 32,
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'System Logs',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF07516B),
                          ),
                        ),
                      ),

                      // System status
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFDDF5EA),
                          borderRadius:
                              BorderRadius.circular(5),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.circle,
                              size: 7,
                              color: Color(0xFF10A66B),
                            ),
                            SizedBox(width: 5),
                            Text(
                              'System Online',
                              style: TextStyle(
                                color: Color(0xFF087C50),
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // ------------------------------------------------
                // TABS + LOG TABLES
                // ------------------------------------------------

                Expanded(
                  child: _buildLogTabs(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4FAFE),
      body: Row(
        children: [
          _buildSidebar(),
          _buildMainContent(),
        ],
      ),
    );
  }
}