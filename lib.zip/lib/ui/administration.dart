import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// administration.dart
///
/// ADMINISTRATION SCREEN
///
/// Features:
/// - Same sidebar structure as dashboard.dart
/// - Home -> /dashboard
/// - Users
/// - Roles & Permissions
/// - Audit Trail
/// - Add User
/// - Edit User
/// - Administrator authentication before Add/Edit
/// - Create username
/// - Create password
/// - Create recovery key
/// - Assign role
/// - Edit username
/// - Edit password
/// - Edit recovery key
/// - Delete user
/// - Create roles
/// - Edit roles
/// - Role permissions
/// - Hospital background
///
/// All visible text = 14px
/// ============================================================

class AdministrationScreen extends StatefulWidget {
  const AdministrationScreen({super.key});

  @override
  State<AdministrationScreen> createState() =>
      _AdministrationScreenState();
}

class _AdministrationScreenState
    extends State<AdministrationScreen> {
  int _selectedIndex = 9;
  int _selectedTab = 0;

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
      route: null,
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_rounded,
      route: '/alerts',
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline_rounded,
      route: '/patients',
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.bed_outlined,
      route: '/beds-wards',
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_other_outlined,
      route: '/devices',
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
      route: '/receiver',
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_rounded,
      route: '/reports',
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.description_outlined,
      route: '/logs',
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
      route: '/settings',
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
      route: '/administration',
    ),
  ];

  final List<_SystemUser> _users = [
    _SystemUser(
      username: 'admin',
      role: 'Administrator',
      status: 'Active',
      recoveryKey: 'ADMIN-001',
    ),
    _SystemUser(
      username: 'john',
      role: 'Operator',
      status: 'Active',
      recoveryKey: 'JOHN-002',
    ),
    _SystemUser(
      username: 'mary',
      role: 'Operator',
      status: 'Active',
      recoveryKey: 'MARY-003',
    ),
  ];

  final List<_SystemRole> _roles = [
    _SystemRole(
      name: 'Administrator',
      description: 'Full system access',
      permissions: {
        'Dashboard': true,
        'Alerts': true,
        'Patients': true,
        'Bed/Wards': true,
        'Devices': true,
        'Receiver': true,
        'Reports': true,
        'Logs': true,
        'Settings': true,
        'Administration': true,
        'Manage Users': true,
        'Manage Roles': true,
      },
    ),
    _SystemRole(
      name: 'Operator',
      description: 'Daily hospital operations',
      permissions: {
        'Dashboard': true,
        'Alerts': true,
        'Patients': true,
        'Bed/Wards': true,
        'Devices': true,
        'Receiver': true,
        'Reports': true,
        'Logs': true,
        'Settings': false,
        'Administration': false,
        'Manage Users': false,
        'Manage Roles': false,
      },
    ),
    _SystemRole(
      name: 'Nurse',
      description: 'Patient and emergency assistance',
      permissions: {
        'Dashboard': true,
        'Alerts': true,
        'Patients': true,
        'Bed/Wards': true,
        'Devices': false,
        'Receiver': true,
        'Reports': true,
        'Logs': false,
        'Settings': false,
        'Administration': false,
        'Manage Users': false,
        'Manage Roles': false,
      },
    ),
  ];

  final List<_AuditRecord> _auditRecords = [
    _AuditRecord(
      time: '14:35',
      user: 'admin',
      action: 'User updated',
      details: 'john',
    ),
    _AuditRecord(
      time: '14:20',
      user: 'admin',
      action: 'User created',
      details: 'mary',
    ),
    _AuditRecord(
      time: '13:54',
      user: 'admin',
      action: 'Role updated',
      details: 'Operator',
    ),
    _AuditRecord(
      time: '13:20',
      user: 'admin',
      action: 'Login',
      details: 'Administration',
    ),
  ];

  // ==========================================================
  // MENU NAVIGATION
  // ==========================================================

  void _handleMenuTap(int index) {
    final item = _menuItems[index];

    if (item.route == null) {
      Navigator.of(context).pushReplacementNamed('/dashboard');
      return;
    }

    Navigator.of(context).pushNamed(item.route!);
  }

  void _logout() {
    Navigator.of(context).pushNamed('/logout');
  }

  // ==========================================================
  // ADD USER
  // ==========================================================

  Future<void> _addUser() async {
    final authenticated = await _administratorAuthentication();

    if (!authenticated || !mounted) {
      return;
    }

    await _showAddUserDialog();
  }

  // ==========================================================
  // EDIT USER
  // ==========================================================

  Future<void> _editUser(_SystemUser user) async {
    final authenticated = await _administratorAuthentication();

    if (!authenticated || !mounted) {
      return;
    }

    await _showEditUserDialog(user);
  }

  // ==========================================================
  // ADMINISTRATOR AUTHENTICATION
  // ==========================================================

  Future<bool> _administratorAuthentication() async {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();

    bool showPassword = false;
    String? errorMessage;

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                width: 390,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: const Color(0xFFD1E7F4),
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x50000000),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment:
                      CrossAxisAlignment.stretch,
                  children: [
                    const Row(
                      children: [
                        Icon(
                          Icons.admin_panel_settings_outlined,
                          color: Color(0xFF0879E8),
                          size: 23,
                        ),
                        SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'Administrator Verification',
                            style: TextStyle(
                              color: Color(0xFF174C73),
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),

                    const Text(
                      'Administrator credentials are required to continue.',
                      style: TextStyle(
                        color: Color(0xFF607D8D),
                        fontSize: 14,
                      ),
                    ),

                    const SizedBox(height: 18),

                    _DialogField(
                      controller: usernameController,
                      label: 'Administrator Username',
                      hint: 'Enter administrator username',
                      icon: Icons.person_outline,
                    ),

                    const SizedBox(height: 12),

                    _DialogField(
                      controller: passwordController,
                      label: 'Administrator Password',
                      hint: 'Enter administrator password',
                      icon: Icons.lock_outline,
                      obscureText: !showPassword,
                      suffixIcon: IconButton(
                        onPressed: () {
                          setDialogState(() {
                            showPassword = !showPassword;
                          });
                        },
                        icon: Icon(
                          showPassword
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          size: 19,
                          color: const Color(0xFF557A96),
                        ),
                      ),
                    ),

                    if (errorMessage != null) ...[
                      const SizedBox(height: 11),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFE8EB),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.error_outline,
                              size: 17,
                              color: Color(0xFFE3263D),
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                errorMessage!,
                                style: const TextStyle(
                                  color: Color(0xFFD51F36),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    const SizedBox(height: 18),

                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment.end,
                      children: [
                        _DialogButton(
                          text: 'Cancel',
                          filled: false,
                          onTap: () {
                            Navigator.of(dialogContext)
                                .pop(false);
                          },
                        ),
                        const SizedBox(width: 8),
                        _DialogButton(
                          text: 'Continue',
                          filled: true,
                          onTap: () {
                            if (usernameController.text
                                .trim()
                                .isEmpty) {
                              setDialogState(() {
                                errorMessage =
                                    'Please enter administrator username.';
                              });
                              return;
                            }

                            if (passwordController.text
                                .isEmpty) {
                              setDialogState(() {
                                errorMessage =
                                    'Please enter administrator password.';
                              });
                              return;
                            }

                            Navigator.of(dialogContext)
                                .pop(true);
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    usernameController.dispose();
    passwordController.dispose();

    return result ?? false;
  }

  // ==========================================================
  // ADD USER DIALOG
  // ==========================================================

  Future<void> _showAddUserDialog() async {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();
    final recoveryController = TextEditingController();

    String selectedRole = _roles.isNotEmpty
        ? _roles.first.name
        : 'Operator';

    bool showPassword = false;
    String? errorMessage;

    final result = await showDialog<_SystemUser>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                width: 450,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: const Color(0xFFD1E7F4),
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x50000000),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment:
                        CrossAxisAlignment.stretch,
                    children: [
                      const Row(
                        children: [
                          Icon(
                            Icons.person_add_alt_1_outlined,
                            color: Color(0xFF0879E8),
                            size: 23,
                          ),
                          SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              'Add User',
                              style: TextStyle(
                                color: Color(0xFF174C73),
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 18),

                      _DialogField(
                        controller: usernameController,
                        label: 'Create Username',
                        hint: 'Enter new username',
                        icon: Icons.person_outline,
                      ),

                      const SizedBox(height: 12),

                      _DialogField(
                        controller: passwordController,
                        label: 'Create Password',
                        hint: 'Enter new password',
                        icon: Icons.lock_outline,
                        obscureText: !showPassword,
                        suffixIcon: IconButton(
                          onPressed: () {
                            setDialogState(() {
                              showPassword = !showPassword;
                            });
                          },
                          icon: Icon(
                            showPassword
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            size: 19,
                            color: const Color(0xFF557A96),
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      _DialogField(
                        controller: recoveryController,
                        label: 'Create Recovery Key',
                        hint: 'Enter recovery key',
                        icon: Icons.key_outlined,
                      ),

                      const SizedBox(height: 12),

                      _RoleDropdown(
                        value: selectedRole,
                        roles: _roles,
                        onChanged: (value) {
                          if (value == null) return;

                          setDialogState(() {
                            selectedRole = value;
                          });
                        },
                      ),

                      if (errorMessage != null) ...[
                        const SizedBox(height: 11),
                        _ErrorBox(
                          message: errorMessage!,
                        ),
                      ],

                      const SizedBox(height: 18),

                      Row(
                        mainAxisAlignment:
                            MainAxisAlignment.end,
                        children: [
                          _DialogButton(
                            text: 'Cancel',
                            filled: false,
                            onTap: () {
                              Navigator.of(dialogContext)
                                  .pop();
                            },
                          ),
                          const SizedBox(width: 8),
                          _DialogButton(
                            text: 'Create User',
                            filled: true,
                            onTap: () {
                              final username =
                                  usernameController.text.trim();

                              if (username.isEmpty) {
                                setDialogState(() {
                                  errorMessage =
                                      'Please enter a username.';
                                });
                                return;
                              }

                              if (passwordController.text.isEmpty) {
                                setDialogState(() {
                                  errorMessage =
                                      'Please enter a password.';
                                });
                                return;
                              }

                              if (recoveryController.text
                                  .trim()
                                  .isEmpty) {
                                setDialogState(() {
                                  errorMessage =
                                      'Please enter a recovery key.';
                                });
                                return;
                              }

                              if (_users.any(
                                (user) =>
                                    user.username.toLowerCase() ==
                                    username.toLowerCase(),
                              )) {
                                setDialogState(() {
                                  errorMessage =
                                      'That username already exists.';
                                });
                                return;
                              }

                              Navigator.of(dialogContext).pop(
                                _SystemUser(
                                  username: username,
                                  role: selectedRole,
                                  status: 'Active',
                                  recoveryKey:
                                      recoveryController.text.trim(),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    usernameController.dispose();
    passwordController.dispose();
    recoveryController.dispose();

    if (result == null || !mounted) {
      return;
    }

    setState(() {
      _users.add(result);

      _auditRecords.insert(
        0,
        _AuditRecord(
          time: _currentTime(),
          user: 'admin',
          action: 'User created',
          details: result.username,
        ),
      );
    });

    _showMessage(
      'User ${result.username} created successfully.',
    );
  }

  // ==========================================================
  // EDIT USER DIALOG
  // ==========================================================

  Future<void> _showEditUserDialog(
    _SystemUser user,
  ) async {
    final usernameController =
        TextEditingController(text: user.username);
    final passwordController = TextEditingController();
    final recoveryController =
        TextEditingController(text: user.recoveryKey);

    String selectedRole = user.role;

    bool showPassword = false;
    String? errorMessage;

    final result = await showDialog<_EditResult>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                width: 450,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: const Color(0xFFD1E7F4),
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x50000000),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment:
                        CrossAxisAlignment.stretch,
                    children: [
                      const Row(
                        children: [
                          Icon(
                            Icons.edit_outlined,
                            color: Color(0xFF0879E8),
                            size: 23,
                          ),
                          SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              'Edit User',
                              style: TextStyle(
                                color: Color(0xFF174C73),
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 18),

                      _DialogField(
                        controller: usernameController,
                        label: 'Create New Username',
                        hint: 'Enter new username',
                        icon: Icons.person_outline,
                      ),

                      const SizedBox(height: 12),

                      _DialogField(
                        controller: passwordController,
                        label: 'Create New Password',
                        hint: 'Leave blank to keep current',
                        icon: Icons.lock_outline,
                        obscureText: !showPassword,
                        suffixIcon: IconButton(
                          onPressed: () {
                            setDialogState(() {
                              showPassword = !showPassword;
                            });
                          },
                          icon: Icon(
                            showPassword
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            size: 19,
                            color: const Color(0xFF557A96),
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      _DialogField(
                        controller: recoveryController,
                        label: 'Create New Recovery Key',
                        hint: 'Enter new recovery key',
                        icon: Icons.key_outlined,
                      ),

                      const SizedBox(height: 12),

                      _RoleDropdown(
                        value: selectedRole,
                        roles: _roles,
                        onChanged: (value) {
                          if (value == null) return;

                          setDialogState(() {
                            selectedRole = value;
                          });
                        },
                      ),

                      if (errorMessage != null) ...[
                        const SizedBox(height: 11),
                        _ErrorBox(
                          message: errorMessage!,
                        ),
                      ],

                      const SizedBox(height: 18),

                      Row(
                        children: [
                          // DELETE
                          OutlinedButton.icon(
                            onPressed: () {
                              Navigator.of(dialogContext).pop(
                                _EditResult.delete(),
                              );
                            },
                            icon: const Icon(
                              Icons.delete_outline,
                              size: 17,
                            ),
                            label: const Text(
                              'Delete User',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            style: OutlinedButton.styleFrom(
                              foregroundColor:
                                  const Color(0xFFE3263D),
                              side: const BorderSide(
                                color: Color(0xFFFFB8C0),
                              ),
                              padding:
                                  const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 9,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(5),
                              ),
                            ),
                          ),

                          const Spacer(),

                          _DialogButton(
                            text: 'Cancel',
                            filled: false,
                            onTap: () {
                              Navigator.of(dialogContext)
                                  .pop();
                            },
                          ),

                          const SizedBox(width: 8),

                          _DialogButton(
                            text: 'Save Changes',
                            filled: true,
                            onTap: () {
                              final username =
                                  usernameController.text.trim();

                              if (username.isEmpty) {
                                setDialogState(() {
                                  errorMessage =
                                      'Please enter a username.';
                                });
                                return;
                              }

                              final duplicate = _users.any(
                                (other) =>
                                    other != user &&
                                    other.username
                                            .toLowerCase() ==
                                        username.toLowerCase(),
                              );

                              if (duplicate) {
                                setDialogState(() {
                                  errorMessage =
                                      'That username already exists.';
                                });
                                return;
                              }

                              if (recoveryController.text
                                  .trim()
                                  .isEmpty) {
                                setDialogState(() {
                                  errorMessage =
                                      'Please enter a recovery key.';
                                });
                                return;
                              }

                              Navigator.of(dialogContext).pop(
                                _EditResult.update(
                                  username: username,
                                  password:
                                      passwordController.text,
                                  recoveryKey:
                                      recoveryController.text.trim(),
                                  role: selectedRole,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    usernameController.dispose();
    passwordController.dispose();
    recoveryController.dispose();

    if (result == null || !mounted) {
      return;
    }

    if (result.deleteUser) {
      if (user.username.toLowerCase() == 'admin') {
        _showMessage(
          'The main administrator account cannot be deleted.',
        );
        return;
      }

      setState(() {
        _users.remove(user);

        _auditRecords.insert(
          0,
          _AuditRecord(
            time: _currentTime(),
            user: 'admin',
            action: 'User deleted',
            details: user.username,
          ),
        );
      });

      _showMessage(
        'User ${user.username} deleted.',
      );

      return;
    }

    setState(() {
      user.username = result.username!;
      user.role = result.role!;
      user.recoveryKey = result.recoveryKey!;

      _auditRecords.insert(
        0,
        _AuditRecord(
          time: _currentTime(),
          user: 'admin',
          action: 'User updated',
          details: user.username,
        ),
      );
    });

    _showMessage(
      'User ${user.username} updated successfully.',
    );
  }

  // ==========================================================
  // ROLES
  // ==========================================================

  Future<void> _addRole() async {
    final authenticated =
        await _administratorAuthentication();

    if (!authenticated || !mounted) {
      return;
    }

    await _showRoleDialog();
  }

  Future<void> _editRole(_SystemRole role) async {
    final authenticated =
        await _administratorAuthentication();

    if (!authenticated || !mounted) {
      return;
    }

    await _showRoleDialog(
      existingRole: role,
    );
  }

  Future<void> _showRoleDialog({
    _SystemRole? existingRole,
  }) async {
    final nameController = TextEditingController(
      text: existingRole?.name ?? '',
    );

    final descriptionController = TextEditingController(
      text: existingRole?.description ?? '',
    );

    final permissions = <String, bool>{
      for (final permission in _allPermissions)
        permission:
            existingRole?.permissions[permission] ?? false,
    };

    String? errorMessage;

    final result = await showDialog<_SystemRole>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                width: 500,
                constraints: const BoxConstraints(
                  maxHeight: 650,
                ),
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: const Color(0xFFD1E7F4),
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x50000000),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment:
                      CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.admin_panel_settings_outlined,
                          color: Color(0xFF0879E8),
                          size: 23,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            existingRole == null
                                ? 'Create Role'
                                : 'Edit Role',
                            style: const TextStyle(
                              color: Color(0xFF174C73),
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    _DialogField(
                      controller: nameController,
                      label: 'Role Name',
                      hint: 'Enter role name',
                      icon: Icons.badge_outlined,
                    ),

                    const SizedBox(height: 12),

                    _DialogField(
                      controller: descriptionController,
                      label: 'Description',
                      hint: 'Enter role description',
                      icon: Icons.description_outlined,
                    ),

                    const SizedBox(height: 16),

                    const Text(
                      'Permissions',
                      style: TextStyle(
                        color: Color(0xFF23465D),
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),

                    const SizedBox(height: 7),

                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFFF7FBFE),
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                            color: const Color(0xFFD1E7F4),
                          ),
                        ),
                        child: ListView(
                          padding: const EdgeInsets.symmetric(
                            vertical: 4,
                          ),
                          children: [
                            ..._allPermissions.map(
                              (permission) {
                                return CheckboxListTile(
                                  dense: true,
                                  value:
                                      permissions[permission] ??
                                          false,
                                  onChanged: (value) {
                                    setDialogState(() {
                                      permissions[permission] =
                                          value ?? false;
                                    });
                                  },
                                  activeColor:
                                      const Color(0xFF0879E8),
                                  controlAffinity:
                                      ListTileControlAffinity.leading,
                                  title: Text(
                                    permission,
                                    style: const TextStyle(
                                      color: Color(0xFF38566A),
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),

                    if (errorMessage != null) ...[
                      const SizedBox(height: 10),
                      _ErrorBox(
                        message: errorMessage!,
                      ),
                    ],

                    const SizedBox(height: 15),

                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment.end,
                      children: [
                        _DialogButton(
                          text: 'Cancel',
                          filled: false,
                          onTap: () {
                            Navigator.of(dialogContext).pop();
                          },
                        ),
                        const SizedBox(width: 8),
                        _DialogButton(
                          text: existingRole == null
                              ? 'Create Role'
                              : 'Save Changes',
                          filled: true,
                          onTap: () {
                            final name =
                                nameController.text.trim();

                            if (name.isEmpty) {
                              setDialogState(() {
                                errorMessage =
                                    'Please enter a role name.';
                              });
                              return;
                            }

                            final duplicate = _roles.any(
                              (role) =>
                                  role != existingRole &&
                                  role.name.toLowerCase() ==
                                      name.toLowerCase(),
                            );

                            if (duplicate) {
                              setDialogState(() {
                                errorMessage =
                                    'That role already exists.';
                              });
                              return;
                            }

                            Navigator.of(dialogContext).pop(
                              _SystemRole(
                                name: name,
                                description:
                                    descriptionController.text
                                        .trim(),
                                permissions:
                                    Map<String, bool>.from(
                                  permissions,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    nameController.dispose();
    descriptionController.dispose();

    if (result == null || !mounted) {
      return;
    }

    setState(() {
      if (existingRole == null) {
        _roles.add(result);

        _auditRecords.insert(
          0,
          _AuditRecord(
            time: _currentTime(),
            user: 'admin',
            action: 'Role created',
            details: result.name,
          ),
        );
      } else {
        existingRole.name = result.name;
        existingRole.description = result.description;
        existingRole.permissions =
            result.permissions;

        _auditRecords.insert(
          0,
          _AuditRecord(
            time: _currentTime(),
            user: 'admin',
            action: 'Role updated',
            details: result.name,
          ),
        );
      }
    });

    _showMessage(
      existingRole == null
          ? 'Role created successfully.'
          : 'Role updated successfully.',
    );
  }

  // ==========================================================
  // ALL PERMISSIONS
  // ==========================================================

  static const List<String> _allPermissions = [
    'Dashboard',
    'Alerts',
    'Patients',
    'Bed/Wards',
    'Devices',
    'Receiver',
    'Reports',
    'Logs',
    'Settings',
    'Administration',
    'Manage Users',
    'Manage Roles',
  ];

  // ==========================================================
  // TIME
  // ==========================================================

  String _currentTime() {
    final now = TimeOfDay.now();

    final hour =
        now.hour.toString().padLeft(2, '0');

    final minute =
        now.minute.toString().padLeft(2, '0');

    return '$hour:$minute';
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(
          seconds: 2,
        ),
      ),
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            _AdministrationSidebar(
              selectedIndex: _selectedIndex,
              menuItems: _menuItems,
              onMenuTap: _handleMenuTap,
              onLogout: _logout,
            ),

            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // ==================================================
                  // HOSPITAL BACKGROUND
                  // ==================================================

                  Image.asset(
                    'assets/images/hospital.png',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                    errorBuilder: (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return Container(
                        color: const Color(0xFFEAF3F9),
                      );
                    },
                  ),

                  // ==================================================
                  // SAME OVERLAY AS LOGIN
                  // ==================================================

                  Container(
                    color: const Color(0x18002545),
                  ),

                  // ==================================================
                  // ADMINISTRATION CONTENT
                  // ==================================================

                  _AdministrationContent(
                    selectedTab: _selectedTab,
                    users: _users,
                    roles: _roles,
                    auditRecords: _auditRecords,
                    onTabChanged: (index) {
                      setState(() {
                        _selectedTab = index;
                      });
                    },
                    onAddUser: _addUser,
                    onEditUser: _editUser,
                    onAddRole: _addRole,
                    onEditRole: _editRole,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  const _MenuItem({
    required this.title,
    required this.icon,
    required this.route,
  });

  final String title;
  final IconData icon;
  final String? route;
}

// ============================================================
// SIDEBAR
// ============================================================

class _AdministrationSidebar extends StatelessWidget {
  const _AdministrationSidebar({
    required this.selectedIndex,
    required this.menuItems,
    required this.onMenuTap,
    required this.onLogout,
  });

  final int selectedIndex;
  final List<_MenuItem> menuItems;
  final ValueChanged<int> onMenuTap;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      decoration: const BoxDecoration(
        color: Color(0xFF062E58),
      ),
      child: Column(
        children: [
          const SizedBox(height: 9),

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: menuItems.length,
              itemBuilder: (
                context,
                index,
              ) {
                final item = menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected:
                        selectedIndex == index,
                    onTap: () =>
                        onMenuTap(index),
                  ),
                );
              },
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: onLogout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() =>
      _SidebarButtonState();
}

class _SidebarButtonState
    extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final highlighted =
        widget.selected || _hovering;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,
          constraints: const BoxConstraints(
            minHeight: 42,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: widget.selected
                ? const Color(0xFF0879E8)
                : highlighted
                    ? const Color(0xFF0A416E)
                    : Colors.transparent,
            borderRadius:
                BorderRadius.circular(5),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.visible,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ADMINISTRATION CONTENT
// ============================================================

class _AdministrationContent extends StatelessWidget {
  const _AdministrationContent({
    required this.selectedTab,
    required this.users,
    required this.roles,
    required this.auditRecords,
    required this.onTabChanged,
    required this.onAddUser,
    required this.onEditUser,
    required this.onAddRole,
    required this.onEditRole,
  });

  final int selectedTab;
  final List<_SystemUser> users;
  final List<_SystemRole> roles;
  final List<_AuditRecord> auditRecords;

  final ValueChanged<int> onTabChanged;
  final VoidCallback onAddUser;
  final ValueChanged<_SystemUser> onEditUser;
  final VoidCallback onAddRole;
  final ValueChanged<_SystemRole> onEditRole;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        return SingleChildScrollView(
          physics:
              const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            12,
            10,
            12,
            12,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight:
                  constraints.maxHeight - 22,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.stretch,
              children: [
                _AdministrationTopBar(
                  selectedTab: selectedTab,
                  onTabChanged: onTabChanged,
                  onAddUser: onAddUser,
                  onAddRole: onAddRole,
                ),

                const SizedBox(height: 10),

                if (selectedTab == 0)
                  _UsersTab(
                    users: users,
                    onEditUser: onEditUser,
                  ),

                if (selectedTab == 1)
                  _RolesPermissionsTab(
                    roles: roles,
                    onAddRole: onAddRole,
                    onEditRole: onEditRole,
                  ),

                if (selectedTab == 2)
                  _AuditTrailTab(
                    records: auditRecords,
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// TOP BAR
// ============================================================

class _AdministrationTopBar
    extends StatelessWidget {
  const _AdministrationTopBar({
    required this.selectedTab,
    required this.onTabChanged,
    required this.onAddUser,
    required this.onAddRole,
  });

  final int selectedTab;
  final ValueChanged<int> onTabChanged;
  final VoidCallback onAddUser;
  final VoidCallback onAddRole;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.97),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x30000000),
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          _TopTab(
            title: 'Users',
            selected: selectedTab == 0,
            icon: Icons.people_outline,
            onTap: () => onTabChanged(0),
          ),

          _TopTab(
            title: 'Roles & Permissions',
            selected: selectedTab == 1,
            icon: Icons.admin_panel_settings_outlined,
            onTap: () => onTabChanged(1),
          ),

          _TopTab(
            title: 'Audit Trail',
            selected: selectedTab == 2,
            icon: Icons.history,
            onTap: () => onTabChanged(2),
          ),

          const Spacer(),

          if (selectedTab == 0)
            _TopActionButton(
              icon: Icons.add,
              text: 'Add User',
              onTap: onAddUser,
            ),

          if (selectedTab == 1)
            _TopActionButton(
              icon: Icons.add,
              text: 'Add Role',
              onTap: onAddRole,
            ),
        ],
      ),
    );
  }
}

// ============================================================
// TOP TAB
// ============================================================

class _TopTab extends StatelessWidget {
  const _TopTab({
    required this.title,
    required this.selected,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final bool selected;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration:
              const Duration(milliseconds: 150),
          margin: const EdgeInsets.only(
            right: 4,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 11,
            vertical: 8,
          ),
          decoration: BoxDecoration(
            color: selected
                ? const Color(0xFFE6F3FD)
                : Colors.transparent,
            borderRadius:
                BorderRadius.circular(5),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 17,
                color: selected
                    ? const Color(0xFF0879E8)
                    : const Color(0xFF668397),
              ),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  color: selected
                      ? const Color(0xFF0879E8)
                      : const Color(0xFF59788D),
                  fontSize: 14,
                  fontWeight: selected
                      ? FontWeight.w800
                      : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// TOP ACTION BUTTON
// ============================================================

class _TopActionButton
    extends StatelessWidget {
  const _TopActionButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  final IconData icon;
  final String text;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(
        icon,
        size: 17,
      ),
      label: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
        ),
      ),
      style: ElevatedButton.styleFrom(
        elevation: 0,
        backgroundColor:
            const Color(0xFF0879E8),
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 9,
        ),
        minimumSize: const Size(
          0,
          34,
        ),
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(5),
        ),
      ),
    );
  }
}

// ============================================================
// USERS TAB
// ============================================================

class _UsersTab extends StatelessWidget {
  const _UsersTab({
    required this.users,
    required this.onEditUser,
  });

  final List<_SystemUser> users;
  final ValueChanged<_SystemUser> onEditUser;

  @override
  Widget build(BuildContext context) {
    return _AdministrationPanel(
      title: 'Users',
      child: Column(
        children: [
          const _UsersHeader(),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          if (users.isEmpty)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Text(
                'No users found.',
                style: TextStyle(
                  color: Color(0xFF668397),
                  fontSize: 14,
                ),
              ),
            )
          else
            ...users.map(
              (user) => _UserRow(
                user: user,
                onEdit: () =>
                    onEditUser(user),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================
// USERS HEADER
// ============================================================

class _UsersHeader extends StatelessWidget {
  const _UsersHeader();

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 38,
      child: Row(
        children: [
          Expanded(
            flex: 30,
            child: Text(
              'Username',
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 24,
            child: Text(
              'Role',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 22,
            child: Text(
              'Status',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 24,
            child: Text(
              'Action',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// USER ROW
// ============================================================

class _UserRow extends StatefulWidget {
  const _UserRow({
    required this.user,
    required this.onEdit,
  });

  final _SystemUser user;
  final VoidCallback onEdit;

  @override
  State<_UserRow> createState() =>
      _UserRowState();
}

class _UserRowState extends State<_UserRow> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.basic,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: _hovering
              ? const Color(0xFFF5FAFD)
              : Colors.white,
          border: const Border(
            bottom: BorderSide(
              color: Color(0xFFE7F0F5),
            ),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 30,
              child: Text(
                widget.user.username,
                style: const TextStyle(
                  color: Color(0xFF315C75),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            Expanded(
              flex: 24,
              child: Text(
                widget.user.role,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF52758A),
                  fontSize: 14,
                ),
              ),
            ),

            Expanded(
              flex: 22,
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(
                      0xFFDDF5EA,
                    ),
                    borderRadius:
                        BorderRadius.circular(4),
                  ),
                  child: Text(
                    widget.user.status,
                    style: const TextStyle(
                      color: Color(0xFF087C50),
                      fontSize: 14,
                      fontWeight:
                          FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),

            Expanded(
              flex: 24,
              child: Center(
                child: TextButton(
                  onPressed: widget.onEdit,
                  style: TextButton.styleFrom(
                    foregroundColor:
                        const Color(0xFF0879E8),
                    backgroundColor:
                        const Color(0xFFEAF5FD),
                    minimumSize:
                        const Size(55, 29),
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    shape:
                        RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(4),
                    ),
                  ),
                  child: const Text(
                    'Edit',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight:
                          FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ROLES & PERMISSIONS TAB
// ============================================================

class _RolesPermissionsTab
    extends StatelessWidget {
  const _RolesPermissionsTab({
    required this.roles,
    required this.onAddRole,
    required this.onEditRole,
  });

  final List<_SystemRole> roles;
  final VoidCallback onAddRole;
  final ValueChanged<_SystemRole> onEditRole;

  @override
  Widget build(BuildContext context) {
    return _AdministrationPanel(
      title: 'Roles & Permissions',
      child: LayoutBuilder(
        builder: (
          context,
          constraints,
        ) {
          if (constraints.maxWidth < 850) {
            return Column(
              children: roles
                  .map(
                    (role) => Padding(
                      padding:
                          const EdgeInsets.only(
                        bottom: 10,
                      ),
                      child: _RoleCard(
                        role: role,
                        onEdit: () =>
                            onEditRole(role),
                      ),
                    ),
                  )
                  .toList(),
            );
          }

          return GridView.builder(
            shrinkWrap: true,
            physics:
                const NeverScrollableScrollPhysics(),
            itemCount: roles.length,
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.75,
            ),
            itemBuilder: (
              context,
              index,
            ) {
              final role = roles[index];

              return _RoleCard(
                role: role,
                onEdit: () =>
                    onEditRole(role),
              );
            },
          );
        },
      ),
    );
  }
}

// ============================================================
// ROLE CARD
// ============================================================

class _RoleCard extends StatelessWidget {
  const _RoleCard({
    required this.role,
    required this.onEdit,
  });

  final _SystemRole role;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final enabledPermissions =
        role.permissions.values
            .where((value) => value)
            .length;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 35,
                height: 35,
                decoration: BoxDecoration(
                  color:
                      const Color(0xFFE7F3FC),
                  borderRadius:
                      BorderRadius.circular(5),
                ),
                child: const Icon(
                  Icons.admin_panel_settings_outlined,
                  color:
                      Color(0xFF0879E8),
                  size: 20,
                ),
              ),

              const SizedBox(width: 9),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      role.name,
                      style:
                          const TextStyle(
                        color:
                            Color(0xFF214B69),
                        fontSize: 14,
                        fontWeight:
                            FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      role.description,
                      maxLines: 1,
                      overflow:
                          TextOverflow.ellipsis,
                      style:
                          const TextStyle(
                        color:
                            Color(0xFF6A8495),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),

              IconButton(
                onPressed: onEdit,
                tooltip: 'Edit role',
                icon: const Icon(
                  Icons.edit_outlined,
                  size: 18,
                ),
                color:
                    const Color(0xFF0879E8),
              ),
            ],
          ),

          const SizedBox(height: 10),

          Container(
            height: 1,
            color: const Color(
              0xFFE3EEF4,
            ),
          ),

          const SizedBox(height: 9),

          Row(
            children: [
              const Icon(
                Icons.check_circle_outline,
                size: 17,
                color:
                    Color(0xFF0B9A61),
              ),
              const SizedBox(width: 6),
              Text(
                '$enabledPermissions permissions enabled',
                style:
                    const TextStyle(
                  color:
                      Color(0xFF52758A),
                  fontSize: 14,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          Expanded(
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 5,
                runSpacing: 5,
                children: role.permissions.entries
                    .where(
                      (entry) => entry.value,
                    )
                    .map(
                      (entry) => Container(
                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal: 7,
                          vertical: 4,
                        ),
                        decoration:
                            BoxDecoration(
                          color:
                              const Color(
                            0xFFEAF5FD,
                          ),
                          borderRadius:
                              BorderRadius
                                  .circular(4),
                        ),
                        child: Text(
                          entry.key,
                          style:
                              const TextStyle(
                            color:
                                Color(
                              0xFF39718F,
                            ),
                            fontSize: 14,
                            fontWeight:
                                FontWeight.w600,
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// AUDIT TRAIL TAB
// ============================================================

class _AuditTrailTab
    extends StatelessWidget {
  const _AuditTrailTab({
    required this.records,
  });

  final List<_AuditRecord> records;

  @override
  Widget build(BuildContext context) {
    return _AdministrationPanel(
      title: 'Audit Trail',
      child: Column(
        children: [
          const _AuditHeader(),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          if (records.isEmpty)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Text(
                'No audit records found.',
                style: TextStyle(
                  color: Color(0xFF668397),
                  fontSize: 14,
                ),
              ),
            )
          else
            ...records.map(
              (record) => _AuditRow(
                record: record,
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================
// AUDIT HEADER
// ============================================================

class _AuditHeader extends StatelessWidget {
  const _AuditHeader();

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 38,
      child: Row(
        children: [
          Expanded(
            flex: 15,
            child: Text(
              'Time',
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 20,
            child: Text(
              'User',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 30,
            child: Text(
              'Action',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 35,
            child: Text(
              'Details',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF59788D),
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// AUDIT ROW
// ============================================================

class _AuditRow extends StatelessWidget {
  const _AuditRow({
    required this.record,
  });

  final _AuditRecord record;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 47,
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE7F0F5),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 15,
            child: Text(
              record.time,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),

          Expanded(
            flex: 20,
            child: Text(
              record.user,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          Expanded(
            flex: 30,
            child: Text(
              record.action,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
              ),
            ),
          ),

          Expanded(
            flex: 35,
            child: Text(
              record.details,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GENERIC ADMINISTRATION PANEL
// ============================================================

class _AdministrationPanel
    extends StatelessWidget {
  const _AdministrationPanel({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        9,
        8,
        9,
        9,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.97),
        borderRadius:
            BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x30000000),
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 31,
            child: Text(
              title,
              style: const TextStyle(
                color: Color(0xFF214B69),
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          const SizedBox(height: 5),

          child,
        ],
      ),
    );
  }
}

// ============================================================
// ROLE DROPDOWN
// ============================================================

class _RoleDropdown
    extends StatelessWidget {
  const _RoleDropdown({
    required this.value,
    required this.roles,
    required this.onChanged,
  });

  final String value;
  final List<_SystemRole> roles;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: value,
      onChanged: onChanged,
      style: const TextStyle(
        color: Color(0xFF38566A),
        fontSize: 14,
      ),
      decoration: InputDecoration(
        labelText: 'Role',
        labelStyle: const TextStyle(
          color: Color(0xFF668397),
          fontSize: 14,
        ),
        prefixIcon: const Icon(
          Icons.badge_outlined,
          size: 19,
          color: Color(0xFF557A96),
        ),
        filled: true,
        fillColor: const Color(0xFFF7FBFE),
        contentPadding:
            const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 8,
        ),
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(5),
          borderSide: const BorderSide(
            color: Color(0xFFD1E7F4),
          ),
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(5),
          borderSide: const BorderSide(
            color: Color(0xFFD1E7F4),
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(5),
          borderSide: const BorderSide(
            color: Color(0xFF0879E8),
            width: 1.3,
          ),
        ),
      ),
      items: roles
          .map(
            (role) =>
                DropdownMenuItem<String>(
              value: role.name,
              child: Text(
                role.name,
                style: const TextStyle(
                  fontSize: 14,
                  color:
                      Color(0xFF38566A),
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}

// ============================================================
// DIALOG FIELD
// ============================================================

class _DialogField
    extends StatelessWidget {
  const _DialogField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscureText = false,
    this.suffixIcon,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscureText;
  final Widget? suffixIcon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(
            color: Color(0xFF668397),
            fontSize: 14,
          ),
          hintStyle: const TextStyle(
            color: Color(0xFFA1B6C5),
            fontSize: 14,
          ),
          prefixIcon: Icon(
            icon,
            size: 19,
            color: const Color(0xFF557A96),
          ),
          suffixIcon: suffixIcon,
          filled: true,
          fillColor:
              const Color(0xFFF7FBFE),
          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 10,
          ),
          border: OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFD1E7F4),
            ),
          ),
          enabledBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFD1E7F4),
            ),
          ),
          focusedBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// DIALOG BUTTON
// ============================================================

class _DialogButton
    extends StatelessWidget {
  const _DialogButton({
    required this.text,
    required this.filled,
    required this.onTap,
  });

  final String text;
  final bool filled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    if (filled) {
      return ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor:
              const Color(0xFF0879E8),
          foregroundColor: Colors.white,
          padding:
              const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 9,
          ),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(5),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      );
    }

    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        foregroundColor:
            const Color(0xFF52758A),
        side: const BorderSide(
          color: Color(0xFFD1E7F4),
        ),
        backgroundColor: Colors.white,
        padding:
            const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 9,
        ),
        shape:
            RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(5),
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// ============================================================
// ERROR BOX
// ============================================================

class _ErrorBox extends StatelessWidget {
  const _ErrorBox({
    required this.message,
  });

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE8EB),
        borderRadius:
            BorderRadius.circular(5),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.error_outline,
            size: 17,
            color: Color(0xFFE3263D),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: Color(0xFFD51F36),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SYSTEM USER
// ============================================================

class _SystemUser {
  _SystemUser({
    required this.username,
    required this.role,
    required this.status,
    required this.recoveryKey,
  });

  String username;
  String role;
  String status;
  String recoveryKey;
}

// ============================================================
// SYSTEM ROLE
// ============================================================

class _SystemRole {
  _SystemRole({
    required this.name,
    required this.description,
    required this.permissions,
  });

  String name;
  String description;
  Map<String, bool> permissions;
}

// ============================================================
// AUDIT RECORD
// ============================================================

class _AuditRecord {
  const _AuditRecord({
    required this.time,
    required this.user,
    required this.action,
    required this.details,
  });

  final String time;
  final String user;
  final String action;
  final String details;
}

// ============================================================
// EDIT RESULT
// ============================================================

class _EditResult {
  const _EditResult({
    this.deleteUser = false,
    this.username,
    this.password,
    this.recoveryKey,
    this.role,
  });

  factory _EditResult.delete() {
    return const _EditResult(
      deleteUser: true,
    );
  }

  factory _EditResult.update({
    required String username,
    required String password,
    required String recoveryKey,
    required String role,
  }) {
    return _EditResult(
      username: username,
      password: password,
      recoveryKey: recoveryKey,
      role: role,
    );
  }

  final bool deleteUser;
  final String? username;
  final String? password;
  final String? recoveryKey;
  final String? role;
}