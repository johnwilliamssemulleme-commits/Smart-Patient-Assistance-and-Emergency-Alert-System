import 'package:flutter/material.dart';
import 'dashboard.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// receiver.dart
///
/// SCREEN — HALL RECEIVER STATUS
///
/// FEATURES:
/// 1. Hospital image background
/// 2. Light background overlay
/// 3. Own sidebar
/// 4. Receiver highlighted
/// 5. Home opens dashboard.dart
/// 6. Communication log
/// 7. Receiver status cards
/// 8. Responsive layout
/// 9. All visible text uses 14px
/// ============================================================

class ReceiverScreen extends StatefulWidget {
  const ReceiverScreen({
    super.key,
  });

  @override
  State<ReceiverScreen> createState() => _ReceiverScreenState();
}

class _ReceiverScreenState extends State<ReceiverScreen> {
  // Receiver is the 6th button.
  int _selectedIndex = 5;

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_rounded,
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline_rounded,
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.bed_outlined,
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_other_outlined,
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_rounded,
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.description_outlined,
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
    ),
  ];

  // ==========================================================
  // NAVIGATION
  // ==========================================================

  void _handleMenuTap(int index) {
    setState(() {
      _selectedIndex = index;
    });

    final String title = _menuItems[index].title;

    // ----------------------------------------------------------
    // HOME → DASHBOARD.DART
    // ----------------------------------------------------------

    if (title == 'Home') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const DashboardScreen(),
        ),
      );
      return;
    }

    // ----------------------------------------------------------
    // RECEIVER
    // ----------------------------------------------------------

    if (title == 'Receiver') {
      return;
    }

    // ----------------------------------------------------------
    // OTHER PAGES
    // ----------------------------------------------------------

    switch (title) {
      case 'Alerts':
        Navigator.pushNamed(context, '/alerts');
        break;

      case 'Patients':
        Navigator.pushNamed(context, '/patients');
        break;

      case 'Bed/Wards':
        Navigator.pushNamed(context, '/beds-wards');
        break;

      case 'Devices':
        Navigator.pushNamed(context, '/devices');
        break;

      case 'Reports':
        Navigator.pushNamed(context, '/reports');
        break;

      case 'Logs':
        Navigator.pushNamed(context, '/logs');
        break;

      case 'Settings':
        Navigator.pushNamed(context, '/settings');
        break;

      case 'Administration':
        Navigator.pushNamed(context, '/administration');
        break;
    }
  }

  // ==========================================================
  // LOGOUT
  // ==========================================================

  void _logout() {
    Navigator.pushNamed(
      context,
      '/logout',
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ----------------------------------------------------
          // HOSPITAL BACKGROUND IMAGE
          // ----------------------------------------------------

          Image.asset(
            'assets/images/hospital.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                color: const Color(0xFFEAF3F9),
                child: const Center(
                  child: Text(
                    'Hospital background image not found',
                    style: TextStyle(
                      color: Color(0xFF31556D),
                      fontSize: 14,
                    ),
                  ),
                ),
              );
            },
          ),

          // ----------------------------------------------------
          // LIGHT OVERLAY
          // ----------------------------------------------------

          Container(
            color: const Color(0x18002545),
          ),

          // ----------------------------------------------------
          // MAIN APPLICATION LAYOUT
          // ----------------------------------------------------

          SafeArea(
            child: Row(
              children: [
                // ------------------------------------------------
                // LEFT SIDEBAR
                // ------------------------------------------------

                _ReceiverSidebar(
                  selectedIndex: _selectedIndex,
                  menuItems: _menuItems,
                  onMenuTap: _handleMenuTap,
                  onLogout: _logout,
                ),

                // ------------------------------------------------
                // MAIN CONTENT
                // ------------------------------------------------

                const Expanded(
                  child: _ReceiverBody(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  const _MenuItem({
    required this.title,
    required this.icon,
  });

  final String title;
  final IconData icon;
}

// ============================================================
// SIDEBAR
// ============================================================

class _ReceiverSidebar extends StatelessWidget {
  const _ReceiverSidebar({
    required this.selectedIndex,
    required this.menuItems,
    required this.onMenuTap,
    required this.onLogout,
  });

  final int selectedIndex;
  final List<_MenuItem> menuItems;
  final ValueChanged<int> onMenuTap;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      decoration: const BoxDecoration(
        color: Color(0xFF062E58),
      ),
      child: Column(
        children: [
          const SizedBox(height: 9),

          // ----------------------------------------------------
          // SYSTEM LOGO
          // ----------------------------------------------------

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          // ----------------------------------------------------
          // NAVIGATION
          // ----------------------------------------------------

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected: selectedIndex == index,
                    onTap: () => onMenuTap(index),
                  ),
                );
              },
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          // ----------------------------------------------------
          // LOGOUT
          // ----------------------------------------------------

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: onLogout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() => _SidebarButtonState();
}

class _SidebarButtonState extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final bool highlighted =
        widget.selected || _hovering;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,
          constraints: const BoxConstraints(
            minHeight: 42,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: widget.selected
                ? const Color(0xFF0879E8)
                : highlighted
                    ? const Color(0xFF0A416E)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.visible,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// RECEIVER BODY
// ============================================================

class _ReceiverBody extends StatelessWidget {
  const _ReceiverBody();

  @override
  Widget build(BuildContext context) {
    // IMPORTANT:
    // No opaque F4FAFE background here.
    // This allows hospital.png to remain visible behind
    // the receiver content.
    return Container(
      color: Colors.transparent,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(
              9,
              7,
              9,
              8,
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: (constraints.maxHeight - 15)
                    .clamp(0.0, double.infinity),
              ),
              child: const Column(
                crossAxisAlignment:
                    CrossAxisAlignment.stretch,
                children: [
                  _ReceiverHeader(),
                  SizedBox(height: 7),
                  _ReceiverContent(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// RECEIVER HEADER
// ============================================================

class _ReceiverHeader extends StatelessWidget {
  const _ReceiverHeader();

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 32,
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          'Hall Receiver Status',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Color(0xFF174C73),
            fontSize: 14,
            height: 1.0,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// RECEIVER CONTENT
// ============================================================

class _ReceiverContent extends StatelessWidget {
  const _ReceiverContent();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 700) {
          return const Column(
            crossAxisAlignment:
                CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                height: 280,
                child: _ReceiverStatusCards(),
              ),
              SizedBox(height: 9),
              SizedBox(
                height: 300,
                child: _CommunicationLog(),
              ),
            ],
          );
        }

        return const SizedBox(
          height: 280,
          child: Row(
            crossAxisAlignment:
                CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: 250,
                child: _ReceiverStatusCards(),
              ),
              SizedBox(width: 10),
              Expanded(
                child: _CommunicationLog(),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ============================================================
// STATUS CARDS
// ============================================================

class _ReceiverStatusCards extends StatelessWidget {
  const _ReceiverStatusCards();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Expanded(
          child: _ReceiverStatusCard(
            title: 'Connected Devices',
            value: '28',
            suffix: ' / 30',
            icon: Icons.check_circle,
          ),
        ),
        SizedBox(height: 7),
        Expanded(
          child: _ReceiverStatusCard(
            title: 'Signal Strength',
            value: '92',
            suffix: ' %',
            icon: Icons.wifi_rounded,
          ),
        ),
        SizedBox(height: 7),
        Expanded(
          child: _ReceiverStatusCard(
            title: 'Last Seen',
            value: '14:32',
            suffix: '',
            icon: Icons.access_time_rounded,
          ),
        ),
        SizedBox(height: 7),
        SizedBox(
          height: 45,
          child: _ReceiverOnlineCard(),
        ),
      ],
    );
  }
}

// ============================================================
// STATUS CARD
// ============================================================

class _ReceiverStatusCard extends StatelessWidget {
  const _ReceiverStatusCard({
    required this.title,
    required this.value,
    required this.suffix,
    required this.icon,
  });

  final String title;
  final String value;
  final String suffix;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: const Color(0xFF0BAA83),
                size: 16,
              ),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF315C78),
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const Spacer(),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: value,
                  style: const TextStyle(
                    color: Color(0xFF174C73),
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (suffix.isNotEmpty)
                  TextSpan(
                    text: suffix,
                    style: const TextStyle(
                      color: Color(0xFF10A66B),
                      fontSize: 14,
                      height: 1.0,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
              ],
            ),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}

// ============================================================
// ONLINE CARD
// ============================================================

class _ReceiverOnlineCard extends StatelessWidget {
  const _ReceiverOnlineCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FFFC),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 16,
            height: 16,
            decoration: const BoxDecoration(
              color: Color(0xFF0BAA83),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.check,
              color: Colors.white,
              size: 11,
            ),
          ),
          const SizedBox(width: 7),
          const Expanded(
            child: Text(
              'Receiver Online',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Color(0xFF07986F),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// COMMUNICATION LOG
// ============================================================

class _CommunicationLog extends StatelessWidget {
  const _CommunicationLog();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        8,
        7,
        8,
        7,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        children: [
          const SizedBox(
            height: 28,
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Communication Log',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Color(0xFF214B69),
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(height: 2),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFFBFEFF),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: const Color(0xFFE1F0F7),
                ),
              ),
              child: const Column(
                children: [
                  _CommunicationHeader(),
                  Divider(
                    height: 1,
                    color: Color(0xFFDCECF6),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          _CommunicationRow(
                            time: '14:32',
                            deviceId: 'D-014',
                            message: 'Heartbeat',
                            status: 'OK',
                          ),
                          _CommunicationRow(
                            time: '14:31',
                            deviceId: 'D-006',
                            message: 'Heartbeat',
                            status: 'OK',
                          ),
                          _CommunicationRow(
                            time: '14:29',
                            deviceId: 'D-012',
                            message: 'Heartbeat',
                            status: 'OK',
                          ),
                          _CommunicationRow(
                            time: '14:28',
                            deviceId: 'D-015',
                            message: 'Data received',
                            status: 'OK',
                          ),
                          _CommunicationRow(
                            time: '14:26',
                            deviceId: 'D-009',
                            message: 'Heartbeat',
                            status: 'OK',
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// COMMUNICATION HEADER
// ============================================================

class _CommunicationHeader extends StatelessWidget {
  const _CommunicationHeader();

  @override
  Widget build(BuildContext context) {
    const headers = [
      'Time',
      'Device ID',
      'Message',
      'Status',
    ];

    const flexes = [
      19,
      24,
      38,
      19,
    ];

    return SizedBox(
      height: 32,
      child: Row(
        children: List.generate(
          headers.length,
          (index) {
            return Expanded(
              flex: flexes[index],
              child: Text(
                headers[index],
                textAlign: index == 0
                    ? TextAlign.left
                    : TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF59788D),
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// COMMUNICATION ROW
// ============================================================

class _CommunicationRow extends StatelessWidget {
  const _CommunicationRow({
    required this.time,
    required this.deviceId,
    required this.message,
    required this.status,
  });

  final String time;
  final String deviceId;
  final String message;
  final String status;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE7F0F5),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 19,
            child: Text(
              time,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF4C6B80),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 24,
            child: Text(
              deviceId,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF39718F),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 38,
            child: Text(
              message,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: message == 'Data received'
                    ? const Color(0xFF07986F)
                    : const Color(0xFF4C6B80),
                fontSize: 14,
                fontWeight: message == 'Data received'
                    ? FontWeight.w600
                    : FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 19,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 6,
                  vertical: 3,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFE4F8EE),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  status,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF07986F),
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}