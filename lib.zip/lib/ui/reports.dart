import 'dart:math' as math;
import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// reports.dart
///
/// SCREEN — REPORTS
///
/// Navigation:
/// Home           -> Dashboard
/// Alerts         -> /alerts
/// Patients       -> /patients
/// Bed/Wards      -> /beds-wards
/// Devices        -> /devices
/// Receiver       -> /receiver
/// Reports        -> Reports
/// Logs           -> /logs
/// Settings       -> /settings
/// Administration -> /administration
/// Logout         -> /logout
///
/// Background:
/// assets/images/hospital.png
///
/// All visible text uses 14px.
/// ============================================================

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({
    super.key,
  });

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int _selectedIndex = 6;

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
      route: null,
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_rounded,
      route: '/alerts',
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline_rounded,
      route: '/patients',
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.bed_outlined,
      route: '/beds-wards',
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_other_outlined,
      route: '/devices',
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
      route: '/receiver',
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_rounded,
      route: '/reports',
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.description_outlined,
      route: '/logs',
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
      route: '/settings',
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
      route: '/administration',
    ),
  ];

  void _handleMenuTap(int index) {
    final item = _menuItems[index];

    setState(() {
      _selectedIndex = index;
    });

    // Home is handled separately.
    if (item.route == null) {
      Navigator.pushReplacementNamed(
        context,
        '/dashboard',
      );
      return;
    }

    // Already on Reports.
    if (item.route == '/reports') {
      return;
    }

    Navigator.pushNamed(
      context,
      item.route!,
    );
  }

  void _logout() {
    Navigator.pushNamed(
      context,
      '/logout',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ==================================================
            // HOSPITAL BACKGROUND
            // ==================================================

            Image.asset(
              'assets/images/hospital.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              errorBuilder: (
                context,
                error,
                stackTrace,
              ) {
                return Container(
                  color: const Color(0xFFEAF3F9),
                  child: const Center(
                    child: Text(
                      'Hospital background image not found',
                      style: TextStyle(
                        color: Color(0xFF31556D),
                        fontSize: 14,
                      ),
                    ),
                  ),
                );
              },
            ),

            // ==================================================
            // LIGHT OVERLAY
            // Same style as login.dart
            // ==================================================

            Container(
              color: const Color(0x18002545),
            ),

            // ==================================================
            // APPLICATION CONTENT
            // ==================================================

            Row(
              children: [
                _ReportsSidebar(
                  selectedIndex: _selectedIndex,
                  menuItems: _menuItems,
                  onMenuTap: _handleMenuTap,
                  onLogout: _logout,
                ),

                Expanded(
                  child: _ReportsBody(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  const _MenuItem({
    required this.title,
    required this.icon,
    required this.route,
  });

  final String title;
  final IconData icon;
  final String? route;
}

// ============================================================
// SIDEBAR
// ============================================================

class _ReportsSidebar extends StatelessWidget {
  const _ReportsSidebar({
    required this.selectedIndex,
    required this.menuItems,
    required this.onMenuTap,
    required this.onLogout,
  });

  final int selectedIndex;
  final List<_MenuItem> menuItems;
  final ValueChanged<int> onMenuTap;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      decoration: const BoxDecoration(
        color: Color(0xFF062E58),
      ),
      child: Column(
        children: [
          const SizedBox(height: 9),

          // ----------------------------------------------------
          // SYSTEM LOGO
          // ----------------------------------------------------

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          // ----------------------------------------------------
          // NAVIGATION
          // ----------------------------------------------------

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected: selectedIndex == index,
                    onTap: () => onMenuTap(index),
                  ),
                );
              },
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          // ----------------------------------------------------
          // LOGOUT
          // ----------------------------------------------------

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: onLogout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() => _SidebarButtonState();
}

class _SidebarButtonState extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final highlighted =
        widget.selected || _hovering;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,
          constraints: const BoxConstraints(
            minHeight: 42,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: widget.selected
                ? const Color(0xFF0879E8)
                : highlighted
                    ? const Color(0xFF0A416E)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.visible,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// REPORTS BODY
// ============================================================

class _ReportsBody extends StatefulWidget {
  const _ReportsBody();

  @override
  State<_ReportsBody> createState() => _ReportsBodyState();
}

class _ReportsBodyState extends State<_ReportsBody> {
  String _period = 'Last 7 Days';
  String _ward = 'All Wards';

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            9,
            7,
            9,
            8,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: (constraints.maxHeight - 15)
                  .clamp(
                    0.0,
                    double.infinity,
                  ),
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.stretch,
              children: [
                // =================================================
                // TOP BAR
                // =================================================

                _ReportsTopBar(
                  period: _period,
                  ward: _ward,
                  onPeriodChanged: (value) {
                    setState(() {
                      _period = value;
                    });
                  },
                  onWardChanged: (value) {
                    setState(() {
                      _ward = value;
                    });
                  },
                  onGenerate: () {
                    ScaffoldMessenger.of(context)
                        .showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Report generated successfully.',
                          style: TextStyle(
                            fontSize: 14,
                          ),
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 8),

                // =================================================
                // MAIN REPORT CHARTS
                // =================================================

                LayoutBuilder(
                  builder: (
                    context,
                    chartConstraints,
                  ) {
                    if (chartConstraints.maxWidth >= 750) {
                      return const SizedBox(
                        height: 270,
                        child: Row(
                          crossAxisAlignment:
                              CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: _AlertsByTypeCard(),
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: _AlertsTrendCard(),
                            ),
                          ],
                        ),
                      );
                    }

                    return const Column(
                      children: [
                        SizedBox(
                          height: 270,
                          child: _AlertsByTypeCard(),
                        ),
                        SizedBox(height: 10),
                        SizedBox(
                          height: 270,
                          child: _AlertsTrendCard(),
                        ),
                      ],
                    );
                  },
                ),

                const SizedBox(height: 8),

                // =================================================
                // REPORT STATISTICS
                // =================================================

                const _ReportStatistics(),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// TOP BAR
// ============================================================

class _ReportsTopBar extends StatelessWidget {
  const _ReportsTopBar({
    required this.period,
    required this.ward,
    required this.onPeriodChanged,
    required this.onWardChanged,
    required this.onGenerate,
  });

  final String period;
  final String ward;
  final ValueChanged<String> onPeriodChanged;
  final ValueChanged<String> onWardChanged;
  final VoidCallback onGenerate;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'Reports',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Color(0xFF174C73),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),

          // ----------------------------------------------------
          // PERIOD
          // ----------------------------------------------------

          _ReportDropdown(
            value: period,
            width: 130,
            items: const [
              'Last 7 Days',
              'Last 30 Days',
              'Last 90 Days',
              'This Year',
            ],
            onChanged: onPeriodChanged,
          ),

          const SizedBox(width: 8),

          // ----------------------------------------------------
          // WARD
          // ----------------------------------------------------

          _ReportDropdown(
            value: ward,
            width: 130,
            items: const [
              'All Wards',
              'Medical',
              'Surgical',
              'General',
              'Isolation',
            ],
            onChanged: onWardChanged,
          ),

          const SizedBox(width: 8),

          // ----------------------------------------------------
          // GENERATE REPORT
          // ----------------------------------------------------

          GestureDetector(
            onTap: onGenerate,
            child: Container(
              height: 32,
              padding: const EdgeInsets.symmetric(
                horizontal: 15,
              ),
              decoration: BoxDecoration(
                color: const Color(0xFF0879E8),
                borderRadius:
                    BorderRadius.circular(5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x18000000),
                    blurRadius: 3,
                    offset: Offset(0, 1),
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: const Text(
                'Generate Report',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// DROPDOWN
// ============================================================

class _ReportDropdown extends StatelessWidget {
  const _ReportDropdown({
    required this.value,
    required this.items,
    required this.onChanged,
    required this.width,
  });

  final String value;
  final List<String> items;
  final ValueChanged<String> onChanged;
  final double width;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 32,
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            size: 18,
            color: Color(0xFF59788D),
          ),
          style: const TextStyle(
            color: Color(0xFF41677E),
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
          items: items.map(
            (item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Text(
                  item,
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14,
                  ),
                ),
              );
            },
          ).toList(),
          onChanged: (value) {
            if (value != null) {
              onChanged(value);
            }
          },
        ),
      ),
    );
  }
}

// ============================================================
// ALERTS BY TYPE
// ============================================================

class _AlertsByTypeCard extends StatelessWidget {
  const _AlertsByTypeCard();

  @override
  Widget build(BuildContext context) {
    return _ReportPanel(
      title: 'Alerts by Type',
      child: Row(
        children: [
          Expanded(
            flex: 5,
            child: Center(
              child: SizedBox(
                width: 165,
                height: 165,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CustomPaint(
                      size: const Size(
                        165,
                        165,
                      ),
                      painter:
                          _DonutChartPainter(),
                    ),

                    const Column(
                      mainAxisSize:
                          MainAxisSize.min,
                      children: [
                        Text(
                          '24',
                          style: TextStyle(
                            color:
                                Color(0xFF174C73),
                            fontSize: 14,
                            fontWeight:
                                FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Total Alerts',
                          style: TextStyle(
                            color:
                                Color(0xFF59788D),
                            fontSize: 14,
                            fontWeight:
                                FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          Expanded(
            flex: 5,
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: const [
                _LegendItem(
                  label: 'Emergency',
                  value: '42% (10)',
                  marker: Color(0xFFE3263D),
                ),
                SizedBox(height: 13),
                _LegendItem(
                  label: 'Critical',
                  value: '21% (5)',
                  marker: Color(0xFFF18A16),
                ),
                SizedBox(height: 13),
                _LegendItem(
                  label: 'Assistance',
                  value: '21% (5)',
                  marker: Color(0xFFF5B51B),
                ),
                SizedBox(height: 13),
                _LegendItem(
                  label: 'Info',
                  value: '16% (4)',
                  marker: Color(0xFF0879E8),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// LEGEND ITEM
// ============================================================

class _LegendItem extends StatelessWidget {
  const _LegendItem({
    required this.label,
    required this.value,
    required this.marker,
  });

  final String label;
  final String value;
  final Color marker;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            color: marker,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Color(0xFF42677D),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Color(0xFF59788D),
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

// ============================================================
// DONUT CHART
// ============================================================

class _DonutChartPainter
    extends CustomPainter {
  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final center = Offset(
      size.width / 2,
      size.height / 2,
    );

    final radius =
        math.min(
              size.width,
              size.height,
            ) /
            2 -
        10;

    const strokeWidth = 22.0;

    const values = [
      42.0,
      21.0,
      21.0,
      16.0,
    ];

    const colors = [
      Color(0xFFE3263D),
      Color(0xFFF18A16),
      Color(0xFFF5B51B),
      Color(0xFF0879E8),
    ];

    double startAngle =
        -math.pi / 2;

    for (
      int i = 0;
      i < values.length;
      i++
    ) {
      final sweepAngle =
          values[i] /
              100 *
              math.pi *
              2;

      final paint = Paint()
        ..color = colors[i]
        ..style =
            PaintingStyle.stroke
        ..strokeWidth =
            strokeWidth
        ..strokeCap =
            StrokeCap.butt;

      canvas.drawArc(
        Rect.fromCircle(
          center: center,
          radius: radius,
        ),
        startAngle,
        sweepAngle,
        false,
        paint,
      );

      startAngle += sweepAngle;
    }
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}

// ============================================================
// ALERTS TREND
// ============================================================

class _AlertsTrendCard
    extends StatelessWidget {
  const _AlertsTrendCard();

  @override
  Widget build(BuildContext context) {
    return _ReportPanel(
      title: 'Alerts Trend',
      child: Padding(
        padding:
            const EdgeInsets.fromLTRB(
          8,
          8,
          10,
          8,
        ),
        child: Column(
          children: [
            Expanded(
              child: CustomPaint(
                painter:
                    _TrendChartPainter(),
                child:
                    const SizedBox.expand(),
              ),
            ),

            const SizedBox(height: 4),

            const Row(
              mainAxisAlignment:
                  MainAxisAlignment
                      .spaceAround,
              children: [
                Text(
                  'Jun 8',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Jun 9',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Jun 10',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Jun 11',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Jun 12',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Jun 13',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Jun 14',
                  style: TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// TREND CHART PAINTER
// ============================================================

class _TrendChartPainter
    extends CustomPainter {
  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    const left = 27.0;
    const top = 8.0;
    const right = 5.0;
    const bottom = 8.0;

    final chartWidth =
        size.width -
        left -
        right;

    final chartHeight =
        size.height -
        top -
        bottom;

    final gridPaint = Paint()
      ..color =
          const Color(0xFFDCECF6)
      ..strokeWidth = 1;

    // --------------------------------------------------------
    // HORIZONTAL GRID LINES
    // --------------------------------------------------------

    for (
      int i = 0;
      i <= 4;
      i++
    ) {
      final y =
          top +
          chartHeight *
              i /
              4;

      canvas.drawLine(
        Offset(left, y),
        Offset(
          size.width - right,
          y,
        ),
        gridPaint,
      );
    }

    // --------------------------------------------------------
    // VERTICAL AXIS
    // --------------------------------------------------------

    canvas.drawLine(
      Offset(left, top),
      Offset(
        left,
        top + chartHeight,
      ),
      gridPaint,
    );

    // --------------------------------------------------------
    // Y-AXIS LABELS
    // --------------------------------------------------------

    const yLabels = [
      '20',
      '15',
      '10',
      '5',
      '0',
    ];

    for (
      int i = 0;
      i < yLabels.length;
      i++
    ) {
      final y =
          top +
          chartHeight *
              i /
              4;

      final textPainter =
          TextPainter(
        text: TextSpan(
          text: yLabels[i],
          style:
              const TextStyle(
            color:
                Color(0xFF59788D),
            fontSize: 14,
          ),
        ),
        textDirection:
            TextDirection.ltr,
      );

      textPainter.layout();

      textPainter.paint(
        canvas,
        Offset(
          left -
              textPainter.width -
              6,
          y -
              textPainter.height /
                  2,
        ),
      );
    }

    // --------------------------------------------------------
    // DATA
    // --------------------------------------------------------

    const data = [
      5.0,
      8.0,
      6.0,
      10.0,
      10.0,
      11.0,
      12.0,
    ];

    final points =
        <Offset>[];

    for (
      int i = 0;
      i < data.length;
      i++
    ) {
      final x =
          left +
          chartWidth *
              i /
              (data.length - 1);

      final y =
          top +
          chartHeight *
              (1 -
                  data[i] /
                      20);

      points.add(
        Offset(x, y),
      );
    }

    // --------------------------------------------------------
    // LINE
    // --------------------------------------------------------

    final linePaint = Paint()
      ..color =
          const Color(0xFF0879E8)
      ..style =
          PaintingStyle.stroke
      ..strokeWidth = 2;

    final path = Path();

    for (
      int i = 0;
      i < points.length;
      i++
    ) {
      if (i == 0) {
        path.moveTo(
          points[i].dx,
          points[i].dy,
        );
      } else {
        path.lineTo(
          points[i].dx,
          points[i].dy,
        );
      }
    }

    canvas.drawPath(
      path,
      linePaint,
    );

    // --------------------------------------------------------
    // POINTS
    // --------------------------------------------------------

    final pointPaint = Paint()
      ..color =
          const Color(0xFF0879E8)
      ..style =
          PaintingStyle.fill;

    for (final point in points) {
      canvas.drawCircle(
        point,
        3,
        pointPaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}

// ============================================================
// REPORT STATISTICS
// ============================================================

class _ReportStatistics
    extends StatelessWidget {
  const _ReportStatistics();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        if (constraints.maxWidth <
            700) {
          return const Column(
            children: [
              _StatisticCard(
                icon:
                    Icons.timer_outlined,
                title:
                    'Avg. Response Time',
                value: '2.3 min',
                iconColor:
                    Color(0xFF10A66B),
              ),
              SizedBox(height: 8),
              _StatisticCard(
                icon: Icons
                    .check_circle_outline_rounded,
                title: 'Resolved',
                value: '20 (83%)',
                iconColor:
                    Color(0xFF0879E8),
              ),
              SizedBox(height: 8),
              _StatisticCard(
                icon: Icons
                    .pending_actions_rounded,
                title: 'Unresolved',
                value: '4 (17%)',
                iconColor:
                    Color(0xFFE3263D),
              ),
              SizedBox(height: 8),
              _StatisticCard(
                icon: Icons
                    .devices_other_outlined,
                title: 'Device Failures',
                value: '2',
                iconColor:
                    Color(0xFF0879E8),
              ),
            ],
          );
        }

        return const Row(
          children: [
            Expanded(
              child: _StatisticCard(
                icon:
                    Icons.timer_outlined,
                title:
                    'Avg. Response Time',
                value: '2.3 min',
                iconColor:
                    Color(0xFF10A66B),
              ),
            ),
            SizedBox(width: 9),
            Expanded(
              child: _StatisticCard(
                icon: Icons
                    .check_circle_outline_rounded,
                title: 'Resolved',
                value: '20 (83%)',
                iconColor:
                    Color(0xFF0879E8),
              ),
            ),
            SizedBox(width: 9),
            Expanded(
              child: _StatisticCard(
                icon: Icons
                    .pending_actions_rounded,
                title: 'Unresolved',
                value: '4 (17%)',
                iconColor:
                    Color(0xFFE3263D),
              ),
            ),
            SizedBox(width: 9),
            Expanded(
              child: _StatisticCard(
                icon: Icons
                    .devices_other_outlined,
                title: 'Device Failures',
                value: '2',
                iconColor:
                    Color(0xFF0879E8),
              ),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// STATISTIC CARD
// ============================================================

class _StatisticCard
    extends StatelessWidget {
  const _StatisticCard({
    required this.icon,
    required this.title,
    required this.value,
    required this.iconColor,
  });

  final IconData icon;
  final String title;
  final String value;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 66,
      padding:
          const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(5),
        border: Border.all(
          color:
              const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color:
                Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 27,
            height: 27,
            decoration: BoxDecoration(
              color:
                  iconColor.withOpacity(
                0.10,
              ),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Icon(
              icon,
              color: iconColor,
              size: 17,
            ),
          ),

          const SizedBox(width: 9),

          Expanded(
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style: const TextStyle(
                    color:
                        Color(0xFF59788D),
                    fontSize: 14,
                    height: 1.0,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  value,
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style: const TextStyle(
                    color:
                        Color(0xFF174C73),
                    fontSize: 14,
                    height: 1.0,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GENERIC REPORT PANEL
// ============================================================

class _ReportPanel
    extends StatelessWidget {
  const _ReportPanel({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(
          0.96,
        ),
        borderRadius:
            BorderRadius.circular(5),
        border: Border.all(
          color:
              const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color:
                Color(0x300B3D64),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      padding:
          const EdgeInsets.fromLTRB(
        8,
        7,
        8,
        7,
      ),
      child: Column(
        children: [
          SizedBox(
            height: 28,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow:
                        TextOverflow.ellipsis,
                    style:
                        const TextStyle(
                      color:
                          Color(0xFF214B69),
                      fontSize: 14,
                      height: 1.0,
                      fontWeight:
                          FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 2),

          Expanded(
            child: child,
          ),
        ],
      ),
    );
  }
}