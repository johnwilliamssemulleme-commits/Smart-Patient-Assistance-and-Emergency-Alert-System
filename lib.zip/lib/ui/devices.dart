import 'package:flutter/material.dart';

// ============================================================
// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
// devices.dart
//
// DEVICE MANAGEMENT SCREEN
//
// DEVICE FLOW:
//
// 1. Receiver detects device.
// 2. Device appears in Detected Devices.
// 3. Administrator taps Assign.
// 4. Assignment interface opens INSIDE this screen.
// 5. Administrator selects:
//      - Ward Type
//      - Ward ID
//      - Bed ID
//      - Device
// 6. Administrator presses the REAL "Assign Device" button.
// 7. Device becomes Assigned.
// 8. Device appears with its assignment in Detected Devices.
//
// IMPORTANT:
//
// - Device Assignments is NOT a separate route.
// - Both interfaces are tabs inside DevicesScreen.
// - NO PATIENT FIELD IS USED.
// - "Select Patient" is replaced by "Select Device".
// ============================================================

class DevicesScreen extends StatefulWidget {
  const DevicesScreen({super.key});

  @override
  State<DevicesScreen> createState() => _DevicesScreenState();
}

class _DevicesScreenState extends State<DevicesScreen> {
  // 0 = Detected Devices
  // 1 = Device Assignments
  int _selectedTab = 0;

  Device? _selectedDevice;

  String? _wardType;
  String? _wardId;
  String? _bedId;

  // ============================================================
  // SAMPLE DEVICE DATA
  // ============================================================

  final List<Device> _devices = [
    Device(
      deviceId: 'D-014',
      signal: 92,
      battery: 87,
      status: 'Connected',
      wardType: '',
      wardId: '',
      bedId: '',
      occupancy: DeviceOccupancy.free,
    ),
    Device(
      deviceId: 'D-006',
      signal: 88,
      battery: 81,
      status: 'Connected',
      wardType: 'Medical',
      wardId: 'A-01',
      bedId: '03',
      occupancy: DeviceOccupancy.assigned,
    ),
    Device(
      deviceId: 'D-012',
      signal: 76,
      battery: 72,
      status: 'Connected',
      wardType: 'Surgical',
      wardId: 'B-02',
      bedId: '07',
      occupancy: DeviceOccupancy.assigned,
    ),
    Device(
      deviceId: 'D-015',
      signal: 65,
      battery: 61,
      status: 'Connected',
      wardType: '',
      wardId: '',
      bedId: '',
      occupancy: DeviceOccupancy.free,
    ),
    Device(
      deviceId: 'D-009',
      signal: 81,
      battery: 90,
      status: 'Connected',
      wardType: '',
      wardId: '',
      bedId: '',
      occupancy: DeviceOccupancy.free,
    ),
  ];

  // ============================================================
  // TEMPORARY WARD DATA
  // ============================================================

  final List<String> _wardTypes = const [
    'General',
    'Medical',
    'Surgical',
    'Emergency',
    'Isolation',
    'Maternity',
    'Pediatric',
    'ICU',
  ];

  final List<String> _wardIds = const [
    'A-01',
    'B-02',
    'B-03',
    'C-01',
    'D-01',
  ];

  final List<String> _bedIds = const [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
  ];

  // ============================================================
  // AVAILABLE DEVICES
  // ============================================================

  List<Device> get _availableDevices {
    return _devices
        .where(
          (device) =>
              device.occupancy == DeviceOccupancy.free,
        )
        .toList();
  }

  // ============================================================
  // ASSIGNED DEVICES
  // ============================================================

  List<Device> get _assignedDevices {
    return _devices
        .where(
          (device) =>
              device.occupancy == DeviceOccupancy.assigned,
        )
        .toList();
  }

  // ============================================================
  // ASSIGNMENT VALIDATION
  // ============================================================

  bool get _canAssign {
    return _selectedDevice != null &&
        _wardType != null &&
        _wardId != null &&
        _bedId != null;
  }

  // ============================================================
  // OPEN ASSIGNMENT
  //
  // NO NEW WINDOW.
  // NO Navigator.push().
  // ============================================================

  void _openDeviceAssignment(Device device) {
    if (device.occupancy != DeviceOccupancy.free) {
      return;
    }

    setState(() {
      _selectedDevice = device;
      _wardType = null;
      _wardId = null;
      _bedId = null;
      _selectedTab = 1;
    });
  }

  // ============================================================
  // SELECT DEVICE
  // ============================================================

  void _selectDevice(Device device) {
    if (device.occupancy != DeviceOccupancy.free) {
      return;
    }

    setState(() {
      _selectedDevice = device;
    });
  }

  // ============================================================
  // REAL ASSIGN DEVICE BUTTON ACTION
  //
  // This is the actual assignment operation.
  // ============================================================

  void _assignDevice() {
    if (!_canAssign) {
      return;
    }

    final Device device = _selectedDevice!;

    // ----------------------------------------------------------
    // FUTURE BACKEND CONNECTION POINT
    //
    // Send:
    // device.deviceId
    // _wardType
    // _wardId
    // _bedId
    // ----------------------------------------------------------

    setState(() {
      device.wardType = _wardType!;
      device.wardId = _wardId!;
      device.bedId = _bedId!;
      device.occupancy = DeviceOccupancy.assigned;

      _selectedDevice = null;
      _wardType = null;
      _wardId = null;
      _bedId = null;

      // Return to Detected Devices after successful assignment.
      _selectedTab = 0;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(
          '${device.deviceId} assigned successfully.',
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ============================================================
  // UPDATE ASSIGNED DEVICE
  // ============================================================

  Future<void> _openUpdateDialog(Device device) async {
    final DeviceAssignment? result =
        await showDialog<DeviceAssignment>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return DeviceUpdateDialog(
          device: device,
          wardTypes: _wardTypes,
          wardIds: _wardIds,
          bedIds: _bedIds,
        );
      },
    );

    if (!mounted || result == null) {
      return;
    }

    setState(() {
      device.wardType = result.wardType;
      device.wardId = result.wardId;
      device.bedId = result.bedId;
      device.occupancy = DeviceOccupancy.assigned;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(
          '${device.deviceId} assignment updated successfully.',
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ============================================================
  // DEVICE ACTION
  // ============================================================

  void _handleDeviceAction(Device device) {
    if (device.occupancy == DeviceOccupancy.free) {
      _openDeviceAssignment(device);
    } else {
      _openUpdateDialog(device);
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4FAFE),
      body: SafeArea(
        child: Row(
          children: [
            _buildSidebar(),
            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SIDEBAR
  // ============================================================

  Widget _buildSidebar() {
    return Container(
      width: 170,
      color: const Color(0xFF062E58),
      child: Column(
        children: [
          const SizedBox(height: 9),

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              children: [
                _sidebarButton(
                  title: 'Home',
                  icon: Icons.home_outlined,
                  route: '/dashboard',
                ),

                _sidebarButton(
                  title: 'Alerts',
                  icon: Icons.notifications_none_rounded,
                  route: '/alerts',
                ),

                _sidebarButton(
                  title: 'Patients',
                  icon: Icons.person_outline_rounded,
                  route: '/patients',
                ),

                _sidebarButton(
                  title: 'Bed/Wards',
                  icon: Icons.bed_outlined,
                  route: '/beds-wards',
                ),

                _sidebarButton(
                  title: 'Devices',
                  icon: Icons.devices_other_outlined,
                  selected: true,
                ),

                _sidebarButton(
                  title: 'Receiver',
                  icon: Icons.sensors_outlined,
                  route: '/receiver',
                ),

                _sidebarButton(
                  title: 'Reports',
                  icon: Icons.bar_chart_rounded,
                  route: '/reports',
                ),

                _sidebarButton(
                  title: 'Logs',
                  icon: Icons.description_outlined,
                  route: '/logs',
                ),

                _sidebarButton(
                  title: 'Settings',
                  icon: Icons.settings_outlined,
                  route: '/settings',
                ),

                _sidebarButton(
                  title: 'Administration',
                  icon: Icons.admin_panel_settings_outlined,
                  route: '/administration',
                ),
              ],
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: () {
                Navigator.pushReplacementNamed(
                  context,
                  '/live-monitoring',
                );
              },
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }

  // ============================================================
  // SIDEBAR BUTTON
  // ============================================================

  Widget _sidebarButton({
    required String title,
    required IconData icon,
    String? route,
    bool selected = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 4,
      ),
      child: _SidebarButton(
        title: title,
        icon: icon,
        selected: selected,
        onTap: () {
          if (route != null) {
            Navigator.pushNamed(
              context,
              route,
            );
          }
        },
      ),
    );
  }

  // ============================================================
  // MAIN CONTENT
  // ============================================================

  Widget _buildContent() {
    return Container(
      color: const Color(0xFFF4FAFE),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(
              9,
              7,
              9,
              8,
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight:
                    constraints.maxHeight > 15
                        ? constraints.maxHeight - 15
                        : 0,
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.stretch,
                children: [
                  _buildHeader(),

                  const SizedBox(height: 6),

                  _buildTabs(),

                  const SizedBox(height: 7),

                  if (_selectedTab == 0)
                    _buildDetectedDevicesPanel()
                  else
                    _buildDeviceAssignmentsPanel(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _buildHeader() {
    return SizedBox(
      height: 32,
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'Devices',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Color(0xFF174C73),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 4,
            ),
            decoration: BoxDecoration(
              color: const Color(0xFFDDF5EA),
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.circle,
                  color: Color(0xFF10A66B),
                  size: 6,
                ),
                SizedBox(width: 4),
                Text(
                  'System Online',
                  style: TextStyle(
                    color: Color(0xFF087C50),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // TABS
  // ============================================================

  Widget _buildTabs() {
    return Container(
      height: 32,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
      ),
      padding: const EdgeInsets.all(2),
      child: Row(
        children: [
          Expanded(
            child: _tabButton(
              title: 'Detected Devices',
              icon: Icons.devices_other_outlined,
              selected: _selectedTab == 0,
              onTap: () {
                setState(() {
                  _selectedTab = 0;
                });
              },
            ),
          ),

          const SizedBox(width: 3),

          Expanded(
            child: _tabButton(
              title: 'Device Assignments',
              icon: Icons.assignment_outlined,
              selected: _selectedTab == 1,
              onTap: () {
                setState(() {
                  _selectedTab = 1;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // TAB BUTTON
  // ============================================================

  Widget _tabButton({
    required String title,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Material(
      color: selected
          ? const Color(0xFF0879E8)
          : Colors.transparent,
      borderRadius: BorderRadius.circular(4),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(4),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 14,
                color: selected
                    ? Colors.white
                    : const Color(0xFF59788D),
              ),

              const SizedBox(width: 5),

              Text(
                title,
                style: TextStyle(
                  color: selected
                      ? Colors.white
                      : const Color(0xFF59788D),
                  fontSize: 12,
                  fontWeight: selected
                      ? FontWeight.w700
                      : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // DETECTED DEVICES PANEL
  // ============================================================

  Widget _buildDetectedDevicesPanel() {
    return _buildWhitePanel(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 27,
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Detected Devices',
                    style: TextStyle(
                      color: Color(0xFF214B69),
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),

                Text(
                  '${_devices.length} devices',
                  style: const TextStyle(
                    color: Color(0xFF0879E8),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 2),

          _buildMainDeviceTable(),
        ],
      ),
    );
  }

  // ============================================================
  // MAIN DEVICE TABLE
  // ============================================================

  Widget _buildMainDeviceTable() {
    return LayoutBuilder(
      builder: (context, constraints) {
        const double minimumWidth = 1050;

        final double tableWidth =
            constraints.maxWidth < minimumWidth
                ? minimumWidth
                : constraints.maxWidth;

        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: tableWidth,
            child: Column(
              children: [
                _buildTableHeader(),

                if (_devices.isEmpty)
                  _buildEmptyRow(
                    'Waiting for detected devices',
                    'Devices detected by the receiver will appear here.',
                  )
                else
                  ..._devices.map(
                    _buildDeviceRow,
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // TABLE HEADER
  // ============================================================

  Widget _buildTableHeader() {
    return Container(
      height: 38,
      color: const Color(0xFFE8F3FA),
      child: Row(
        children: [
          _headerCell('Device', 120),
          _headerCell('Signal', 90),
          _headerCell('Battery', 95),
          _headerCell('Status', 115),
          _headerCell('Ward Type', 140),
          _headerCell('Ward ID', 90),
          _headerCell('Bed ID', 100),
          _headerCell('Occupancy', 110),
          _headerCell('Action', 105),
        ],
      ),
    );
  }

  // ============================================================
  // HEADER CELL
  // ============================================================

  Widget _headerCell(
    String title,
    double width,
  ) {
    return SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 8,
        ),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Color(0xFF59788D),
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // DEVICE ROW
  // ============================================================

  Widget _buildDeviceRow(
    Device device,
  ) {
    return Container(
      height: 46,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE4EEF4),
          ),
        ),
      ),
      child: Row(
        children: [
          _rowCell(
            width: 120,
            child: Text(
              device.deviceId,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF214B69),
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),

          _rowCell(
            width: 90,
            child: _signalWidget(
              device.signal,
            ),
          ),

          _rowCell(
            width: 95,
            child: _batteryWidget(
              device.battery,
            ),
          ),

          _rowCell(
            width: 115,
            child: _statusBadge(
              device.status,
            ),
          ),

          _rowCell(
            width: 140,
            child: _locationText(
              device.wardType,
            ),
          ),

          _rowCell(
            width: 90,
            child: _locationText(
              device.wardId,
            ),
          ),

          _rowCell(
            width: 100,
            child: _locationText(
              device.bedId,
            ),
          ),

          _rowCell(
            width: 110,
            child: _occupancyBadge(
              device.occupancy,
            ),
          ),

          _rowCell(
            width: 105,
            child: _actionButton(
              device,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ROW CELL
  // ============================================================

  Widget _rowCell({
    required double width,
    required Widget child,
  }) {
    return SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 8,
        ),
        child: child,
      ),
    );
  }

  // ============================================================
  // EMPTY ROW
  // ============================================================

  Widget _buildEmptyRow(
    String title,
    String subtitle,
  ) {
    return Container(
      height: 140,
      width: double.infinity,
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE4EEF4),
          ),
        ),
      ),
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.devices_other_outlined,
            color: Color(0xFF91A9B9),
            size: 30,
          ),

          const SizedBox(height: 7),

          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF59788D),
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFF91A9B9),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DEVICE ASSIGNMENTS
  // ============================================================

  Widget _buildDeviceAssignmentsPanel() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bool compact =
            constraints.maxWidth < 850;

        if (compact) {
          return Column(
            crossAxisAlignment:
                CrossAxisAlignment.stretch,
            children: [
              _buildAssignmentDevicesCard(),

              const SizedBox(height: 8),

              _buildAssignmentDetailsCard(),
            ],
          );
        }

        return Row(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 48,
              child:
                  _buildAssignmentDevicesCard(),
            ),

            const SizedBox(width: 8),

            Expanded(
              flex: 52,
              child:
                  _buildAssignmentDetailsCard(),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // LEFT: DETECTED DEVICES
  // ============================================================

  Widget _buildAssignmentDevicesCard() {
    return _buildWhitePanel(
      padding: const EdgeInsets.fromLTRB(
        8,
        7,
        8,
        7,
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Detected Devices',
                  style: TextStyle(
                    color: Color(0xFF214B69),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),

              Text(
                '${_availableDevices.length} available',
                style: const TextStyle(
                  color: Color(0xFF0879E8),
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),

          const SizedBox(height: 6),

          if (_availableDevices.isEmpty)
            Container(
              height: 140,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFFAFCFE),
                border: Border.all(
                  color: const Color(0xFFE4EEF4),
                ),
              ),
              child: const Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.devices_other_outlined,
                    color: Color(0xFF91A9B9),
                    size: 28,
                  ),
                  SizedBox(height: 7),
                  Text(
                    'No free devices available.',
                    style: TextStyle(
                      color: Color(0xFF59788D),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            )
          else
            _buildAssignmentDeviceList(),
        ],
      ),
    );
  }

  // ============================================================
  // ASSIGNMENT DEVICE LIST
  // ============================================================

  Widget _buildAssignmentDeviceList() {
    return Column(
      children: [
        Container(
          height: 32,
          color: const Color(0xFFE8F3FA),
          child: Row(
            children: [
              _assignmentHeaderCell(
                'Device ID',
                38,
              ),
              _assignmentHeaderCell(
                'Signal',
                27,
              ),
              _assignmentHeaderCell(
                'Status',
                35,
              ),
            ],
          ),
        ),

        ..._availableDevices.map(
          (device) {
            final bool selected =
                _selectedDevice == device;

            return Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () {
                  _selectDevice(device);
                },
                child: Container(
                  height: 39,
                  decoration: BoxDecoration(
                    color: selected
                        ? const Color(0xFFEAF4FF)
                        : Colors.white,
                    border: const Border(
                      bottom: BorderSide(
                        color: Color(0xFFE4EEF4),
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 38,
                        child: Padding(
                          padding:
                              const EdgeInsets.symmetric(
                            horizontal: 9,
                          ),
                          child: Text(
                            device.deviceId,
                            style: TextStyle(
                              color:
                                  const Color(
                                0xFF214B69,
                              ),
                              fontSize: 12,
                              fontWeight: selected
                                  ? FontWeight.w800
                                  : FontWeight.w700,
                            ),
                          ),
                        ),
                      ),

                      Expanded(
                        flex: 27,
                        child: Padding(
                          padding:
                              const EdgeInsets.symmetric(
                            horizontal: 5,
                          ),
                          child: _signalWidget(
                            device.signal,
                            compact: true,
                          ),
                        ),
                      ),

                      Expanded(
                        flex: 35,
                        child: Padding(
                          padding:
                              const EdgeInsets.symmetric(
                            horizontal: 5,
                          ),
                          child: _statusBadge(
                            device.status,
                            compact: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  // ============================================================
  // ASSIGNMENT HEADER CELL
  // ============================================================

  Widget _assignmentHeaderCell(
    String title,
    int flexValue,
  ) {
    return Expanded(
      flex: flexValue,
      child: Padding(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 9,
        ),
        child: Text(
          title,
          style: const TextStyle(
            color: Color(0xFF59788D),
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  // ============================================================
  // RIGHT: ASSIGNMENT DETAILS
  // ============================================================

  Widget _buildAssignmentDetailsCard() {
    return _buildWhitePanel(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Assignment Details',
            style: TextStyle(
              color: Color(0xFF214B69),
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),

          const SizedBox(height: 8),

          _buildField(
            label: 'Ward Type',
            value: _wardType,
            hint: 'Select Ward Type',
            icon: Icons.local_hospital_outlined,
            items: _wardTypes,
            onChanged: (value) {
              setState(() {
                _wardType = value;
              });
            },
          ),

          const SizedBox(height: 7),

          _buildField(
            label: 'Ward ID',
            value: _wardId,
            hint: 'Select Ward ID',
            icon: Icons.domain_outlined,
            items: _wardIds,
            onChanged: (value) {
              setState(() {
                _wardId = value;
              });
            },
          ),

          const SizedBox(height: 7),

          _buildField(
            label: 'Bed',
            value: _bedId,
            hint: 'Select Bed',
            icon: Icons.bed_outlined,
            items: _bedIds,
            onChanged: (value) {
              setState(() {
                _bedId = value;
              });
            },
          ),

          const SizedBox(height: 7),

          // ====================================================
          // REAL SELECT DEVICE FIELD
          // ====================================================

          _buildSelectedDeviceField(),

          const SizedBox(height: 12),

          // ====================================================
          // REAL ASSIGN DEVICE BUTTON
          //
          // THIS IS AN ACTUAL FUNCTIONAL BUTTON.
          // ====================================================

          SizedBox(
            height: 36,
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _canAssign
                  ? _assignDevice
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF0879E8),
                foregroundColor: Colors.white,

                // Disabled state is visually different,
                // but this is still a real ElevatedButton.
                disabledBackgroundColor:
                    const Color(0xFFB8CBD8),
                disabledForegroundColor:
                    Colors.white,

                elevation: 0,

                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 10,
                ),

                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(4),
                ),
              ),
              child: const Text(
                'Assign Device',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),

          const SizedBox(height: 5),

          // Small instruction showing why the button
          // may currently be disabled.
          if (!_canAssign)
            const Text(
              'Select a device, ward type, ward ID and bed to assign.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF91A9B9),
                fontSize: 11,
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // FIELD
  // ============================================================

  Widget _buildField({
    required String label,
    required String? value,
    required String hint,
    required IconData icon,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.stretch,
      children: [
        _fieldLabel(label),

        const SizedBox(height: 3),

        _dropdown(
          value: value,
          hint: hint,
          icon: icon,
          items: items,
          onChanged: onChanged,
        ),
      ],
    );
  }

  // ============================================================
  // SELECT DEVICE
  // ============================================================

  Widget _buildSelectedDeviceField() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.stretch,
      children: [
        _fieldLabel('Select Device'),

        const SizedBox(height: 3),

        Container(
          height: 35,
          decoration: BoxDecoration(
            color: const Color(0xFFFAFCFE),
            borderRadius:
                BorderRadius.circular(4),
            border: Border.all(
              color: const Color(0xFFBCD2E1),
            ),
          ),
          padding:
              const EdgeInsets.symmetric(
            horizontal: 8,
          ),
          child:
              DropdownButtonHideUnderline(
            child:
                DropdownButton<Device>(
              value: _selectedDevice,
              isExpanded: true,

              icon: const Icon(
                Icons.keyboard_arrow_down_rounded,
                color: Color(0xFF59788D),
                size: 18,
              ),

              hint: const Row(
                children: [
                  Icon(
                    Icons.devices_other_outlined,
                    color: Color(0xFF7893A4),
                    size: 16,
                  ),
                  SizedBox(width: 6),
                  Text(
                    'Select Device',
                    style: TextStyle(
                      color: Color(0xFF8298A7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),

              items: _availableDevices.map(
                (device) {
                  return DropdownMenuItem<Device>(
                    value: device,
                    child: Row(
                      children: [
                        const Icon(
                          Icons.devices_other_outlined,
                          color: Color(0xFF0879E8),
                          size: 16,
                        ),

                        const SizedBox(width: 6),

                        Expanded(
                          child: Text(
                            device.deviceId,
                            style:
                                const TextStyle(
                              color:
                                  Color(0xFF294F68),
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ).toList(),

              onChanged: (device) {
                if (device == null) {
                  return;
                }

                _selectDevice(device);
              },
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // FIELD LABEL
  // ============================================================

  Widget _fieldLabel(
    String title,
  ) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF174C73),
        fontSize: 12,
        fontWeight: FontWeight.w700,
      ),
    );
  }

  // ============================================================
  // DROPDOWN
  // ============================================================

  Widget _dropdown({
    required String? value,
    required String hint,
    required IconData icon,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      height: 35,
      decoration: BoxDecoration(
        color: const Color(0xFFFAFCFE),
        borderRadius:
            BorderRadius.circular(4),
        border: Border.all(
          color: const Color(0xFFBCD2E1),
        ),
      ),
      padding:
          const EdgeInsets.symmetric(
        horizontal: 8,
      ),
      child:
          DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,

          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Color(0xFF59788D),
            size: 18,
          ),

          hint: Row(
            children: [
              Icon(
                icon,
                color:
                    const Color(0xFF7893A4),
                size: 16,
              ),

              const SizedBox(width: 6),

              Text(
                hint,
                style: const TextStyle(
                  color:
                      Color(0xFF8298A7),
                  fontSize: 12,
                ),
              ),
            ],
          ),

          items: items.map(
            (item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Row(
                  children: [
                    Icon(
                      icon,
                      color:
                          const Color(0xFF0879E8),
                      size: 16,
                    ),

                    const SizedBox(
                      width: 6,
                    ),

                    Expanded(
                      child: Text(
                        item,
                        style:
                            const TextStyle(
                          color:
                              Color(0xFF294F68),
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ).toList(),

          onChanged: onChanged,
        ),
      ),
    );
  }

  // ============================================================
  // WHITE PANEL
  // ============================================================

  Widget _buildWhitePanel({
    required Widget child,
    EdgeInsets padding =
        const EdgeInsets.fromLTRB(
      8,
      7,
      8,
      7,
    ),
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      padding: padding,
      child: child,
    );
  }

  // ============================================================
  // SIGNAL
  // ============================================================

  Widget _signalWidget(
    int signal, {
    bool compact = false,
  }) {
    IconData icon;
    Color color;

    if (signal >= 70) {
      icon = Icons.wifi;
      color = const Color(0xFF10A66B);
    } else if (signal >= 40) {
      icon = Icons.wifi_2_bar;
      color = const Color(0xFFD89400);
    } else {
      icon = Icons.wifi_1_bar;
      color = const Color(0xFFE3263D);
    }

    return Row(
      mainAxisSize:
          compact
              ? MainAxisSize.min
              : MainAxisSize.max,
      children: [
        Icon(
          icon,
          size: compact ? 15 : 17,
          color: color,
        ),

        const SizedBox(width: 4),

        Text(
          '$signal%',
          style: TextStyle(
            color:
                const Color(0xFF4C6B80),
            fontSize:
                compact ? 11 : 12,
            fontWeight:
                FontWeight.w600,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // BATTERY
  // ============================================================

  Widget _batteryWidget(
    int battery,
  ) {
    Color color;

    if (battery > 40) {
      color = const Color(0xFF10A66B);
    } else if (battery > 20) {
      color = const Color(0xFFD89400);
    } else {
      color = const Color(0xFFE3263D);
    }

    return Row(
      children: [
        Icon(
          battery > 20
              ? Icons.battery_std
              : Icons.battery_alert,
          size: 17,
          color: color,
        ),

        const SizedBox(width: 4),

        Text(
          '$battery%',
          style: const TextStyle(
            color: Color(0xFF4C6B80),
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // STATUS BADGE
  // ============================================================

  Widget _statusBadge(
    String status, {
    bool compact = false,
  }) {
    final bool connected =
        status.toLowerCase() ==
            'connected';

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal:
            compact ? 5 : 6,
        vertical:
            compact ? 3 : 4,
      ),
      decoration: BoxDecoration(
        color: connected
            ? const Color(0xFFDDF5EA)
            : const Color(0xFFFFE5E8),
        borderRadius:
            BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Icon(
            Icons.circle,
            size: compact ? 5 : 6,
            color: connected
                ? const Color(0xFF10A66B)
                : const Color(0xFFE3263D),
          ),

          const SizedBox(width: 4),

          Text(
            status,
            style: TextStyle(
              color: connected
                  ? const Color(0xFF087C50)
                  : const Color(0xFFC62236),
              fontSize:
                  compact ? 10 : 11,
              fontWeight:
                  FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LOCATION TEXT
  // ============================================================

  Widget _locationText(
    String value,
  ) {
    final bool hasValue =
        value.trim().isNotEmpty;

    return Text(
      hasValue ? value : '—',
      maxLines: 1,
      overflow:
          TextOverflow.ellipsis,
      style: TextStyle(
        color: hasValue
            ? const Color(0xFF39718F)
            : const Color(0xFF9AAEBC),
        fontSize: 12,
        fontWeight: hasValue
            ? FontWeight.w600
            : FontWeight.w400,
      ),
    );
  }

  // ============================================================
  // OCCUPANCY
  // ============================================================

  Widget _occupancyBadge(
    DeviceOccupancy occupancy,
  ) {
    final bool assigned =
        occupancy ==
            DeviceOccupancy.assigned;

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 6,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: assigned
            ? const Color(0xFFE4EFFA)
            : const Color(0xFFDDF5EA),
        borderRadius:
            BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Icon(
            Icons.circle,
            size: 5,
            color: assigned
                ? const Color(0xFF0879E8)
                : const Color(0xFF10A66B),
          ),

          const SizedBox(width: 4),

          Text(
            assigned
                ? 'Assigned'
                : 'Free',
            style: TextStyle(
              color: assigned
                  ? const Color(0xFF0879E8)
                  : const Color(0xFF087C50),
              fontSize: 11,
              fontWeight:
                  FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // REAL ASSIGN / UPDATE BUTTON
  //
  // FREE DEVICE:
  //     Assign
  //
  // ASSIGNED DEVICE:
  //     Update
  // ============================================================

  Widget _actionButton(
    Device device,
  ) {
    final bool assigned =
        device.occupancy ==
            DeviceOccupancy.assigned;

    return SizedBox(
      height: 27,
      child: ElevatedButton(
        onPressed: () {
          _handleDeviceAction(device);
        },
        style:
            ElevatedButton.styleFrom(
          backgroundColor:
              const Color(0xFF0879E8),
          foregroundColor:
              Colors.white,
          elevation: 0,
          padding:
              const EdgeInsets.symmetric(
            horizontal: 9,
          ),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(4),
          ),
        ),
        child: Text(
          assigned
              ? 'Update'
              : 'Assign',
          style: const TextStyle(
            fontSize: 11,
            fontWeight:
                FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton
    extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() =>
      _SidebarButtonState();
}

class _SidebarButtonState
    extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final bool highlighted =
        widget.selected ||
            _hovering;

    return MouseRegion(
      cursor:
          SystemMouseCursors.click,

      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },

      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },

      child: GestureDetector(
        onTap: widget.onTap,

        child: AnimatedContainer(
          duration:
              const Duration(
            milliseconds: 150,
          ),

          width: double.infinity,

          constraints:
              const BoxConstraints(
            minHeight: 42,
          ),

          padding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),

          decoration:
              BoxDecoration(
            color: widget.selected
                ? const Color(
                    0xFF0879E8,
                  )
                : highlighted
                    ? const Color(
                        0xFF0A416E,
                      )
                    : Colors.transparent,

            borderRadius:
                BorderRadius.circular(5),
          ),

          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),

              const SizedBox(width: 9),

              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  softWrap: false,
                  overflow:
                      TextOverflow.visible,
                  style:
                      const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// DEVICE MODEL
// ============================================================

class Device {
  Device({
    required this.deviceId,
    required this.signal,
    required this.battery,
    required this.status,
    required this.wardType,
    required this.wardId,
    required this.bedId,
    required this.occupancy,
  });

  final String deviceId;

  final int signal;

  final int battery;

  final String status;

  String wardType;

  String wardId;

  String bedId;

  DeviceOccupancy occupancy;
}

// ============================================================
// DEVICE OCCUPANCY
// ============================================================

enum DeviceOccupancy {
  free,
  assigned,
}

// ============================================================
// DEVICE ASSIGNMENT RESULT
// ============================================================

class DeviceAssignment {
  const DeviceAssignment({
    required this.wardType,
    required this.wardId,
    required this.bedId,
  });

  final String wardType;

  final String wardId;

  final String bedId;
}

// ============================================================
// UPDATE DEVICE DIALOG
//
// This dialog is ONLY for an already-assigned device.
// ============================================================

class DeviceUpdateDialog
    extends StatefulWidget {
  const DeviceUpdateDialog({
    super.key,
    required this.device,
    required this.wardTypes,
    required this.wardIds,
    required this.bedIds,
  });

  final Device device;

  final List<String> wardTypes;

  final List<String> wardIds;

  final List<String> bedIds;

  @override
  State<DeviceUpdateDialog> createState() =>
      _DeviceUpdateDialogState();
}

class _DeviceUpdateDialogState
    extends State<DeviceUpdateDialog> {
  String? _wardType;
  String? _wardId;
  String? _bedId;

  @override
  void initState() {
    super.initState();

    if (widget.wardTypes.contains(
      widget.device.wardType,
    )) {
      _wardType =
          widget.device.wardType;
    }

    if (widget.wardIds.contains(
      widget.device.wardId,
    )) {
      _wardId =
          widget.device.wardId;
    }

    if (widget.bedIds.contains(
      widget.device.bedId,
    )) {
      _bedId =
          widget.device.bedId;
    }
  }

  bool get _canUpdate {
    return _wardType != null &&
        _wardId != null &&
        _bedId != null;
  }

  void _update() {
    if (!_canUpdate) {
      return;
    }

    Navigator.of(context).pop(
      DeviceAssignment(
        wardType: _wardType!,
        wardId: _wardId!,
        bedId: _bedId!,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor:
          Colors.transparent,

      insetPadding:
          const EdgeInsets.symmetric(
        horizontal: 25,
        vertical: 20,
      ),

      child: ConstrainedBox(
        constraints:
            const BoxConstraints(
          maxWidth: 560,
        ),

        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius:
                BorderRadius.circular(6),
            border: Border.all(
              color:
                  const Color(0xFFD1E7F4),
            ),
            boxShadow: const [
              BoxShadow(
                color:
                    Color(0x30000000),
                blurRadius: 15,
                offset: Offset(0, 5),
              ),
            ],
          ),

          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              // ==================================================
              // DIALOG HEADER
              // ==================================================

              Container(
                height: 48,
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 16,
                ),
                decoration:
                    const BoxDecoration(
                  color:
                      Color(0xFF062E58),
                  borderRadius:
                      BorderRadius.only(
                    topLeft:
                        Radius.circular(6),
                    topRight:
                        Radius.circular(6),
                  ),
                ),

                child: Row(
                  children: [
                    const Icon(
                      Icons.devices_other_outlined,
                      color: Colors.white,
                      size: 21,
                    ),

                    const SizedBox(
                      width: 9,
                    ),

                    const Expanded(
                      child: Text(
                        'Update Device Assignment',
                        style:
                            TextStyle(
                          color:
                              Colors.white,
                          fontSize: 14,
                          fontWeight:
                              FontWeight.w800,
                        ),
                      ),
                    ),

                    IconButton(
                      padding:
                          EdgeInsets.zero,
                      constraints:
                          const BoxConstraints(
                        minWidth: 30,
                        minHeight: 30,
                      ),
                      onPressed: () {
                        Navigator.of(
                          context,
                        ).pop();
                      },
                      icon:
                          const Icon(
                        Icons.close,
                        color:
                            Colors.white,
                        size: 19,
                      ),
                    ),
                  ],
                ),
              ),

              // ==================================================
              // DEVICE INFORMATION
              // ==================================================

              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                color:
                    const Color(0xFFF3F8FC),
                child: Row(
                  children: [
                    const Text(
                      'Device:',
                      style:
                          TextStyle(
                        color:
                            Color(
                          0xFF59788D,
                        ),
                        fontSize: 13,
                        fontWeight:
                            FontWeight.w600,
                      ),
                    ),

                    const SizedBox(
                      width: 8,
                    ),

                    Text(
                      widget.device.deviceId,
                      style:
                          const TextStyle(
                        color:
                            Color(
                          0xFF174C73,
                        ),
                        fontSize: 13,
                        fontWeight:
                            FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),

              // ==================================================
              // FORM
              // ==================================================

              Padding(
                padding:
                    const EdgeInsets.all(
                  16,
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment
                          .stretch,
                  children: [
                    _fieldLabel(
                      'Ward Type',
                    ),

                    const SizedBox(
                      height: 5,
                    ),

                    _dropdown(
                      value: _wardType,
                      hint:
                          'Select Ward Type',
                      icon: Icons
                          .local_hospital_outlined,
                      items:
                          widget.wardTypes,
                      onChanged:
                          (value) {
                        setState(() {
                          _wardType =
                              value;
                        });
                      },
                    ),

                    const SizedBox(
                      height: 11,
                    ),

                    _fieldLabel(
                      'Ward ID',
                    ),

                    const SizedBox(
                      height: 5,
                    ),

                    _dropdown(
                      value: _wardId,
                      hint:
                          'Select Ward ID',
                      icon:
                          Icons.domain_outlined,
                      items:
                          widget.wardIds,
                      onChanged:
                          (value) {
                        setState(() {
                          _wardId =
                              value;
                        });
                      },
                    ),

                    const SizedBox(
                      height: 11,
                    ),

                    _fieldLabel(
                      'Bed ID',
                    ),

                    const SizedBox(
                      height: 5,
                    ),

                    _dropdown(
                      value: _bedId,
                      hint:
                          'Select Bed ID',
                      icon:
                          Icons.bed_outlined,
                      items:
                          widget.bedIds,
                      onChanged:
                          (value) {
                        setState(() {
                          _bedId =
                              value;
                        });
                      },
                    ),

                    const SizedBox(
                      height: 16,
                    ),

                    // ==================================================
                    // REAL UPDATE BUTTON
                    // ==================================================

                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment
                              .end,
                      children: [
                        OutlinedButton(
                          onPressed: () {
                            Navigator.of(
                              context,
                            ).pop();
                          },
                          style:
                              OutlinedButton
                                  .styleFrom(
                            foregroundColor:
                                const Color(
                              0xFF59788D,
                            ),
                            side:
                                const BorderSide(
                              color:
                                  Color(
                                0xFFBFD4E2,
                              ),
                            ),
                            minimumSize:
                                const Size(
                              90,
                              34,
                            ),
                            shape:
                                RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(
                                4,
                              ),
                            ),
                          ),
                          child:
                              const Text(
                            'Cancel',
                            style:
                                TextStyle(
                              fontSize:
                                  13,
                              fontWeight:
                                  FontWeight
                                      .w600,
                            ),
                          ),
                        ),

                        const SizedBox(
                          width: 8,
                        ),

                        ElevatedButton(
                          onPressed:
                              _canUpdate
                                  ? _update
                                  : null,
                          style:
                              ElevatedButton
                                  .styleFrom(
                            backgroundColor:
                                const Color(
                              0xFF0879E8,
                            ),
                            foregroundColor:
                                Colors.white,
                            disabledBackgroundColor:
                                const Color(
                              0xFFB8CBD8,
                            ),
                            disabledForegroundColor:
                                Colors.white,
                            elevation: 0,
                            minimumSize:
                                const Size(
                              90,
                              34,
                            ),
                            shape:
                                RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(
                                4,
                              ),
                            ),
                          ),
                          child:
                              const Text(
                            'Update',
                            style:
                                TextStyle(
                              fontSize:
                                  13,
                              fontWeight:
                                  FontWeight
                                      .w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // DIALOG FIELD LABEL
  // ============================================================

  Widget _fieldLabel(
    String title,
  ) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF174C73),
        fontSize: 13,
        fontWeight: FontWeight.w700,
      ),
    );
  }

  // ============================================================
  // DIALOG DROPDOWN
  // ============================================================

  Widget _dropdown({
    required String? value,
    required String hint,
    required IconData icon,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      height: 38,
      decoration: BoxDecoration(
        color:
            const Color(0xFFFAFCFE),
        borderRadius:
            BorderRadius.circular(4),
        border: Border.all(
          color:
              const Color(0xFFBCD2E1),
        ),
      ),
      padding:
          const EdgeInsets.symmetric(
        horizontal: 9,
      ),
      child:
          DropdownButtonHideUnderline(
        child:
            DropdownButton<String>(
          value: value,
          isExpanded: true,

          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color:
                Color(0xFF59788D),
            size: 19,
          ),

          hint: Row(
            children: [
              Icon(
                icon,
                color:
                    const Color(
                  0xFF7893A4,
                ),
                size: 17,
              ),

              const SizedBox(
                width: 7,
              ),

              Text(
                hint,
                style:
                    const TextStyle(
                  color:
                      Color(
                    0xFF8298A7,
                  ),
                  fontSize: 13,
                ),
              ),
            ],
          ),

          items: items.map(
            (item) {
              return DropdownMenuItem<
                  String>(
                value: item,
                child: Row(
                  children: [
                    Icon(
                      icon,
                      color:
                          const Color(
                        0xFF0879E8,
                      ),
                      size: 17,
                    ),

                    const SizedBox(
                      width: 7,
                    ),

                    Expanded(
                      child: Text(
                        item,
                        style:
                            const TextStyle(
                          color:
                              Color(
                            0xFF294F68,
                          ),
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ).toList(),

          onChanged: onChanged,
        ),
      ),
    );
  }
}