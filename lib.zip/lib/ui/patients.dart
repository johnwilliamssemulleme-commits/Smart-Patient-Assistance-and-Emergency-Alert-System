import 'package:flutter/material.dart';

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({super.key});

  @override
  State<PatientsScreen> createState() => _PatientsScreenState();
}

class _PatientsScreenState extends State<PatientsScreen> {
  final TextEditingController _searchController = TextEditingController();

  static const int _rowsPerPage = 10;

  int _currentPage = 1;

  bool _exportHover = false;
  bool _addPatientHover = false;

  final List<Map<String, String>> _patients = [
    {
      'id': 'P-001',
      'name': 'John M.',
      'age': '68',
      'gender': 'M',
      'ward': 'Medical',
      'wardId': 'B-02',
      'bedId': '12',
    },
    {
      'id': 'P-002',
      'name': 'Amina N.',
      'age': '72',
      'gender': 'F',
      'ward': 'Surgical',
      'wardId': 'A-01',
      'bedId': '05',
    },
    {
      'id': 'P-003',
      'name': 'Samuel O.',
      'age': '56',
      'gender': 'M',
      'ward': 'General',
      'wardId': 'C-01',
      'bedId': '08',
    },
    {
      'id': 'P-004',
      'name': 'Grace N.',
      'age': '61',
      'gender': 'F',
      'ward': 'Emergency',
      'wardId': 'B-03',
      'bedId': '03',
    },
    {
      'id': 'P-005',
      'name': 'Patrick S.',
      'age': '47',
      'gender': 'M',
      'ward': 'Medical',
      'wardId': 'B-02',
      'bedId': '11',
    },
  ];

  static const List<String> _wardIds = [
    'B-02',
    'A-01',
    'C-01',
    'B-03',
  ];

  static const List<String> _bedIds = [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
    '11',
    '12',
  ];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  void _onSearchChanged() {
    if (!mounted) return;

    setState(() {
      _currentPage = 1;
    });
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, String>> get _filteredPatients {
    final query = _searchController.text.trim().toLowerCase();

    if (query.isEmpty) {
      return List<Map<String, String>>.from(_patients);
    }

    return _patients.where((patient) {
      return patient['id']!.toLowerCase().contains(query) ||
          patient['name']!.toLowerCase().contains(query) ||
          patient['age']!.toLowerCase().contains(query) ||
          patient['gender']!.toLowerCase().contains(query) ||
          patient['ward']!.toLowerCase().contains(query) ||
          patient['wardId']!.toLowerCase().contains(query) ||
          patient['bedId']!.toLowerCase().contains(query);
    }).toList();
  }

  List<Map<String, String>> _patientsForCurrentPage(
    List<Map<String, String>> patients,
  ) {
    if (patients.isEmpty) {
      return [];
    }

    final totalPages = ((patients.length - 1) ~/ _rowsPerPage) + 1;
    final page = _currentPage.clamp(1, totalPages);

    final start = (page - 1) * _rowsPerPage;
    final end = (start + _rowsPerPage).clamp(0, patients.length);

    return patients.sublist(start, end);
  }

  void _navigate(String route) {
    Navigator.of(context).pushReplacementNamed(route);
  }

  void _exportPatients() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Patient data export started.',
          style: TextStyle(fontSize: 14),
        ),
      ),
    );
  }

  void _viewPatient(Map<String, String> patient) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
          ),
          title: const Text(
            'Patient Details',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFF062E58),
            ),
          ),
          content: SizedBox(
            width: 380,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _detailRow('Patient ID', patient['id']!),
                _detailRow('Patient Name', patient['name']!),
                _detailRow('Age', patient['age']!),
                _detailRow('Gender', patient['gender']!),
                _detailRow('Ward Type', patient['ward']!),
                _detailRow('Ward ID', patient['wardId']!),
                _detailRow('Bed ID', patient['bedId']!),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text(
                'Close',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF0879E8),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                color: Color(0xFF64748B),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF1E293B),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showAddPatientDialog() async {
    final patientIdController = TextEditingController();
    final patientNameController = TextEditingController();
    final ageController = TextEditingController();

    String? selectedGender;
    String? selectedWardType;
    String? selectedWardId;
    String? selectedBedId;
    String? validationMessage;

    final result = await showDialog<Map<String, String>>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            void showValidation(String message) {
              setDialogState(() {
                validationMessage = message;
              });
            }

            return Dialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              child: SizedBox(
                width: 540,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                    26,
                    22,
                    26,
                    22,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Add Patient',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF062E58),
                                ),
                              ),
                            ),
                            IconButton(
                              tooltip: 'Close',
                              onPressed: () {
                                Navigator.of(dialogContext).pop();
                              },
                              icon: const Icon(
                                Icons.close,
                                size: 20,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 4),

                        const Text(
                          'Enter the patient information below.',
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFF64748B),
                          ),
                        ),

                        const SizedBox(height: 20),

                        Row(
                          children: [
                            Expanded(
                              child: _dialogTextField(
                                controller: patientIdController,
                                label: 'Patient ID',
                                hint: 'e.g. P-006',
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: _dialogTextField(
                                controller: patientNameController,
                                label: 'Patient Name',
                                hint: 'Enter patient name',
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 14),

                        Row(
                          children: [
                            Expanded(
                              child: _dialogTextField(
                                controller: ageController,
                                label: 'Age',
                                hint: 'Enter age',
                                keyboardType: TextInputType.number,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: _dialogDropdown(
                                label: 'Gender',
                                value: selectedGender,
                                items: const [
                                  'M',
                                  'F',
                                ],
                                onChanged: (value) {
                                  setDialogState(() {
                                    selectedGender = value;
                                    validationMessage = null;
                                  });
                                },
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 14),

                        _dialogDropdown(
                          label: 'Ward Type',
                          value: selectedWardType,
                          items: const [
                            'Medical',
                            'Surgical',
                            'General',
                            'Emergency',
                          ],
                          onChanged: (value) {
                            setDialogState(() {
                              selectedWardType = value;
                              validationMessage = null;
                            });
                          },
                        ),

                        const SizedBox(height: 14),

                        _dialogDropdown(
                          label: 'Ward ID',
                          value: selectedWardId,
                          items: _wardIds,
                          onChanged: (value) {
                            setDialogState(() {
                              selectedWardId = value;
                              validationMessage = null;
                            });
                          },
                        ),

                        const SizedBox(height: 14),

                        _dialogDropdown(
                          label: 'Bed ID',
                          value: selectedBedId,
                          items: _bedIds,
                          onChanged: (value) {
                            setDialogState(() {
                              selectedBedId = value;
                              validationMessage = null;
                            });
                          },
                        ),

                        if (validationMessage != null) ...[
                          const SizedBox(height: 14),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF3F3),
                              border: Border.all(
                                color: const Color(0xFFF2B8B8),
                              ),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Text(
                              validationMessage!,
                              style: const TextStyle(
                                fontSize: 14,
                                color: Color(0xFFC62828),
                              ),
                            ),
                          ),
                        ],

                        const SizedBox(height: 24),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              height: 40,
                              child: OutlinedButton(
                                onPressed: () {
                                  Navigator.of(dialogContext).pop();
                                },
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(
                                    color: Color(0xFFD0D7DE),
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                  ),
                                ),
                                child: const Text(
                                  'Cancel',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Color(0xFF475569),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(width: 10),

                            SizedBox(
                              height: 40,
                              child: ElevatedButton(
                                onPressed: () {
                                  final patientId =
                                      patientIdController.text.trim();
                                  final patientName =
                                      patientNameController.text.trim();
                                  final age = ageController.text.trim();

                                  if (patientId.isEmpty ||
                                      patientName.isEmpty ||
                                      age.isEmpty ||
                                      selectedGender == null ||
                                      selectedWardType == null ||
                                      selectedWardId == null ||
                                      selectedBedId == null) {
                                    showValidation(
                                      'Please complete all patient fields.',
                                    );
                                    return;
                                  }

                                  final parsedAge = int.tryParse(age);

                                  if (parsedAge == null ||
                                      parsedAge <= 0 ||
                                      parsedAge > 120) {
                                    showValidation(
                                      'Please enter a valid age between 1 and 120.',
                                    );
                                    return;
                                  }

                                  final alreadyExists = _patients.any(
                                    (patient) =>
                                        patient['id']!
                                            .toLowerCase() ==
                                        patientId.toLowerCase(),
                                  );

                                  if (alreadyExists) {
                                    showValidation(
                                      'A patient with this ID already exists.',
                                    );
                                    return;
                                  }

                                  Navigator.of(dialogContext).pop({
                                    'id': patientId,
                                    'name': patientName,
                                    'age': age,
                                    'gender': selectedGender!,
                                    'ward': selectedWardType!,
                                    'wardId': selectedWardId!,
                                    'bedId': selectedBedId!,
                                  });
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      const Color(0xFF0879E8),
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 22,
                                  ),
                                ),
                                child: const Text(
                                  'Done',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    patientIdController.dispose();
    patientNameController.dispose();
    ageController.dispose();

    if (result == null || !mounted) {
      return;
    }

    setState(() {
      _patients.insert(0, result);
      _currentPage = 1;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${result['name']} was added successfully.',
          style: const TextStyle(fontSize: 14),
        ),
      ),
    );
  }

  Widget _dialogTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Color(0xFF334155),
          ),
        ),
        const SizedBox(height: 7),
        SizedBox(
          height: 42,
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF1E293B),
            ),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                fontSize: 14,
                color: Color(0xFF94A3B8),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Color(0xFFD0D7DE),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Color(0xFFD0D7DE),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Color(0xFF0879E8),
                  width: 1.3,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _dialogDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Color(0xFF334155),
          ),
        ),
        const SizedBox(height: 7),
        SizedBox(
          height: 42,
          child: DropdownButtonFormField<String>(
            initialValue: value,
            isExpanded: true,
            icon: const Icon(
              Icons.keyboard_arrow_down,
              size: 20,
              color: Color(0xFF64748B),
            ),
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF1E293B),
            ),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 8,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Color(0xFFD0D7DE),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Color(0xFFD0D7DE),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Color(0xFF0879E8),
                  width: 1.3,
                ),
              ),
            ),
            hint: const Text(
              'Select',
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF94A3B8),
              ),
            ),
            items: items.map((item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Text(
                  item,
                  style: const TextStyle(
                    fontSize: 14,
                  ),
                ),
              );
            }).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final patients = _filteredPatients;
    final visiblePatients = _patientsForCurrentPage(patients);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/hospital.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                color: const Color(0xFFEAF3F9),
                child: const Center(
                  child: Text(
                    'Hospital background image not found',
                    style: TextStyle(
                      color: Color(0xFF31556D),
                      fontSize: 14,
                    ),
                  ),
                ),
              );
            },
          ),

          Container(
            color: const Color(0x18002545),
          ),

          SafeArea(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSidebar(),

                Expanded(
                  child: Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildTopHeader(),

                        Expanded(
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.fromLTRB(
                              28,
                              24,
                              28,
                              30,
                            ),
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                _buildPageHeader(),

                                const SizedBox(height: 24),

                                _buildSearchBar(),

                                const SizedBox(height: 18),

                                _buildPatientTable(visiblePatients),

                                const SizedBox(height: 18),

                                _buildPagination(patients),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopHeader() {
    return Container(
      height: 58,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE2E8F0),
          ),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 28,
        ),
        child: Row(
          children: [
            const Text(
              'Patient Management',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF334155),
              ),
            ),

            const Spacer(),

            const Icon(
              Icons.notifications_none_outlined,
              size: 21,
              color: Color(0xFF64748B),
            ),

            const SizedBox(width: 20),

            Container(
              width: 32,
              height: 32,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFE8F2FC),
              ),
              child: const Center(
                child: Icon(
                  Icons.person_outline,
                  size: 19,
                  color: Color(0xFF0A4B7A),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPageHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Expanded(
          child: Text(
            'Patients',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w600,
              color: Color(0xFF06427D),
            ),
          ),
        ),

        MouseRegion(
          onEnter: (_) {
            setState(() {
              _exportHover = true;
            });
          },
          onExit: (_) {
            setState(() {
              _exportHover = false;
            });
          },
          child: SizedBox(
            height: 40,
            child: OutlinedButton.icon(
              onPressed: _exportPatients,
              icon: const Icon(
                Icons.download_outlined,
                size: 18,
              ),
              label: const Text(
                'Export',
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: _exportHover
                    ? const Color(0xFF0879E8)
                    : const Color(0xFF475569),
                side: BorderSide(
                  color: _exportHover
                      ? const Color(0xFF0879E8)
                      : const Color(0xFFD0D7DE),
                ),
                backgroundColor: _exportHover
                    ? const Color(0xFFF4F9FF)
                    : Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 15,
                ),
              ),
            ),
          ),
        ),

        const SizedBox(width: 10),

        MouseRegion(
          onEnter: (_) {
            setState(() {
              _addPatientHover = true;
            });
          },
          onExit: (_) {
            setState(() {
              _addPatientHover = false;
            });
          },
          child: SizedBox(
            height: 40,
            child: ElevatedButton.icon(
              onPressed: _showAddPatientDialog,
              icon: const Icon(
                Icons.add,
                size: 18,
              ),
              label: const Text(
                'Add Patient',
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: _addPatientHover
                    ? const Color(0xFF066FD4)
                    : const Color(0xFF0879E8),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Container(
      height: 42,
      width: 420,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD0D7DE),
        ),
      ),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(
          fontSize: 14,
          color: Color(0xFF1E293B),
        ),
        decoration: const InputDecoration(
          hintText: 'Search patients...',
          hintStyle: TextStyle(
            fontSize: 14,
            color: Color(0xFF94A3B8),
          ),
          prefixIcon: Icon(
            Icons.search,
            size: 20,
            color: Color(0xFF64748B),
          ),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(
            vertical: 11,
          ),
        ),
      ),
    );
  }

  Widget _buildPatientTable(
    List<Map<String, String>> patients,
  ) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFE2E8F0),
        ),
      ),
      child: Column(
        children: [
          Container(
            height: 48,
            decoration: const BoxDecoration(
              color: Color(0xFFF8FAFC),
              border: Border(
                bottom: BorderSide(
                  color: Color(0xFFE2E8F0),
                ),
              ),
            ),
            child: const Row(
              children: [
                _TableHeader(
                  text: 'Patient ID',
                  flex: 1,
                ),
                _TableHeader(
                  text: 'Patient Name',
                  flex: 2,
                ),
                _TableHeader(
                  text: 'Age',
                  flex: 1,
                ),
                _TableHeader(
                  text: 'Gender',
                  flex: 1,
                ),
                _TableHeader(
                  text: 'Ward Type',
                  flex: 2,
                ),
                _TableHeader(
                  text: 'Ward ID',
                  flex: 1,
                ),
                _TableHeader(
                  text: 'Bed ID',
                  flex: 1,
                ),
                _TableHeader(
                  text: 'Action',
                  flex: 1,
                ),
              ],
            ),
          ),

          if (patients.isEmpty)
            const SizedBox(
              height: 110,
              child: Center(
                child: Text(
                  'No patients found.',
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF64748B),
                  ),
                ),
              ),
            )
          else
            ...patients.map(
              (patient) => _buildPatientRow(patient),
            ),
        ],
      ),
    );
  }

  Widget _buildPatientRow(
    Map<String, String> patient,
  ) {
    return Container(
      height: 58,
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE2E8F0),
          ),
        ),
      ),
      child: Row(
        children: [
          _TableCell(
            text: patient['id']!,
            flex: 1,
            bold: true,
          ),
          _TableCell(
            text: patient['name']!,
            flex: 2,
          ),
          _TableCell(
            text: patient['age']!,
            flex: 1,
          ),
          _TableCell(
            text: patient['gender']!,
            flex: 1,
          ),
          _TableCell(
            text: patient['ward']!,
            flex: 2,
          ),
          _TableCell(
            text: patient['wardId']!,
            flex: 1,
          ),
          _TableCell(
            text: patient['bedId']!,
            flex: 1,
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: TextButton(
                onPressed: () {
                  _viewPatient(patient);
                },
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF0879E8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 5,
                  ),
                ),
                child: const Text(
                  'View',
                  style: TextStyle(
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination(
    List<Map<String, String>> patients,
  ) {
    final totalPages = patients.isEmpty
        ? 1
        : ((patients.length - 1) ~/ _rowsPerPage) + 1;

    final page = _currentPage.clamp(1, totalPages);

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        IconButton(
          onPressed: page > 1
              ? () {
                  setState(() {
                    _currentPage = page - 1;
                  });
                }
              : null,
          icon: const Icon(
            Icons.chevron_left,
            size: 20,
          ),
          color: const Color(0xFF475569),
          disabledColor: const Color(0xFFCBD5E1),
          tooltip: 'Previous page',
        ),

        SizedBox(
          width: 32,
          height: 32,
          child: Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              '$page',
              style: const TextStyle(
                fontSize: 14,
                color: Colors.white,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),

        IconButton(
          onPressed: page < totalPages
              ? () {
                  setState(() {
                    _currentPage = page + 1;
                  });
                }
              : null,
          icon: const Icon(
            Icons.chevron_right,
            size: 20,
          ),
          color: const Color(0xFF475569),
          disabledColor: const Color(0xFFCBD5E1),
          tooltip: 'Next page',
        ),
      ],
    );
  }

  Widget _buildSidebar() {
    return Container(
      width: 170,
      color: const Color(0xFF062E58),
      child: Column(
        children: [
          const SizedBox(height: 9),

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              children: [
                _SidebarButton(
                  icon: Icons.dashboard_outlined,
                  title: 'Home',
                  selected: false,
                  onTap: () => _navigate('/dashboard'),
                ),
                _SidebarButton(
                  icon: Icons.notifications_none_rounded,
                  title: 'Alerts',
                  selected: false,
                  onTap: () => _navigate('/alerts'),
                ),
                _SidebarButton(
                  icon: Icons.person_outline_rounded,
                  title: 'Patients',
                  selected: true,
                  onTap: () {},
                ),
                _SidebarButton(
                  icon: Icons.bed_outlined,
                  title: 'Bed/Wards',
                  selected: false,
                  onTap: () => _navigate('/beds-wards'),
                ),
                _SidebarButton(
                  icon: Icons.devices_other_outlined,
                  title: 'Devices',
                  selected: false,
                  onTap: () => _navigate('/devices'),
                ),
                _SidebarButton(
                  icon: Icons.sensors_outlined,
                  title: 'Receiver',
                  selected: false,
                  onTap: () => _navigate('/receiver'),
                ),
                _SidebarButton(
                  icon: Icons.bar_chart_rounded,
                  title: 'Reports',
                  selected: false,
                  onTap: () => _navigate('/reports'),
                ),
                _SidebarButton(
                  icon: Icons.description_outlined,
                  title: 'Logs',
                  selected: false,
                  onTap: () => _navigate('/logs'),
                ),
                _SidebarButton(
                  icon: Icons.settings_outlined,
                  title: 'Settings',
                  selected: false,
                  onTap: () => _navigate('/settings'),
                ),
                _SidebarButton(
                  icon: Icons.admin_panel_settings_outlined,
                  title: 'Administration',
                  selected: false,
                  onTap: () => _navigate('/administration'),
                ),
              ],
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              icon: Icons.logout_rounded,
              title: 'Logout',
              selected: false,
              onTap: () => _navigate('/logout'),
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.icon,
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() => _SidebarButtonState();
}

class _SidebarButtonState extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final highlighted = widget.selected || _hovering;

    return Padding(
      padding: const EdgeInsets.only(
        bottom: 4,
      ),
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) {
          setState(() {
            _hovering = true;
          });
        },
        onExit: (_) {
          setState(() {
            _hovering = false;
          });
        },
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(
              milliseconds: 150,
            ),
            width: double.infinity,
            constraints: const BoxConstraints(
              minHeight: 42,
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              color: widget.selected
                  ? const Color(0xFF0879E8)
                  : highlighted
                      ? const Color(0xFF0A416E)
                      : Colors.transparent,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 28,
                  child: Icon(
                    widget.icon,
                    color: Colors.white,
                    size: 18,
                  ),
                ),

                const SizedBox(width: 9),

                Expanded(
                  child: Text(
                    widget.title,
                    maxLines: 1,
                    softWrap: false,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      height: 1.0,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TableHeader extends StatelessWidget {
  const _TableHeader({
    required this.text,
    required this.flex,
  });

  final String text;
  final int flex;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
        ),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Color(0xFF475569),
            ),
          ),
        ),
      ),
    );
  }
}

class _TableCell extends StatelessWidget {
  const _TableCell({
    required this.text,
    required this.flex,
    this.bold = false,
  });

  final String text;
  final int flex;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
        ),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 14,
              fontWeight: bold
                  ? FontWeight.w500
                  : FontWeight.w400,
              color: const Color(0xFF334155),
            ),
          ),
        ),
      ),
    );
  }
}