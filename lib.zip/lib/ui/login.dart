import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// login.dart
/// ============================================================

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController =
      TextEditingController();

  final TextEditingController _passwordController =
      TextEditingController();

  bool _showPassword = false;
  bool _rememberMe = false;

  bool _backHover = false;
  bool _setupHover = false;
  bool _forgotHover = false;
  bool _loginHover = false;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // ==========================================================
  // LOGIN -> DASHBOARD
  // ==========================================================

  void _login() {
    if (_usernameController.text.trim().isEmpty) {
      _showMessage('Please enter your username.');
      return;
    }

    if (_passwordController.text.isEmpty) {
      _showMessage('Please enter your password.');
      return;
    }

    Navigator.of(context).pushReplacementNamed('/dashboard');
  }

  // ==========================================================
  // BACK -> LIVE MONITORING
  // ==========================================================

  void _goBack() {
    Navigator.of(context).pushReplacementNamed('/live-monitoring');
  }

  // ==========================================================
  // FIRST TIME SETUP
  // ==========================================================

  void _goFirstTimeSetup() {
    Navigator.of(context).pushNamed('/first-time-setup');
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ====================================================
          // HOSPITAL BACKGROUND
          // ====================================================

          Image.asset(
            'assets/images/hospital.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                color: const Color(0xFFEAF3F9),
                child: const Center(
                  child: Text(
                    'Hospital background image not found',
                    style: TextStyle(
                      color: Color(0xFF31556D),
                      fontSize: 14,
                    ),
                  ),
                ),
              );
            },
          ),

          // ====================================================
          // LIGHT OVERLAY
          // ====================================================

          Container(
            color: const Color(0x18002545),
          ),

          // ====================================================
          // BACK BUTTON
          // ====================================================

          Positioned(
            left: 28,
            top: 28,
            child: _backButton(),
          ),

          // ====================================================
          // LOGIN CARD
          // ====================================================

          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 30,
              ),
              child: _loginCard(),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // BACK BUTTON
  // ==========================================================

  Widget _backButton() {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _backHover = true;
        });
      },
      onExit: (_) {
        setState(() {
          _backHover = false;
        });
      },
      child: GestureDetector(
        onTap: _goBack,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: 44,
          padding: const EdgeInsets.symmetric(
            horizontal: 17,
          ),
          decoration: BoxDecoration(
            color: _backHover
                ? const Color(0xFF0879E8)
                : Colors.white.withOpacity(0.96),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: _backHover
                  ? const Color(0xFF0879E8)
                  : const Color(0xFFD0E0EA),
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x40000000),
                blurRadius: 8,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.arrow_back,
                size: 19,
                color: _backHover
                    ? Colors.white
                    : const Color(0xFF16486B),
              ),
              const SizedBox(width: 8),
              Text(
                'Back',
                style: TextStyle(
                  color: _backHover
                      ? Colors.white
                      : const Color(0xFF16486B),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // LOGIN CARD
  // ==========================================================

  Widget _loginCard() {
    return Container(
      width: 440,
      padding: const EdgeInsets.fromLTRB(
        34,
        32,
        34,
        30,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: const Color(0xFFD3E3EC),
          width: 1,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x60000000),
            blurRadius: 25,
            spreadRadius: 1,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ====================================================
          // LOGO
          // ====================================================

          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: const Color(0xFF07539F),
              borderRadius: BorderRadius.circular(11),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x35000000),
                  blurRadius: 7,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: const Icon(
              Icons.monitor_heart,
              color: Colors.white,
              size: 41,
            ),
          ),

          const SizedBox(height: 18),

          // ====================================================
          // TITLE
          // ====================================================

          const Text(
            'Smart Patient Assistance &',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF06427D),
              fontSize: 20,
              fontWeight: FontWeight.w700,
              height: 1.12,
            ),
          ),

          const Text(
            'Emergency Alert System',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF06427D),
              fontSize: 20,
              fontWeight: FontWeight.w700,
              height: 1.12,
            ),
          ),

          const SizedBox(height: 9),

          const Text(
            'Safe Patients, Faster Response',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF4383BD),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),

          const SizedBox(height: 21),

          // ====================================================
          // DIVIDER
          // ====================================================

          Container(
            width: double.infinity,
            height: 1,
            color: const Color(0xFFDCE8EF),
          ),

          const SizedBox(height: 20),

          // ====================================================
          // USERNAME LABEL
          // ====================================================

          _fieldLabel(
            Icons.person,
            'Username',
          ),

          const SizedBox(height: 8),

          // ====================================================
          // USERNAME FIELD
          // ====================================================

          _inputField(
            controller: _usernameController,
            hintText: 'Enter your username',
            icon: Icons.person_outline,
          ),

          const SizedBox(height: 16),

          // ====================================================
          // PASSWORD LABEL
          // ====================================================

          _fieldLabel(
            Icons.lock,
            'Password',
          ),

          const SizedBox(height: 8),

          // ====================================================
          // PASSWORD FIELD
          // ====================================================

          _inputField(
            controller: _passwordController,
            hintText: 'Enter your password',
            icon: Icons.lock_outline,
            obscureText: !_showPassword,
            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _showPassword = !_showPassword;
                });
              },
              icon: Icon(
                _showPassword
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined,
                size: 20,
                color: const Color(0xFF557A96),
              ),
            ),
          ),

          const SizedBox(height: 10),

          // ====================================================
          // REMEMBER ME
          // ====================================================

          Row(
            children: [
              SizedBox(
                width: 25,
                height: 25,
                child: Checkbox(
                  value: _rememberMe,
                  onChanged: (value) {
                    setState(() {
                      _rememberMe = value ?? false;
                    });
                  },
                  activeColor: const Color(0xFF0879E8),
                  side: const BorderSide(
                    color: Color(0xFF0879E8),
                    width: 1.5,
                  ),
                  materialTapTargetSize:
                      MaterialTapTargetSize.shrinkWrap,
                ),
              ),
              const SizedBox(width: 7),
              const Text(
                'Remember me',
                style: TextStyle(
                  color: Color(0xFF23465D),
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),

          const SizedBox(height: 17),

          // ====================================================
          // LOGIN BUTTON
          // ====================================================

          _loginButton(),

          const SizedBox(height: 22),

          // ====================================================
          // BOTTOM LINKS
          // ====================================================

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // ------------------------------------------------
              // FIRST TIME SETUP
              // ------------------------------------------------

              MouseRegion(
                cursor: SystemMouseCursors.click,
                onEnter: (_) {
                  setState(() {
                    _setupHover = true;
                  });
                },
                onExit: (_) {
                  setState(() {
                    _setupHover = false;
                  });
                },
                child: GestureDetector(
                  onTap: _goFirstTimeSetup,
                  child: Text(
                    'First Time Setup',
                    style: TextStyle(
                      color: _setupHover
                          ? const Color(0xFF064D9E)
                          : const Color(0xFF0879E8),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),

              // ------------------------------------------------
              // FORGOT PASSWORD
              //
              // NO NAVIGATION
              // ------------------------------------------------

              MouseRegion(
                cursor: SystemMouseCursors.click,
                onEnter: (_) {
                  setState(() {
                    _forgotHover = true;
                  });
                },
                onExit: (_) {
                  setState(() {
                    _forgotHover = false;
                  });
                },
                child: GestureDetector(
                  onTap: () {
                    // No navigation.
                  },
                  child: Text(
                    'Forgot Password?',
                    style: TextStyle(
                      color: _forgotHover
                          ? const Color(0xFF064D9E)
                          : const Color(0xFF0879E8),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // FIELD LABEL
  // ==========================================================

  Widget _fieldLabel(
    IconData icon,
    String label,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: const Color(0xFF124B76),
        ),
        const SizedBox(width: 7),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF23465D),
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  // ==========================================================
  // INPUT FIELD
  // ==========================================================

  Widget _inputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    bool obscureText = false,
    Widget? suffixIcon,
  }) {
    return SizedBox(
      height: 46,
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: const TextStyle(
            color: Color(0xFFA1B6C5),
            fontSize: 14,
          ),
          prefixIcon: Icon(
            icon,
            size: 19,
            color: Color(0xFF9AB0C0),
          ),
          suffixIcon: suffixIcon,
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // LOGIN BUTTON
  // ==========================================================

  Widget _loginButton() {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _loginHover = true;
        });
      },
      onExit: (_) {
        setState(() {
          _loginHover = false;
        });
      },
      child: GestureDetector(
        onTap: _login,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: double.infinity,
          height: 43,
          decoration: BoxDecoration(
            color: _loginHover
                ? const Color(0xFF066FD5)
                : const Color(0xFF0879E8),
            borderRadius: BorderRadius.circular(5),
            boxShadow: const [
              BoxShadow(
                color: Color(0x300879E8),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: const Center(
            child: Text(
              'Login',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}