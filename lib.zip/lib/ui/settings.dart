import 'package:flutter/material.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// system.dart
///
/// SETTINGS
///
/// Includes:
/// - System Settings
/// - Notification Settings
/// - Appearance Settings
/// - Account Settings
/// - Change Username
/// - Change Password
/// - Change Password Using Recovery Key
/// - Change Recovery Key
///
/// All visible text: 14px
/// Background: assets/images/hospital.png
/// ============================================================

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // ==========================================================
  // SIDEBAR
  // ==========================================================

  int _selectedIndex = 8;

  // ==========================================================
  // SETTINGS TAB
  // 0 = System
  // 1 = Notifications
  // 2 = Appearance
  // 3 = Account Settings
  // ==========================================================

  int _selectedTab = 0;

  // ==========================================================
  // SYSTEM SETTINGS
  // ==========================================================

  String _language = 'English';

  String _timeZone = '(UTC+03:00) East Africa Time';

  String _autoLogout = '30';

  bool _soundNotifications = true;

  bool _desktopNotifications = true;

  // ==========================================================
  // NOTIFICATION SETTINGS
  // ==========================================================

  bool _emergencyAlerts = true;

  bool _patientAlerts = true;

  bool _deviceAlerts = true;

  bool _receiverAlerts = true;

  bool _criticalAlertNotifications = true;

  // ==========================================================
  // APPEARANCE SETTINGS
  // ==========================================================

  String _theme = 'Light';

  String _density = 'Comfortable';

  bool _compactSidebar = false;

  // ==========================================================
  // SIDEBAR ITEMS
  // ==========================================================

  final List<_MenuItem> _menuItems = const [
    _MenuItem(
      title: 'Home',
      icon: Icons.home_outlined,
      route: '/dashboard',
    ),
    _MenuItem(
      title: 'Alerts',
      icon: Icons.notifications_none_rounded,
      route: '/alerts',
    ),
    _MenuItem(
      title: 'Patients',
      icon: Icons.person_outline_rounded,
      route: '/patients',
    ),
    _MenuItem(
      title: 'Bed/Wards',
      icon: Icons.bed_outlined,
      route: '/beds-wards',
    ),
    _MenuItem(
      title: 'Devices',
      icon: Icons.devices_other_outlined,
      route: '/devices',
    ),
    _MenuItem(
      title: 'Receiver',
      icon: Icons.sensors_outlined,
      route: '/receiver',
    ),
    _MenuItem(
      title: 'Reports',
      icon: Icons.bar_chart_rounded,
      route: '/reports',
    ),
    _MenuItem(
      title: 'Logs',
      icon: Icons.description_outlined,
      route: '/logs',
    ),
    _MenuItem(
      title: 'Settings',
      icon: Icons.settings_outlined,
      route: '/settings',
    ),
    _MenuItem(
      title: 'Administration',
      icon: Icons.admin_panel_settings_outlined,
      route: '/administration',
    ),
  ];

  // ==========================================================
  // SIDEBAR NAVIGATION
  // ==========================================================

  void _handleMenuTap(int index) {
    setState(() {
      _selectedIndex = index;
    });

    final String route = _menuItems[index].route;

    if (route == '/settings') {
      return;
    }

    Navigator.of(context).pushReplacementNamed(route);
  }

  // ==========================================================
  // LOGOUT
  // ==========================================================

  void _logout() {
    Navigator.of(context).pushReplacementNamed('/logout');
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ==========================================================
  // SAVE SYSTEM SETTINGS
  // ==========================================================

  void _saveSystemSettings() {
    _showMessage(
      'System settings saved successfully.',
    );
  }

  // ==========================================================
  // RESET SYSTEM SETTINGS
  // ==========================================================

  void _resetSystemSettings() {
    setState(() {
      _language = 'English';
      _timeZone = '(UTC+03:00) East Africa Time';
      _autoLogout = '30';
      _soundNotifications = true;
      _desktopNotifications = true;
    });

    _showMessage(
      'System settings reset.',
    );
  }

  // ==========================================================
  // SAVE NOTIFICATIONS
  // ==========================================================

  void _saveNotificationSettings() {
    _showMessage(
      'Notification settings saved successfully.',
    );
  }

  // ==========================================================
  // SAVE APPEARANCE
  // ==========================================================

  void _saveAppearanceSettings() {
    _showMessage(
      'Appearance settings saved successfully.',
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            // ==================================================
            // SIDEBAR
            // ==================================================

            _SettingsSidebar(
              selectedIndex: _selectedIndex,
              menuItems: _menuItems,
              onMenuTap: _handleMenuTap,
              onLogout: _logout,
            ),

            // ==================================================
            // MAIN AREA
            // ==================================================

            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // ==================================================
                  // HOSPITAL BACKGROUND
                  // ==================================================

                  Image.asset(
                    'assets/images/hospital.png',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                    errorBuilder: (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return Container(
                        color: const Color(0xFFEAF3F9),
                      );
                    },
                  ),

                  // ==================================================
                  // BACKGROUND OVERLAY
                  // ==================================================

                  Container(
                    color: const Color(0x18002545),
                  ),

                  // ==================================================
                  // SETTINGS CONTENT
                  // ==================================================

                  _SettingsContent(
                    selectedTab: _selectedTab,
                    language: _language,
                    timeZone: _timeZone,
                    autoLogout: _autoLogout,
                    soundNotifications: _soundNotifications,
                    desktopNotifications: _desktopNotifications,
                    emergencyAlerts: _emergencyAlerts,
                    patientAlerts: _patientAlerts,
                    deviceAlerts: _deviceAlerts,
                    receiverAlerts: _receiverAlerts,
                    criticalAlertNotifications:
                        _criticalAlertNotifications,
                    theme: _theme,
                    density: _density,
                    compactSidebar: _compactSidebar,

                    onTabChanged: (value) {
                      setState(() {
                        _selectedTab = value;
                      });
                    },

                    onLanguageChanged: (value) {
                      setState(() {
                        _language = value;
                      });
                    },

                    onTimeZoneChanged: (value) {
                      setState(() {
                        _timeZone = value;
                      });
                    },

                    onAutoLogoutChanged: (value) {
                      setState(() {
                        _autoLogout = value;
                      });
                    },

                    onSoundNotificationsChanged: (value) {
                      setState(() {
                        _soundNotifications = value;
                      });
                    },

                    onDesktopNotificationsChanged: (value) {
                      setState(() {
                        _desktopNotifications = value;
                      });
                    },

                    onEmergencyAlertsChanged: (value) {
                      setState(() {
                        _emergencyAlerts = value;
                      });
                    },

                    onPatientAlertsChanged: (value) {
                      setState(() {
                        _patientAlerts = value;
                      });
                    },

                    onDeviceAlertsChanged: (value) {
                      setState(() {
                        _deviceAlerts = value;
                      });
                    },

                    onReceiverAlertsChanged: (value) {
                      setState(() {
                        _receiverAlerts = value;
                      });
                    },

                    onCriticalAlertNotificationsChanged:
                        (value) {
                      setState(() {
                        _criticalAlertNotifications = value;
                      });
                    },

                    onThemeChanged: (value) {
                      setState(() {
                        _theme = value;
                      });
                    },

                    onDensityChanged: (value) {
                      setState(() {
                        _density = value;
                      });
                    },

                    onCompactSidebarChanged: (value) {
                      setState(() {
                        _compactSidebar = value;
                      });
                    },

                    onSaveSystem: _saveSystemSettings,

                    onResetSystem: _resetSystemSettings,

                    onSaveNotifications:
                        _saveNotificationSettings,

                    onSaveAppearance:
                        _saveAppearanceSettings,

                    onAccountMessage: _showMessage,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM
// ============================================================

class _MenuItem {
  const _MenuItem({
    required this.title,
    required this.icon,
    required this.route,
  });

  final String title;
  final IconData icon;
  final String route;
}

// ============================================================
// SIDEBAR
// ============================================================

class _SettingsSidebar extends StatelessWidget {
  const _SettingsSidebar({
    required this.selectedIndex,
    required this.menuItems,
    required this.onMenuTap,
    required this.onLogout,
  });

  final int selectedIndex;
  final List<_MenuItem> menuItems;
  final ValueChanged<int> onMenuTap;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      decoration: const BoxDecoration(
        color: Color(0xFF062E58),
      ),
      child: Column(
        children: [
          const SizedBox(height: 9),

          // ==================================================
          // LOGO
          // ==================================================

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF0879E8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.monitor_heart_outlined,
              color: Colors.white,
              size: 27,
            ),
          ),

          const SizedBox(height: 12),

          // ==================================================
          // MENU
          // ==================================================

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
              ),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];

                return Padding(
                  padding: const EdgeInsets.only(
                    bottom: 4,
                  ),
                  child: _SidebarButton(
                    title: item.title,
                    icon: item.icon,
                    selected: selectedIndex == index,
                    onTap: () => onMenuTap(index),
                  ),
                );
              },
            ),
          ),

          const Divider(
            height: 1,
            color: Color(0xFF1B4770),
            indent: 10,
            endIndent: 10,
          ),

          const SizedBox(height: 5),

          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
            ),
            child: _SidebarButton(
              title: 'Logout',
              icon: Icons.logout_rounded,
              selected: false,
              onTap: onLogout,
            ),
          ),

          const SizedBox(height: 9),
        ],
      ),
    );
  }
}

// ============================================================
// SIDEBAR BUTTON
// ============================================================

class _SidebarButton extends StatefulWidget {
  const _SidebarButton({
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_SidebarButton> createState() =>
      _SidebarButtonState();
}

class _SidebarButtonState
    extends State<_SidebarButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final bool highlighted =
        widget.selected || _hovering;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          width: double.infinity,
          constraints: const BoxConstraints(
            minHeight: 42,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: widget.selected
                ? const Color(0xFF0879E8)
                : highlighted
                    ? const Color(0xFF0A416E)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 18,
                ),
              ),

              const SizedBox(width: 9),

              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.visible,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SETTINGS CONTENT
// ============================================================

class _SettingsContent extends StatelessWidget {
  const _SettingsContent({
    required this.selectedTab,
    required this.language,
    required this.timeZone,
    required this.autoLogout,
    required this.soundNotifications,
    required this.desktopNotifications,
    required this.emergencyAlerts,
    required this.patientAlerts,
    required this.deviceAlerts,
    required this.receiverAlerts,
    required this.criticalAlertNotifications,
    required this.theme,
    required this.density,
    required this.compactSidebar,
    required this.onTabChanged,
    required this.onLanguageChanged,
    required this.onTimeZoneChanged,
    required this.onAutoLogoutChanged,
    required this.onSoundNotificationsChanged,
    required this.onDesktopNotificationsChanged,
    required this.onEmergencyAlertsChanged,
    required this.onPatientAlertsChanged,
    required this.onDeviceAlertsChanged,
    required this.onReceiverAlertsChanged,
    required this.onCriticalAlertNotificationsChanged,
    required this.onThemeChanged,
    required this.onDensityChanged,
    required this.onCompactSidebarChanged,
    required this.onSaveSystem,
    required this.onResetSystem,
    required this.onSaveNotifications,
    required this.onSaveAppearance,
    required this.onAccountMessage,
  });

  final int selectedTab;

  final String language;
  final String timeZone;
  final String autoLogout;

  final bool soundNotifications;
  final bool desktopNotifications;

  final bool emergencyAlerts;
  final bool patientAlerts;
  final bool deviceAlerts;
  final bool receiverAlerts;
  final bool criticalAlertNotifications;

  final String theme;
  final String density;
  final bool compactSidebar;

  final ValueChanged<int> onTabChanged;

  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<String> onTimeZoneChanged;
  final ValueChanged<String> onAutoLogoutChanged;

  final ValueChanged<bool> onSoundNotificationsChanged;
  final ValueChanged<bool> onDesktopNotificationsChanged;

  final ValueChanged<bool> onEmergencyAlertsChanged;
  final ValueChanged<bool> onPatientAlertsChanged;
  final ValueChanged<bool> onDeviceAlertsChanged;
  final ValueChanged<bool> onReceiverAlertsChanged;
  final ValueChanged<bool>
      onCriticalAlertNotificationsChanged;

  final ValueChanged<String> onThemeChanged;
  final ValueChanged<String> onDensityChanged;
  final ValueChanged<bool> onCompactSidebarChanged;

  final VoidCallback onSaveSystem;
  final VoidCallback onResetSystem;
  final VoidCallback onSaveNotifications;
  final VoidCallback onSaveAppearance;

  final ValueChanged<String> onAccountMessage;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            14,
            12,
            14,
            16,
          ),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: 930,
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.stretch,
                children: [
                  // ==================================================
                  // TOP BAR
                  // ==================================================

                  _SettingsTopBar(
                    selectedTab: selectedTab,
                    onTabChanged: onTabChanged,
                  ),

                  const SizedBox(height: 10),

                  // ==================================================
                  // SYSTEM
                  // ==================================================

                  if (selectedTab == 0)
                    _SystemSettingsPanel(
                      language: language,
                      timeZone: timeZone,
                      autoLogout: autoLogout,
                      soundNotifications:
                          soundNotifications,
                      desktopNotifications:
                          desktopNotifications,
                      onLanguageChanged:
                          onLanguageChanged,
                      onTimeZoneChanged:
                          onTimeZoneChanged,
                      onAutoLogoutChanged:
                          onAutoLogoutChanged,
                      onSoundNotificationsChanged:
                          onSoundNotificationsChanged,
                      onDesktopNotificationsChanged:
                          onDesktopNotificationsChanged,
                      onSave: onSaveSystem,
                      onReset: onResetSystem,
                    ),

                  // ==================================================
                  // NOTIFICATIONS
                  // ==================================================

                  if (selectedTab == 1)
                    _NotificationsSettingsPanel(
                      emergencyAlerts:
                          emergencyAlerts,
                      patientAlerts:
                          patientAlerts,
                      deviceAlerts:
                          deviceAlerts,
                      receiverAlerts:
                          receiverAlerts,
                      criticalAlertNotifications:
                          criticalAlertNotifications,
                      onEmergencyAlertsChanged:
                          onEmergencyAlertsChanged,
                      onPatientAlertsChanged:
                          onPatientAlertsChanged,
                      onDeviceAlertsChanged:
                          onDeviceAlertsChanged,
                      onReceiverAlertsChanged:
                          onReceiverAlertsChanged,
                      onCriticalAlertNotificationsChanged:
                          onCriticalAlertNotificationsChanged,
                      onSave:
                          onSaveNotifications,
                    ),

                  // ==================================================
                  // APPEARANCE
                  // ==================================================

                  if (selectedTab == 2)
                    _AppearanceSettingsPanel(
                      theme: theme,
                      density: density,
                      compactSidebar:
                          compactSidebar,
                      onThemeChanged:
                          onThemeChanged,
                      onDensityChanged:
                          onDensityChanged,
                      onCompactSidebarChanged:
                          onCompactSidebarChanged,
                      onSave:
                          onSaveAppearance,
                    ),

                  // ==================================================
                  // ACCOUNT SETTINGS
                  // ==================================================

                  if (selectedTab == 3)
                    Center(
                      child: ConstrainedBox(
                        constraints:
                            const BoxConstraints(
                          maxWidth: 760,
                        ),
                        child:
                            _AccountSettingsPanel(
                          onMessage:
                              onAccountMessage,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// TOP SETTINGS BAR
// ============================================================

class _SettingsTopBar extends StatelessWidget {
  const _SettingsTopBar({
    required this.selectedTab,
    required this.onTabChanged,
  });

  final int selectedTab;
  final ValueChanged<int> onTabChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.97),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x30000000),
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          _TopTab(
            title: 'System',
            icon: Icons.settings_outlined,
            selected: selectedTab == 0,
            onTap: () => onTabChanged(0),
          ),

          _TopTab(
            title: 'Notifications',
            icon: Icons.notifications_none_rounded,
            selected: selectedTab == 1,
            onTap: () => onTabChanged(1),
          ),

          _TopTab(
            title: 'Appearance',
            icon: Icons.palette_outlined,
            selected: selectedTab == 2,
            onTap: () => onTabChanged(2),
          ),

          const Spacer(),

          _TopActionButton(
            icon: Icons.manage_accounts_outlined,
            text: 'Account Settings',
            selected: selectedTab == 3,
            onTap: () => onTabChanged(3),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// TOP TAB
// ============================================================

class _TopTab extends StatelessWidget {
  const _TopTab({
    required this.title,
    required this.selected,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final bool selected;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 150,
          ),
          margin: const EdgeInsets.only(
            right: 4,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 11,
            vertical: 8,
          ),
          decoration: BoxDecoration(
            color: selected
                ? const Color(0xFFE6F3FD)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 17,
                color: selected
                    ? const Color(0xFF0879E8)
                    : const Color(0xFF668397),
              ),

              const SizedBox(width: 6),

              Text(
                title,
                style: TextStyle(
                  color: selected
                      ? const Color(0xFF0879E8)
                      : const Color(0xFF59788D),
                  fontSize: 14,
                  fontWeight: selected
                      ? FontWeight.w800
                      : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ACCOUNT TOP BUTTON
// ============================================================

class _TopActionButton extends StatefulWidget {
  const _TopActionButton({
    required this.icon,
    required this.text,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String text;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_TopActionButton> createState() =>
      _TopActionButtonState();
}

class _TopActionButtonState
    extends State<_TopActionButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 120,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 9,
          ),
          decoration: BoxDecoration(
            color: _hovering || widget.selected
                ? const Color(0xFF066FD5)
                : const Color(0xFF0879E8),
            borderRadius: BorderRadius.circular(5),
            boxShadow: const [
              BoxShadow(
                color: Color(0x300879E8),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                widget.icon,
                size: 17,
                color: Colors.white,
              ),

              const SizedBox(width: 6),

              Text(
                widget.text,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SYSTEM SETTINGS
// ============================================================

class _SystemSettingsPanel extends StatelessWidget {
  const _SystemSettingsPanel({
    required this.language,
    required this.timeZone,
    required this.autoLogout,
    required this.soundNotifications,
    required this.desktopNotifications,
    required this.onLanguageChanged,
    required this.onTimeZoneChanged,
    required this.onAutoLogoutChanged,
    required this.onSoundNotificationsChanged,
    required this.onDesktopNotificationsChanged,
    required this.onSave,
    required this.onReset,
  });

  final String language;
  final String timeZone;
  final String autoLogout;

  final bool soundNotifications;
  final bool desktopNotifications;

  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<String> onTimeZoneChanged;
  final ValueChanged<String> onAutoLogoutChanged;

  final ValueChanged<bool> onSoundNotificationsChanged;
  final ValueChanged<bool> onDesktopNotificationsChanged;

  final VoidCallback onSave;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    return _SettingsPanel(
      title: 'System Settings',
      icon: Icons.settings_outlined,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          _SettingsLabel(
            icon: Icons.language_outlined,
            text: 'Language',
          ),

          const SizedBox(height: 6),

          _SettingsDropdown(
            value: language,
            items: const [
              'English',
              'French',
              'Swahili',
            ],
            onChanged: onLanguageChanged,
          ),

          const SizedBox(height: 13),

          _SettingsLabel(
            icon: Icons.access_time_outlined,
            text: 'Time Zone',
          ),

          const SizedBox(height: 6),

          _SettingsDropdown(
            value: timeZone,
            items: const [
              '(UTC+03:00) East Africa Time',
              '(UTC+00:00) Greenwich Mean Time',
              '(UTC+01:00) Central European Time',
              '(UTC+02:00) Central Africa Time',
            ],
            onChanged: onTimeZoneChanged,
          ),

          const SizedBox(height: 13),

          _SettingsLabel(
            icon: Icons.timer_outlined,
            text: 'Auto Logout (minutes)',
          ),

          const SizedBox(height: 6),

          _SettingsTextField(
            initialValue: autoLogout,
            hintText: 'Enter minutes',
            icon: Icons.timer_outlined,
            keyboardType: TextInputType.number,
            onChanged: onAutoLogoutChanged,
          ),

          const SizedBox(height: 17),

          _SettingsSwitchRow(
            title: 'Sound Notifications',
            icon: Icons.volume_up_outlined,
            value: soundNotifications,
            onChanged:
                onSoundNotificationsChanged,
          ),

          const SizedBox(height: 5),

          _SettingsSwitchRow(
            title: 'Desktop Notifications',
            icon: Icons.desktop_windows_outlined,
            value: desktopNotifications,
            onChanged:
                onDesktopNotificationsChanged,
          ),

          const SizedBox(height: 18),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          const SizedBox(height: 12),

          Row(
            mainAxisAlignment:
                MainAxisAlignment.end,
            children: [
              _SettingsButton(
                text: 'Reset',
                filled: false,
                icon: Icons.refresh_outlined,
                onTap: onReset,
              ),

              const SizedBox(width: 8),

              _SettingsButton(
                text: 'Save Changes',
                filled: true,
                icon: Icons.save_outlined,
                onTap: onSave,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// NOTIFICATIONS
// ============================================================

class _NotificationsSettingsPanel
    extends StatelessWidget {
  const _NotificationsSettingsPanel({
    required this.emergencyAlerts,
    required this.patientAlerts,
    required this.deviceAlerts,
    required this.receiverAlerts,
    required this.criticalAlertNotifications,
    required this.onEmergencyAlertsChanged,
    required this.onPatientAlertsChanged,
    required this.onDeviceAlertsChanged,
    required this.onReceiverAlertsChanged,
    required this.onCriticalAlertNotificationsChanged,
    required this.onSave,
  });

  final bool emergencyAlerts;
  final bool patientAlerts;
  final bool deviceAlerts;
  final bool receiverAlerts;
  final bool criticalAlertNotifications;

  final ValueChanged<bool> onEmergencyAlertsChanged;
  final ValueChanged<bool> onPatientAlertsChanged;
  final ValueChanged<bool> onDeviceAlertsChanged;
  final ValueChanged<bool> onReceiverAlertsChanged;
  final ValueChanged<bool>
      onCriticalAlertNotificationsChanged;

  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return _SettingsPanel(
      title: 'Notification Settings',
      icon: Icons.notifications_none_rounded,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          _SettingsSwitchRow(
            title: 'Emergency Alerts',
            subtitle:
                'Receive emergency patient alerts.',
            icon: Icons.emergency_outlined,
            value: emergencyAlerts,
            onChanged:
                onEmergencyAlertsChanged,
          ),

          const SizedBox(height: 7),

          _SettingsSwitchRow(
            title: 'Patient Alerts',
            subtitle:
                'Receive patient assistance alerts.',
            icon: Icons.person_outline_rounded,
            value: patientAlerts,
            onChanged:
                onPatientAlertsChanged,
          ),

          const SizedBox(height: 7),

          _SettingsSwitchRow(
            title: 'Device Alerts',
            subtitle:
                'Receive medical device alerts.',
            icon: Icons.devices_other_outlined,
            value: deviceAlerts,
            onChanged:
                onDeviceAlertsChanged,
          ),

          const SizedBox(height: 7),

          _SettingsSwitchRow(
            title: 'Receiver Alerts',
            subtitle:
                'Receive receiver and communication alerts.',
            icon: Icons.sensors_outlined,
            value: receiverAlerts,
            onChanged:
                onReceiverAlertsChanged,
          ),

          const SizedBox(height: 7),

          // ==================================================
          // CRITICAL ALERT NOTIFICATIONS
          // ==================================================

          _SettingsSwitchRow(
            title: 'Critical Alert Notifications',
            subtitle:
                'Receive notifications for critical patient and system events.',
            icon: Icons.warning_amber_outlined,
            value: criticalAlertNotifications,
            onChanged:
                onCriticalAlertNotificationsChanged,
          ),

          const SizedBox(height: 18),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          const SizedBox(height: 12),

          Row(
            mainAxisAlignment:
                MainAxisAlignment.end,
            children: [
              _SettingsButton(
                text: 'Save Changes',
                filled: true,
                icon: Icons.save_outlined,
                onTap: onSave,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// APPEARANCE
// ============================================================

class _AppearanceSettingsPanel
    extends StatelessWidget {
  const _AppearanceSettingsPanel({
    required this.theme,
    required this.density,
    required this.compactSidebar,
    required this.onThemeChanged,
    required this.onDensityChanged,
    required this.onCompactSidebarChanged,
    required this.onSave,
  });

  final String theme;
  final String density;
  final bool compactSidebar;

  final ValueChanged<String> onThemeChanged;
  final ValueChanged<String> onDensityChanged;
  final ValueChanged<bool>
      onCompactSidebarChanged;

  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return _SettingsPanel(
      title: 'Appearance Settings',
      icon: Icons.palette_outlined,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          _SettingsLabel(
            icon: Icons.brightness_6_outlined,
            text: 'Theme',
          ),

          const SizedBox(height: 6),

          _SettingsDropdown(
            value: theme,
            items: const [
              'Light',
              'Dark',
              'System Default',
            ],
            onChanged: onThemeChanged,
          ),

          const SizedBox(height: 14),

          _SettingsLabel(
            icon: Icons.view_compact_outlined,
            text: 'Interface Density',
          ),

          const SizedBox(height: 6),

          _SettingsDropdown(
            value: density,
            items: const [
              'Comfortable',
              'Compact',
              'Spacious',
            ],
            onChanged: onDensityChanged,
          ),

          const SizedBox(height: 14),

          _SettingsSwitchRow(
            title: 'Compact Sidebar',
            subtitle:
                'Use a reduced sidebar layout.',
            icon: Icons.view_sidebar_outlined,
            value: compactSidebar,
            onChanged:
                onCompactSidebarChanged,
          ),

          const SizedBox(height: 18),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          const SizedBox(height: 12),

          Row(
            mainAxisAlignment:
                MainAxisAlignment.end,
            children: [
              _SettingsButton(
                text: 'Save Changes',
                filled: true,
                icon: Icons.save_outlined,
                onTap: onSave,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ACCOUNT SETTINGS
// ============================================================

class _AccountSettingsPanel
    extends StatelessWidget {
  const _AccountSettingsPanel({
    required this.onMessage,
  });

  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    return _SettingsPanel(
      title: 'Account Settings',
      icon: Icons.manage_accounts_outlined,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          // ==================================================
          // CHANGE USERNAME
          // ==================================================

          _AccountSection(
            title: 'Change Username',
            icon: Icons.person_outline_rounded,
            children: [
              _AccountTextField(
                label: 'Current Username',
                hint: 'Enter current username',
                icon: Icons.person_outline,
              ),

              const SizedBox(height: 10),

              _AccountTextField(
                label: 'New Username',
                hint: 'Enter new username',
                icon: Icons.person_add_alt_1_outlined,
              ),

              const SizedBox(height: 10),

              _AccountTextField(
                label: 'Confirm Username',
                hint: 'Confirm new username',
                icon: Icons.verified_user_outlined,
              ),

              const SizedBox(height: 12),

              Align(
                alignment: Alignment.centerRight,
                child: _SettingsButton(
                  text: 'Update',
                  filled: true,
                  icon: Icons.check_outlined,
                  onTap: () {
                    onMessage(
                      'Username update submitted.',
                    );
                  },
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // ==================================================
          // CHANGE PASSWORD
          // ==================================================

          _AccountSection(
            title: 'Change Password',
            icon: Icons.lock_outline,
            children: [
              _AccountPasswordField(
                label: 'Current Password',
                hint: 'Enter current password',
              ),

              const SizedBox(height: 10),

              _AccountPasswordField(
                label: 'New Password',
                hint: 'Enter new password',
              ),

              const SizedBox(height: 10),

              _AccountPasswordField(
                label: 'Confirm New Password',
                hint: 'Confirm new password',
              ),

              const SizedBox(height: 12),

              Align(
                alignment: Alignment.centerRight,
                child: _SettingsButton(
                  text: 'Update',
                  filled: true,
                  icon: Icons.check_outlined,
                  onTap: () {
                    onMessage(
                      'Password update submitted.',
                    );
                  },
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // ==================================================
          // CHANGE PASSWORD USING RECOVERY KEY
          // ==================================================

          _AccountSection(
            title:
                'Change Password Using Recovery Key',
            icon: Icons.key_outlined,
            children: [
              _AccountTextField(
                label: 'Current Recovery Key',
                hint: 'Enter current recovery key',
                icon: Icons.key_outlined,
              ),

              const SizedBox(height: 10),

              _AccountPasswordField(
                label: 'New Password',
                hint: 'Enter new password',
              ),

              const SizedBox(height: 10),

              _AccountPasswordField(
                label: 'Confirm New Password',
                hint: 'Confirm new password',
              ),

              const SizedBox(height: 12),

              Align(
                alignment: Alignment.centerRight,
                child: _SettingsButton(
                  text: 'Update',
                  filled: true,
                  icon: Icons.check_outlined,
                  onTap: () {
                    onMessage(
                      'Password recovery update submitted.',
                    );
                  },
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // ==================================================
          // CHANGE RECOVERY KEY
          // ==================================================

          _AccountSection(
            title: 'Change Recovery Key',
            icon: Icons.vpn_key_outlined,
            children: [
              _AccountTextField(
                label: 'Current Recovery Key',
                hint: 'Enter current recovery key',
                icon: Icons.key_outlined,
              ),

              const SizedBox(height: 10),

              _AccountTextField(
                label: 'New Recovery Key',
                hint: 'Enter new recovery key',
                icon: Icons.vpn_key_outlined,
              ),

              const SizedBox(height: 10),

              _AccountTextField(
                label: 'Confirm New Recovery Key',
                hint: 'Confirm new recovery key',
                icon: Icons.verified_outlined,
              ),

              const SizedBox(height: 12),

              Align(
                alignment: Alignment.centerRight,
                child: _SettingsButton(
                  text: 'Update',
                  filled: true,
                  icon: Icons.check_outlined,
                  onTap: () {
                    onMessage(
                      'Recovery key update submitted.',
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ACCOUNT SECTION
// ============================================================

class _AccountSection extends StatelessWidget {
  const _AccountSection({
    required this.title,
    required this.icon,
    required this.children,
  });

  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FBFE),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: const Color(0xFFE7F3FC),
                  borderRadius:
                      BorderRadius.circular(5),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFF0879E8),
                  size: 19,
                ),
              ),

              const SizedBox(width: 9),

              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF214B69),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 11),

          Container(
            height: 1,
            color: const Color(0xFFDCECF6),
          ),

          const SizedBox(height: 11),

          ...children,
        ],
      ),
    );
  }
}

// ============================================================
// GENERAL SETTINGS PANEL
// ============================================================

class _SettingsPanel extends StatelessWidget {
  const _SettingsPanel({
    required this.title,
    required this.icon,
    required this.child,
  });

  final String title;
  final IconData icon;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        12,
        10,
        12,
        12,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.97),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: const Color(0xFFD1E7F4),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x30000000),
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(
                icon,
                size: 18,
                color: const Color(0xFF0879E8),
              ),

              const SizedBox(width: 7),

              Text(
                title,
                style: const TextStyle(
                  color: Color(0xFF214B69),
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),

          const SizedBox(height: 9),

          const Divider(
            height: 1,
            color: Color(0xFFDCECF6),
          ),

          const SizedBox(height: 10),

          child,
        ],
      ),
    );
  }
}

// ============================================================
// SETTINGS LABEL
// ============================================================

class _SettingsLabel extends StatelessWidget {
  const _SettingsLabel({
    required this.icon,
    required this.text,
  });

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 17,
          color: const Color(0xFF124B76),
        ),

        const SizedBox(width: 7),

        Text(
          text,
          style: const TextStyle(
            color: Color(0xFF23465D),
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// ============================================================
// DROPDOWN
// ============================================================

class _SettingsDropdown extends StatelessWidget {
  const _SettingsDropdown({
    required this.value,
    required this.items,
    required this.onChanged,
  });

  final String value;
  final List<String> items;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: DropdownButtonFormField<String>(
        value: value,

        onChanged: (value) {
          if (value != null) {
            onChanged(value);
          }
        },

        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),

        icon: const Icon(
          Icons.keyboard_arrow_down,
          color: Color(0xFF557A96),
          size: 20,
        ),

        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,

          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 10,
          ),

          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),

        items: items
            .map(
              (item) => DropdownMenuItem<String>(
                value: item,
                child: Text(
                  item,
                  style: const TextStyle(
                    color: Color(0xFF38566A),
                    fontSize: 14,
                  ),
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

// ============================================================
// GENERAL TEXT FIELD
// ============================================================

class _SettingsTextField extends StatefulWidget {
  const _SettingsTextField({
    required this.initialValue,
    required this.hintText,
    required this.icon,
    required this.onChanged,
    this.keyboardType,
  });

  final String initialValue;
  final String hintText;
  final IconData icon;
  final ValueChanged<String> onChanged;
  final TextInputType? keyboardType;

  @override
  State<_SettingsTextField> createState() =>
      _SettingsTextFieldState();
}

class _SettingsTextFieldState
    extends State<_SettingsTextField> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();

    _controller = TextEditingController(
      text: widget.initialValue,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: TextField(
        controller: _controller,
        keyboardType: widget.keyboardType,
        onChanged: widget.onChanged,

        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),

        decoration: InputDecoration(
          hintText: widget.hintText,

          hintStyle: const TextStyle(
            color: Color(0xFFA1B6C5),
            fontSize: 14,
          ),

          prefixIcon: Icon(
            widget.icon,
            size: 19,
            color: const Color(0xFF557A96),
          ),

          filled: true,
          fillColor: Colors.white,

          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),

          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ACCOUNT TEXT FIELD
// ============================================================

class _AccountTextField extends StatelessWidget {
  const _AccountTextField({
    required this.label,
    required this.hint,
    required this.icon,
  });

  final String label;
  final String hint;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: TextField(
        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),

        decoration: InputDecoration(
          labelText: label,
          hintText: hint,

          labelStyle: const TextStyle(
            color: Color(0xFF668397),
            fontSize: 14,
          ),

          hintStyle: const TextStyle(
            color: Color(0xFFA1B6C5),
            fontSize: 14,
          ),

          prefixIcon: Icon(
            icon,
            size: 19,
            color: const Color(0xFF557A96),
          ),

          filled: true,
          fillColor: Colors.white,

          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),

          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ACCOUNT PASSWORD FIELD
// ============================================================

class _AccountPasswordField
    extends StatefulWidget {
  const _AccountPasswordField({
    required this.label,
    required this.hint,
  });

  final String label;
  final String hint;

  @override
  State<_AccountPasswordField> createState() =>
      _AccountPasswordFieldState();
}

class _AccountPasswordFieldState
    extends State<_AccountPasswordField> {
  bool _showPassword = false;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: TextField(
        obscureText: !_showPassword,

        style: const TextStyle(
          color: Color(0xFF38566A),
          fontSize: 14,
        ),

        decoration: InputDecoration(
          labelText: widget.label,
          hintText: widget.hint,

          labelStyle: const TextStyle(
            color: Color(0xFF668397),
            fontSize: 14,
          ),

          hintStyle: const TextStyle(
            color: Color(0xFFA1B6C5),
            fontSize: 14,
          ),

          prefixIcon: const Icon(
            Icons.lock_outline,
            size: 19,
            color: Color(0xFF557A96),
          ),

          suffixIcon: IconButton(
            onPressed: () {
              setState(() {
                _showPassword = !_showPassword;
              });
            },

            icon: Icon(
              _showPassword
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
              size: 19,
              color: const Color(0xFF557A96),
            ),
          ),

          filled: true,
          fillColor: Colors.white,

          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),

          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFFC5DCEB),
            ),
          ),

          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: const BorderSide(
              color: Color(0xFF0879E8),
              width: 1.3,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SWITCH ROW
// ============================================================

class _SettingsSwitchRow extends StatelessWidget {
  const _SettingsSwitchRow({
    required this.title,
    required this.icon,
    required this.value,
    required this.onChanged,
    this.subtitle,
  });

  final String title;
  final IconData icon;
  final bool value;
  final ValueChanged<bool> onChanged;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FBFE),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFDCECF6),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: const Color(0xFFE7F3FC),
              borderRadius: BorderRadius.circular(5),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF0879E8),
              size: 18,
            ),
          ),

          const SizedBox(width: 9),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF315C75),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),

                if (subtitle != null) ...[
                  const SizedBox(height: 2),

                  Text(
                    subtitle!,
                    style: const TextStyle(
                      color: Color(0xFF6A8495),
                      fontSize: 14,
                    ),
                  ),
                ],
              ],
            ),
          ),

          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: const Color(0xFF0879E8),
            activeTrackColor: const Color(0xFF9ACCF5),
            inactiveThumbColor: const Color(0xFF8EA7B7),
            inactiveTrackColor: const Color(0xFFDCE8EF),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SETTINGS BUTTON
// ============================================================

class _SettingsButton extends StatefulWidget {
  const _SettingsButton({
    required this.text,
    required this.filled,
    required this.onTap,
    this.icon,
  });

  final String text;
  final bool filled;
  final VoidCallback onTap;
  final IconData? icon;

  @override
  State<_SettingsButton> createState() =>
      _SettingsButtonState();
}

class _SettingsButtonState
    extends State<_SettingsButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,

      onEnter: (_) {
        setState(() {
          _hovering = true;
        });
      },

      onExit: (_) {
        setState(() {
          _hovering = false;
        });
      },

      child: GestureDetector(
        onTap: widget.onTap,

        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 120,
          ),

          // ==================================================
          // SMALL BUTTON SIZE
          // ==================================================

          padding: const EdgeInsets.symmetric(
            horizontal: 13,
            vertical: 8,
          ),

          decoration: BoxDecoration(
            color: widget.filled
                ? (_hovering
                    ? const Color(0xFF066FD5)
                    : const Color(0xFF0879E8))
                : (_hovering
                    ? const Color(0xFFF2F8FC)
                    : Colors.white),

            borderRadius: BorderRadius.circular(5),

            border: widget.filled
                ? null
                : Border.all(
                    color: const Color(0xFFD1E7F4),
                  ),

            boxShadow: widget.filled
                ? const [
                    BoxShadow(
                      color: Color(0x300879E8),
                      blurRadius: 5,
                      offset: Offset(0, 2),
                    ),
                  ]
                : null,
          ),

          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.icon != null) ...[
                Icon(
                  widget.icon,
                  size: 16,
                  color: widget.filled
                      ? Colors.white
                      : const Color(0xFF52758A),
                ),

                const SizedBox(width: 5),
              ],

              Text(
                widget.text,
                style: TextStyle(
                  color: widget.filled
                      ? Colors.white
                      : const Color(0xFF52758A),
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}