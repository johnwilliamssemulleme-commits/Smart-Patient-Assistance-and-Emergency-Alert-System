import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

/// ============================================================
/// SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM
/// live_monitoring.dart
///
/// SCREEN #1 — LIVE MONITORING
/// PUBLIC / NO LOGIN
///
/// Font size:
/// - Normal text: 14
/// - Main page title: 28
/// ============================================================

class LiveMonitoringScreen extends StatefulWidget {
  const LiveMonitoringScreen({
    super.key,
    this.onLogin,
  });

  final VoidCallback? onLogin;

  @override
  State<LiveMonitoringScreen> createState() =>
      _LiveMonitoringScreenState();
}

class _LiveMonitoringScreenState extends State<LiveMonitoringScreen> {
  Timer? _clockTimer;
  Timer? _marqueeTimer;

  DateTime _currentTime = DateTime.now();
  double _titleOffset = 0;

  static const String _systemName =
      'SMART PATIENT ASSISTANCE & EMERGENCY ALERT SYSTEM';

  @override
  void initState() {
    super.initState();
    _startClock();
    _startMarquee();
  }

  void _startClock() {
    _clockTimer = Timer.periodic(
      const Duration(seconds: 1),
      (_) {
        if (!mounted) return;

        setState(() {
          _currentTime = DateTime.now();
        });
      },
    );
  }

  void _startMarquee() {
    _marqueeTimer = Timer.periodic(
      const Duration(milliseconds: 45),
      (_) {
        if (!mounted) return;

        setState(() {
          _titleOffset -= 0.55;

          if (_titleOffset < -560) {
            _titleOffset = 0;
          }
        });
      },
    );
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _marqueeTimer?.cancel();
    super.dispose();
  }

  String _formattedDateTime() {
    const weekdays = [
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      'Fri',
      'Sat',
      'Sun',
    ];

    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    final weekday = weekdays[_currentTime.weekday - 1];
    final month = months[_currentTime.month - 1];

    final hour = _currentTime.hour.toString().padLeft(2, '0');
    final minute = _currentTime.minute.toString().padLeft(2, '0');

    return '$weekday, ${_currentTime.day} $month '
        '${_currentTime.year}  $hour:$minute';
  }

  void _openLogin() {
    if (widget.onLogin != null) {
      widget.onLogin!();
      return;
    }

    Navigator.pushNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F9FD),
      body: SafeArea(
        child: Column(
          children: [
            _PublicTopBar(
              dateTime: _formattedDateTime(),
              titleOffset: _titleOffset,
              systemName: _systemName,
              onLogin: _openLogin,
            ),
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    'assets/images/hospital.png',
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: const Color(0xFFF4F9FD),
                        alignment: Alignment.center,
                        child: const Text(
                          'Hospital background image not found',
                          style: TextStyle(
                            color: Color(0xFF5E7C92),
                            fontSize: 14,
                          ),
                        ),
                      );
                    },
                  ),

                  Container(
                    color: const Color(0x18002545),
                  ),

                  LayoutBuilder(
                    builder: (context, constraints) {
                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(
                          13,
                          8,
                          13,
                          8,
                        ),
                        child: ConstrainedBox(
                          constraints: BoxConstraints(
                            minHeight: (constraints.maxHeight - 16)
                                .clamp(0.0, double.infinity),
                          ),
                          child: const _LiveMonitoringContent(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// PUBLIC TOP BAR
// ============================================================

class _PublicTopBar extends StatelessWidget {
  const _PublicTopBar({
    required this.dateTime,
    required this.titleOffset,
    required this.systemName,
    required this.onLogin,
  });

  final String dateTime;
  final double titleOffset;
  final String systemName;
  final VoidCallback onLogin;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 50,
      decoration: const BoxDecoration(
        color: Color(0xFF063B68),
        border: Border(
          bottom: BorderSide(
            color: Color(0xFF0B4777),
            width: 1,
          ),
        ),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final bool compact = constraints.maxWidth < 700;

          return Row(
            children: [
              const SizedBox(width: 5),

              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: const Color(0xFF0879E8),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x35000000),
                      blurRadius: 5,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.monitor_heart_outlined,
                  color: Colors.white,
                  size: 20,
                ),
              ),

              const SizedBox(width: 7),

              // FIX:
              // The title area is now Flexible instead of a fixed
              // 390px width, preventing the top Row from becoming
              // too wide on smaller Windows window sizes.
              Flexible(
                flex: 5,
                child: SizedBox(
                  height: 38,
                  child: ClipRect(
                    child: Stack(
                      alignment: Alignment.centerLeft,
                      children: [
                        Positioned(
                          left: titleOffset,
                          child: _MarqueeTitle(
                            systemName: systemName,
                          ),
                        ),
                        Positioned(
                          left: titleOffset + 560,
                          child: _MarqueeTitle(
                            systemName: systemName,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 6),

              if (!compact)
                Flexible(
                  flex: 2,
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      dateTime,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),

              if (!compact) const SizedBox(width: 4),

              _HoverLoginButton(
                onLogin: onLogin,
              ),

              const SizedBox(width: 5),
            ],
          );
        },
      ),
    );
  }
}

// ============================================================
// MARQUEE TITLE
// ============================================================

class _MarqueeTitle extends StatelessWidget {
  const _MarqueeTitle({
    required this.systemName,
  });

  final String systemName;

  @override
  Widget build(BuildContext context) {
    return Text(
      systemName,
      maxLines: 1,
      softWrap: false,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.2,
      ),
    );
  }
}

// ============================================================
// HOVER LOGIN BUTTON
// ============================================================

class _HoverLoginButton extends StatefulWidget {
  const _HoverLoginButton({
    required this.onLogin,
  });

  final VoidCallback onLogin;

  @override
  State<_HoverLoginButton> createState() =>
      _HoverLoginButtonState();
}

class _HoverLoginButtonState extends State<_HoverLoginButton> {
  bool _hovering = false;

  void _mouseEnter(PointerEvent event) {
    if (!mounted) return;

    setState(() {
      _hovering = true;
    });
  }

  void _mouseExit(PointerEvent event) {
    if (!mounted) return;

    setState(() {
      _hovering = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: _mouseEnter,
      onExit: _mouseExit,
      child: SizedBox(
        width: 100,
        height: 42,
        child: Center(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,

            // FIX:
            // Keep the animated button wide enough for
            // the Icon + Login text at all times.
            width: _hovering ? 88 : 2,
            height: _hovering ? 34 : 2,

            decoration: BoxDecoration(
              color: _hovering
                  ? const Color(0xFF0879E8)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(6),
              boxShadow: _hovering
                  ? const [
                      BoxShadow(
                        color: Color(0x33000000),
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      ),
                    ]
                  : null,
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(6),
                onTap: _hovering ? widget.onLogin : null,
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 100),
                  opacity: _hovering ? 1.0 : 0.0,

                  // FIX:
                  // Flexible prevents the Row from reporting an
                  // overflow during the animation.
                  child: const FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.login_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                        SizedBox(width: 5),
                        Text(
                          'Login',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// MAIN LIVE MONITORING CONTENT
// ============================================================

class _LiveMonitoringContent extends StatelessWidget {
  const _LiveMonitoringContent();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const _PageHeader(),

        const SizedBox(height: 7),

        const _StatusCards(),

        const SizedBox(height: 8),

        LayoutBuilder(
          builder: (context, constraints) {
            if (constraints.maxWidth >= 800) {
              return const SizedBox(
                height: 435,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 7,
                      child: _RecentAlertsCard(),
                    ),
                    SizedBox(width: 9),
                    Expanded(
                      flex: 3,
                      child: _SystemHealthCard(),
                    ),
                  ],
                ),
              );
            }

            return const Column(
              children: [
                SizedBox(
                  height: 370,
                  child: _RecentAlertsCard(),
                ),
                SizedBox(height: 8),
                SizedBox(
                  height: 330,
                  child: _SystemHealthCard(),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

// ============================================================
// PAGE HEADER
// ============================================================

class _PageHeader extends StatelessWidget {
  const _PageHeader();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        top: 1,
        bottom: 1,
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          // On very narrow windows, stack the online indicator
          // below the title instead of forcing both into one Row.
          if (constraints.maxWidth < 430) {
            return const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _PageTitle(),
                SizedBox(height: 6),
                _OnlinePill(),
              ],
            );
          }

          return const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _PageTitle(),
              ),
              SizedBox(width: 8),
              _OnlinePill(),
            ],
          );
        },
      ),
    );
  }
}

// ============================================================
// PAGE TITLE
// ============================================================

class _PageTitle extends StatelessWidget {
  const _PageTitle();

  @override
  Widget build(BuildContext context) {
    return const Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Live Monitoring',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Color(0xFF123F63),
            fontSize: 28,
            height: 1.05,
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 6),
        Text(
          'Real-time patient status and alerts',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Color(0xFF1971B7),
            fontSize: 14,
            height: 1.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

// ============================================================
// SYSTEM ONLINE PILL
// ============================================================

class _OnlinePill extends StatelessWidget {
  const _OnlinePill();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 1),
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFD9F7EA),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.circle,
            color: Color(0xFF11A56A),
            size: 9,
          ),
          SizedBox(width: 6),
          Text(
            'System Online',
            style: TextStyle(
              color: Color(0xFF08794E),
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// STATUS CARDS
// ============================================================

class _StatusCards extends StatelessWidget {
  const _StatusCards();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 650) {
          return const Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _StatusCard(
                      icon: Icons.groups_rounded,
                      value: '2',
                      label: 'Active Alerts',
                      type: _StatusType.red,
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: _StatusCard(
                      icon: Icons.person_rounded,
                      value: '1',
                      label: 'Critical',
                      type: _StatusType.orange,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _StatusCard(
                      icon: Icons.warning_rounded,
                      value: '2',
                      label: 'Emergency',
                      type: _StatusType.emergency,
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: _StatusCard(
                      icon: Icons.medical_services_outlined,
                      value: '4',
                      label: 'Assistance',
                      type: _StatusType.amber,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _StatusCard(
                      icon: Icons.access_time_rounded,
                      value: '28/30',
                      label: 'Normal',
                      type: _StatusType.green,
                    ),
                  ),
                  Expanded(
                    child: SizedBox(),
                  ),
                ],
              ),
            ],
          );
        }

        return const Row(
          children: [
            Expanded(
              child: _StatusCard(
                icon: Icons.groups_rounded,
                value: '2',
                label: 'Active Alerts',
                type: _StatusType.red,
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              child: _StatusCard(
                icon: Icons.person_rounded,
                value: '1',
                label: 'Critical',
                type: _StatusType.orange,
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              child: _StatusCard(
                icon: Icons.warning_rounded,
                value: '2',
                label: 'Emergency',
                type: _StatusType.emergency,
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              child: _StatusCard(
                icon: Icons.medical_services_outlined,
                value: '4',
                label: 'Assistance',
                type: _StatusType.amber,
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              child: _StatusCard(
                icon: Icons.access_time_rounded,
                value: '28/30',
                label: 'Normal',
                type: _StatusType.green,
              ),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// STATUS TYPE
// ============================================================

enum _StatusType {
  red,
  orange,
  emergency,
  amber,
  green,
}

// ============================================================
// STATUS CARD
// ============================================================

class _StatusCard extends StatelessWidget {
  const _StatusCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.type,
  });

  final IconData icon;
  final String value;
  final String label;
  final _StatusType type;

  @override
  Widget build(BuildContext context) {
    Color background;

    switch (type) {
      case _StatusType.red:
        background = const Color(0xFFE52F43);
        break;
      case _StatusType.orange:
        background = const Color(0xFFF18A16);
        break;
      case _StatusType.emergency:
        background = const Color(0xFFD91E36);
        break;
      case _StatusType.amber:
        background = const Color(0xFFF5B51B);
        break;
      case _StatusType.green:
        background = const Color(0xFF13A86B);
        break;
    }

    return Container(
      constraints: const BoxConstraints(
        minHeight: 76,
      ),
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(5),
        boxShadow: const [
          BoxShadow(
            color: Color(0x17000000),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: background,
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 23,
            ),
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 26,
                    height: 1.0,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// RECENT ALERTS CARD
// ============================================================

class _RecentAlertsCard extends StatelessWidget {
  const _RecentAlertsCard();

  @override
  Widget build(BuildContext context) {
    return _Panel(
      title: 'Recent Alerts',
      action: 'View All',
      child: Column(
        children: [
          const _AlertTableHeader(),

          const Divider(
            height: 1,
            color: Color(0xFFE1EEF7),
          ),

          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: const [
                _AlertRow(
                  time: '14:31',
                  type: 'Emergency',
                  wardType: 'Medical',
                  wardId: 'B-03',
                  patient: '0012',
                  bedId: '12',
                  status: 'Active',
                  statusKind: _RowStatus.red,
                ),
                _AlertRow(
                  time: '14:28',
                  type: 'Assistance',
                  wardType: 'Surgical',
                  wardId: 'A-01',
                  patient: '0007',
                  bedId: '05',
                  status: 'Pending',
                  statusKind: _RowStatus.amber,
                ),
                _AlertRow(
                  time: '14:26',
                  type: 'Critical',
                  wardType: 'Medical',
                  wardId: 'B-02',
                  patient: '0009',
                  bedId: '02',
                  status: 'Active',
                  statusKind: _RowStatus.orange,
                ),
                _AlertRow(
                  time: '14:20',
                  type: 'Emergency',
                  wardType: 'Medical',
                  wardId: 'B-03',
                  patient: '0015',
                  bedId: '03',
                  status: 'Active',
                  statusKind: _RowStatus.red,
                ),
                _AlertRow(
                  time: '14:12',
                  type: 'Assistance',
                  wardType: 'General',
                  wardId: 'C-01',
                  patient: '0021',
                  bedId: '08',
                  status: 'Resolved',
                  statusKind: _RowStatus.green,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ALERT TABLE HEADER
// ============================================================

class _AlertTableHeader extends StatelessWidget {
  const _AlertTableHeader();

  @override
  Widget build(BuildContext context) {
    const labels = [
      'Time',
      'Type',
      'Ward Type',
      'Ward ID',
      'Patient',
      'Bed ID',
      'Status',
    ];

    const flexes = [
      11,
      21,
      18,
      13,
      13,
      10,
      14,
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        8,
        8,
        8,
        7,
      ),
      child: Row(
        children: List.generate(
          labels.length,
          (index) {
            return Expanded(
              flex: flexes[index],
              child: Text(
                labels[index],
                textAlign:
                    index == 0 ? TextAlign.left : TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF5E7C92),
                  fontSize: 14,
                  height: 1.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// ROW STATUS
// ============================================================

enum _RowStatus {
  red,
  orange,
  amber,
  green,
}

// ============================================================
// ALERT ROW
// ============================================================

class _AlertRow extends StatelessWidget {
  const _AlertRow({
    required this.time,
    required this.type,
    required this.wardType,
    required this.wardId,
    required this.patient,
    required this.bedId,
    required this.status,
    required this.statusKind,
  });

  final String time;
  final String type;
  final String wardType;
  final String wardId;
  final String patient;
  final String bedId;
  final String status;
  final _RowStatus statusKind;

  @override
  Widget build(BuildContext context) {
    Color badgeBackground;
    Color badgeText;

    switch (type) {
      case 'Emergency':
        badgeBackground = const Color(0xFFFFE4E7);
        badgeText = const Color(0xFFE3263D);
        break;
      case 'Critical':
        badgeBackground = const Color(0xFFFFE7DB);
        badgeText = const Color(0xFFE65A18);
        break;
      default:
        badgeBackground = const Color(0xFFFFF1D4);
        badgeText = const Color(0xFFC98500);
    }

    Color statusBackground;
    Color statusText;

    switch (statusKind) {
      case _RowStatus.red:
        statusBackground = const Color(0xFFFFE4E7);
        statusText = const Color(0xFFE3263D);
        break;
      case _RowStatus.orange:
        statusBackground = const Color(0xFFFFE9DE);
        statusText = const Color(0xFFE65A18);
        break;
      case _RowStatus.amber:
        statusBackground = const Color(0xFFFFF1D4);
        statusText = const Color(0xFFC98500);
        break;
      case _RowStatus.green:
        statusBackground = const Color(0xFFDDF7EC);
        statusText = const Color(0xFF0B9A61);
        break;
    }

    const commonTextStyle = TextStyle(
      color: Color(0xFF42657D),
      fontSize: 14,
      height: 1.0,
    );

    return Container(
      height: 49,
      margin: const EdgeInsets.symmetric(
        horizontal: 5,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFEAF2F7),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 12,
            child: Text(
              time,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: commonTextStyle.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 22,
            child: Center(
              child: _Badge(
                text: type,
                background: badgeBackground,
                foreground: badgeText,
              ),
            ),
          ),
          Expanded(
            flex: 20,
            child: Text(
              wardType,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: commonTextStyle,
            ),
          ),
          Expanded(
            flex: 15,
            child: Text(
              wardId,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: commonTextStyle.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 15,
            child: Text(
              patient,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: commonTextStyle,
            ),
          ),
          Expanded(
            flex: 12,
            child: Text(
              bedId,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: commonTextStyle.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 16,
            child: Center(
              child: _Badge(
                text: status,
                background: statusBackground,
                foreground: statusText,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// BADGE
// ============================================================

class _Badge extends StatelessWidget {
  const _Badge({
    required this.text,
    required this.background,
    required this.foreground,
  });

  final String text;
  final Color background;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: foreground,
          fontSize: 14,
          height: 1.0,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// ============================================================
// SYSTEM HEALTH CARD
// ============================================================

class _SystemHealthCard extends StatelessWidget {
  const _SystemHealthCard();

  @override
  Widget build(BuildContext context) {
    return _Panel(
      title: 'System Health',
      child: Column(
        children: [
          const _HealthLine(
            icon: Icons.sensors_outlined,
            label: 'Receiver',
            value: 'Connected',
          ),
          const _HealthLine(
            icon: Icons.devices_other_outlined,
            label: 'Devices',
            value: '28/30',
          ),
          const _HealthLine(
            icon: Icons.wifi_rounded,
            label: 'Network',
            value: 'Online',
          ),
          const _HealthLine(
            icon: Icons.storage_outlined,
            label: 'Database',
            value: 'Online',
          ),
          const SizedBox(height: 8),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Live View (Hall)',
              style: TextStyle(
                color: Color(0xFF214B69),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFF1FAFF),
                border: Border.all(
                  color: const Color(0xFFD3EAF7),
                ),
                borderRadius: BorderRadius.circular(5),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.monitor_heart_outlined,
                    color: Color(0xFF0AA36A),
                    size: 34,
                  ),
                  SizedBox(height: 9),
                  Text(
                    'Hall Receiver - Online',
                    style: TextStyle(
                      color: Color(0xFF2B5B76),
                      fontSize: 14,
                      height: 1.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    '28 / 30 Devices',
                    style: TextStyle(
                      color: Color(0xFF7892A5),
                      fontSize: 14,
                      height: 1.0,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// HEALTH LINE
// ============================================================

class _HealthLine extends StatelessWidget {
  const _HealthLine({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 43,
      child: Row(
        children: [
          Container(
            width: 30,
            height: 28,
            decoration: const BoxDecoration(
              color: Color(0xFFE2F8EF),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: const Color(0xFF0AA36A),
              size: 17,
            ),
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF45667C),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const Icon(
            Icons.circle,
            color: Color(0xFF0AA36A),
            size: 8,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: const TextStyle(
                color: Color(0xFF118B61),
                fontSize: 14,
                height: 1.0,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GENERIC PANEL
// ============================================================

class _Panel extends StatelessWidget {
  const _Panel({
    required this.title,
    required this.child,
    this.action,
  });

  final String title;
  final String? action;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: const Color(0xFFD0E8F6),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0E0B3D64),
            blurRadius: 4,
            offset: Offset(0, 1),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(
        10,
        9,
        10,
        9,
      ),
      child: Column(
        children: [
          SizedBox(
            height: 29,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFF214B69),
                      fontSize: 14,
                      height: 1.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                if (action != null) ...[
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      action!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        color: Color(0xFF0879E8),
                        fontSize: 14,
                        height: 1.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 3),
          Expanded(
            child: child,
          ),
        ],
      ),
    );
  }
}
